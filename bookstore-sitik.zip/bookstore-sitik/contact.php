<?php
session_start();

require_once __DIR__ . "/config/database.php";

// =====================================
// TOKEN KEAMANAN FORM
// =====================================

if (empty($_SESSION['contact_csrf'])) {
    $_SESSION['contact_csrf'] = bin2hex(random_bytes(32));
}

// =====================================
// DATA FORM CONTACT
// =====================================

$success_message = "";
$error_message = "";

$name = "";
$email = "";

// Isi otomatis jika pelanggan sudah login
if (isset($_SESSION["user_id"])) {
    $user_id = (int) $_SESSION["user_id"];

    $stmt = $conn->prepare(
        "SELECT name, email FROM users WHERE id = ? LIMIT 1"
    );

    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    $user_data = $stmt->get_result()->fetch_assoc();

    if ($user_data) {
        $name = $user_data["name"];
        $email = $user_data["email"];
    }

    $stmt->close();
}

// =====================================
// PROSES KIRIM PESAN
// =====================================

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["send_message"])) {

    $csrf_token = $_POST["csrf_token"] ?? "";

    if (
        empty($_SESSION["contact_csrf"]) ||
        !hash_equals($_SESSION["contact_csrf"], $csrf_token)
    ) {
        $error_message = "Sesi formulir tidak valid. Silakan muat ulang halaman.";
    } else {

        $name = trim($_POST["name"] ?? "");
        $email = trim($_POST["email"] ?? "");
        $subject = trim($_POST["subject"] ?? "");
        $message = trim($_POST["message"] ?? "");

        if (
            $name === "" ||
            $email === "" ||
            $subject === "" ||
            $message === ""
        ) {
            $error_message = "Semua kolom wajib diisi.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error_message = "Format email tidak valid.";
        } elseif (
            mb_strlen($name) > 100 ||
            mb_strlen($email) > 150 ||
            mb_strlen($subject) > 150 ||
            mb_strlen($message) > 5000
        ) {
            $error_message = "Pesan terlalu panjang. Periksa kembali isian Anda.";
        } else {

            $user_id = isset($_SESSION["user_id"])
                ? (int) $_SESSION["user_id"]
                : null;

            $stmt = $conn->prepare("
                INSERT INTO contact_messages
                (user_id, name, email, subject, message)
                VALUES (?, ?, ?, ?, ?)
            ");

            $stmt->bind_param(
                "issss",
                $user_id,
                $name,
                $email,
                $subject,
                $message
            );

            if ($stmt->execute()) {
                $success_message = "Pesan berhasil dikirim! Admin akan segera memeriksanya.";

                // Buat token baru setelah pengiriman berhasil
                $_SESSION["contact_csrf"] = bin2hex(random_bytes(32));

                $name = "";
                $email = "";
            } else {
                $error_message = "Pesan gagal dikirim. Silakan coba kembali.";
            }

            $stmt->close();
        }
    }
}

// =====================================
// CHAT PELANGGAN DI HALAMAN CONTACT
// =====================================

$chat_error = "";
$chat_success = "";
$chat_messages = [];
$chat_replies = [];
$selected_chat = null;
$selected_chat_id = (int)($_GET["chat_id"] ?? $_POST["chat_message_id"] ?? 0);
$customer_id = (int)($_SESSION["user_id"] ?? 0);

if (empty($_SESSION["customer_chat_csrf"])) {
    $_SESSION["customer_chat_csrf"] = bin2hex(random_bytes(32));
}

// Pelanggan dapat membalas dari card percakapan di halaman Contact
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["send_chat_reply"])) {
    $chat_token = $_POST["chat_csrf"] ?? "";
    $chat_reply = trim($_POST["chat_reply"] ?? "");
    $selected_chat_id = (int)($_POST["chat_message_id"] ?? 0);

    if ($customer_id <= 0 || ($_SESSION["user_role"] ?? "") !== "user") {
        $chat_error = "Silakan login sebagai pelanggan untuk membalas percakapan.";
    } elseif (
        empty($_SESSION["customer_chat_csrf"]) ||
        !hash_equals($_SESSION["customer_chat_csrf"], $chat_token)
    ) {
        $chat_error = "Sesi chat tidak valid. Silakan muat ulang halaman.";
    } elseif ($chat_reply === "" || mb_strlen($chat_reply) > 5000) {
        $chat_error = "Pesan wajib diisi dan maksimal 5.000 karakter.";
    } else {
        $check_chat = $conn->prepare("SELECT id FROM contact_messages WHERE id = ? AND user_id = ? LIMIT 1");
        $check_chat->bind_param("ii", $selected_chat_id, $customer_id);
        $check_chat->execute();
        $owned_chat = $check_chat->get_result()->fetch_assoc();
        $check_chat->close();

        if (!$owned_chat) {
            $chat_error = "Percakapan tidak ditemukan.";
        } else {
            $sender_role = "user";
            $insert_reply = $conn->prepare("INSERT INTO contact_replies (message_id, sender_id, sender_role, reply) VALUES (?, ?, ?, ?)");
            $insert_reply->bind_param("iiss", $selected_chat_id, $customer_id, $sender_role, $chat_reply);

            if ($insert_reply->execute()) {
                $insert_reply->close();

                $mark_unread = $conn->prepare("UPDATE contact_messages SET is_read = 0 WHERE id = ? AND user_id = ?");
                $mark_unread->bind_param("ii", $selected_chat_id, $customer_id);
                $mark_unread->execute();
                $mark_unread->close();

                header("Location: contact.php?chat_id=" . $selected_chat_id . "&chat_sent=1#contact-chat");
                exit;
            } else {
                $chat_error = "Pesan gagal dikirim. Silakan coba kembali.";
                $insert_reply->close();
            }
        }
    }
}

// Ambil semua percakapan milik pelanggan yang sedang login
if ($customer_id > 0 && ($_SESSION["user_role"] ?? "") === "user") {
    $list_chats = $conn->prepare("SELECT id, subject, message, created_at FROM contact_messages WHERE user_id = ? ORDER BY created_at DESC");
    $list_chats->bind_param("i", $customer_id);
    $list_chats->execute();
    $chat_messages = $list_chats->get_result()->fetch_all(MYSQLI_ASSOC);
    $list_chats->close();

    // Jika belum memilih percakapan, tampilkan percakapan terbaru
    if ($selected_chat_id <= 0 && !empty($chat_messages)) {
        $selected_chat_id = (int)$chat_messages[0]["id"];
    }

    if ($selected_chat_id > 0) {
        $get_chat = $conn->prepare("SELECT id, subject, message, created_at FROM contact_messages WHERE id = ? AND user_id = ? LIMIT 1");
        $get_chat->bind_param("ii", $selected_chat_id, $customer_id);
        $get_chat->execute();
        $selected_chat = $get_chat->get_result()->fetch_assoc();
        $get_chat->close();

        if ($selected_chat) {
            // Balasan admin dianggap sudah dibaca saat pelanggan membuka percakapan.
            $mark_admin_replies = $conn->prepare("
                UPDATE contact_replies
                SET is_read = 1
                WHERE message_id = ?
                  AND sender_role = 'admin'
            ");
            $mark_admin_replies->bind_param("i", $selected_chat_id);
            $mark_admin_replies->execute();
            $mark_admin_replies->close();

            $get_replies = $conn->prepare("SELECT r.id, r.sender_id, r.sender_role, r.reply, r.created_at, u.name AS sender_name FROM contact_replies r LEFT JOIN users u ON u.id = r.sender_id WHERE r.message_id = ? ORDER BY r.created_at ASC, r.id ASC");
            $get_replies->bind_param("i", $selected_chat_id);
            $get_replies->execute();
            $chat_replies = $get_replies->get_result()->fetch_all(MYSQLI_ASSOC);
            $get_replies->close();
        }
    }
}

// =========================================
// KONFIGURASI WHATSAPP
// =========================================

$whatsapp_number = "6283871315657";

$whatsapp_message = "Halo S'itik Bookstore, saya ingin bertanya mengenai produk atau layanan toko.";

$whatsapp_url = "https://wa.me/" . $whatsapp_number
    . "?text=" . urlencode($whatsapp_message);


// =========================================
// CEK LOGIN ADMIN
// =========================================

if (
    isset($_SESSION["user_role"]) &&
    $_SESSION["user_role"] === "admin"
) {
    header("Location: admin/dashboard.php");
    exit;
}


// =========================================
// DATA PENGGUNA
// =========================================

$display_name = "Akun Saya";

if (isset($_SESSION["user_id"])) {

    $nav_uid = (int) $_SESSION["user_id"];

    $nav_stmt = $conn->prepare(
        "SELECT name FROM users WHERE id = ? LIMIT 1"
    );

    if ($nav_stmt) {

        $nav_stmt->bind_param("i", $nav_uid);
        $nav_stmt->execute();

        $nav_user = $nav_stmt->get_result()->fetch_assoc();

        $display_name = $nav_user["name"] ?? "Akun Saya";

        $nav_stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Contact Us - S'itik BOOKSTORE</title>

    <!-- CSS UTAMA -->
    <link rel="stylesheet" href="css/base.css">

    <!-- CSS HOMEPAGE -->
    <link rel="stylesheet" href="css/home.css">

    <!-- CSS CONTACT -->
    <link rel="stylesheet" href="css/contact.css">

    <!-- FONT AWESOME - WHATSAPP BRAND ICON -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
    >


    <style>
        /* Layout dua card: formulir di kiri dan percakapan di kanan */
        .contact-form-section .contact-layout {
            width: min(1250px, 94%);
            margin: 40px auto;
            display: grid;
            grid-template-columns: minmax(0, 1.05fr) minmax(340px, .95fr);
            align-items: stretch;
            gap: 24px;
        }

        .contact-form-section .contact-form-container,
        .contact-form-section .contact-chat-card {
            width: 100%;
            max-width: none;
            min-width: 0;
            margin: 0;
            box-sizing: border-box;
            background: #fffdf9;
            border: 1px solid #e5ddcf;
            border-radius: 16px;
            padding: 28px;
            box-shadow: 0 8px 25px rgba(70, 58, 38, .06);
        }

        .contact-form-section .contact-chat-card {
            display: flex;
            flex-direction: column;
            min-height: 100%;
        }

        .contact-chat-heading h2 {
            margin: 0 0 7px;
            color: #566b50;
            font-size: 25px;
        }

        .contact-chat-heading p {
            margin: 0 0 18px;
            color: #777;
            font-size: 14px;
            line-height: 1.5;
        }

        .contact-chat-list {
            display: flex;
            flex-direction: column;
            gap: 7px;
            max-height: 125px;
            overflow-y: auto;
            margin-bottom: 15px;
        }

        .contact-chat-list a {
            display: block;
            padding: 10px 12px;
            border: 1px solid #e8e5dc;
            border-radius: 8px;
            color: #465641;
            text-decoration: none;
            font-size: 13px;
            background: #fff;
        }

        .contact-chat-list a.active,
        .contact-chat-list a:hover {
            background: #edf0df;
            border-color: #aab89f;
        }

        .contact-chat-list small {
            display: block;
            margin-top: 4px;
            color: #888;
        }

        .contact-chat-history {
            flex: 1;
            min-height: 230px;
            max-height: 360px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 13px;
            padding: 15px 4px;
            border-top: 1px solid #eee9df;
            border-bottom: 1px solid #eee9df;
        }

        .contact-chat-bubble {
            max-width: 86%;
            padding: 12px 14px;
            border-radius: 12px;
            font-size: 14px;
            line-height: 1.55;
            overflow-wrap: anywhere;
        }

        .contact-chat-bubble.customer {
            align-self: flex-end;
            background: #71836b;
            color: #fff;
            border-bottom-right-radius: 3px;
        }

        .contact-chat-bubble.admin {
            align-self: flex-start;
            background: #edf0df;
            color: #354231;
            border-bottom-left-radius: 3px;
        }

        .contact-chat-bubble strong {
            display: block;
            margin-bottom: 5px;
            font-size: 12px;
        }

        .contact-chat-bubble small {
            display: block;
            margin-top: 7px;
            font-size: 10px;
            opacity: .75;
        }

        .contact-chat-reply-form {
            margin-top: 14px;
        }

        .contact-chat-reply-form textarea {
            width: 100%;
            min-height: 75px;
            padding: 12px;
            border: 1px solid #ddd7ca;
            border-radius: 9px;
            resize: vertical;
            font: inherit;
            box-sizing: border-box;
        }

        .contact-chat-reply-form button {
            width: 100%;
            margin-top: 9px;
            padding: 12px;
            border: 0;
            border-radius: 8px;
            background: #71836b;
            color: #fff;
            font-weight: 600;
            cursor: pointer;
        }

        .contact-chat-reply-form button:hover {
            background: #566b50;
        }

        .contact-chat-notice {
            padding: 10px 12px;
            margin-bottom: 12px;
            border-radius: 8px;
            background: #e5f2e5;
            color: #315f35;
            font-size: 13px;
        }

        .contact-chat-notice.error {
            background: #fbe8e6;
            color: #a3332b;
        }

        .contact-chat-empty {
            flex: 1;
            min-height: 230px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #888;
            line-height: 1.6;
            padding: 20px;
            background: #faf8f2;
            border-radius: 10px;
        }

        @media (max-width: 900px) {
            .contact-form-section .contact-layout {
                width: 92%;
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 520px) {
            .contact-form-section .contact-form-container,
            .contact-form-section .contact-chat-card {
                padding: 20px;
            }
            .contact-chat-bubble {
                max-width: 94%;
            }
        }
    </style>

</head>

<body class="contact-page">


    <!-- =========================================
         NAVBAR
    ========================================== -->

    <header class="site-navbar">

        <a
            class="site-logo"
            href="home.php"
            aria-label="S'itik Bookstore Home"
        >

            <img
                src="images/logo-icon.png"
                alt="S'itik Bookstore Logo"
            >

            <span class="site-logo-text">

                <span class="top">S’itik</span>

                <span class="bottom">BOOKSTORE</span>

            </span>

        </a>


        <nav class="site-nav" aria-label="Main navigation">

            <a href="home.php">Home</a>

            <a href="cart.php">Cart</a>

            <a href="about-us.php">About Us</a>

            <a href="contact.php" class="active">Contact</a>


            <?php if (isset($_SESSION["user_id"])): ?>

                <a
                    href="profile.php"
                    style="color: #4a5c46; font-weight: bold;"
                >
                    👤 <?= htmlspecialchars(
                        $display_name,
                        ENT_QUOTES,
                        "UTF-8"
                    ); ?>
                </a>

                <a href="logout.php" class="signin-link">
                    Logout
                </a>

            <?php else: ?>

                <a href="login.php" class="signin-link">
                    Sign In
                </a>

            <?php endif; ?>

        </nav>

    </header>



    <!-- =========================================
         CONTACT HERO SECTION
    ========================================== -->

    <section class="contact-hero">

        <div class="contact-overlay">

            <h1>Contact us</h1>

            <p>
                Have questions, issues with an order, or need book recommendations?
                Don't hesitate to reach out to the S'itik Bookstore team!
            </p>

        </div>

    </section>

<!-- =========================================
     CONTACT TO ADMIN FORM
========================================== -->

<section class="contact-form-section">

    <div class="contact-layout">

        <div class="contact-form-container">

        <div class="contact-form-heading">
            <span>GET IN TOUCH</span>
            <h2>Contact to Admin</h2>
            <p>
                Punya pertanyaan, kendala pesanan, atau saran?
                Kirim pesan kepada admin S'titik Bookstore.
            </p>
        </div>

        <?php if ($success_message !== ""): ?>
            <div class="contact-alert success">
                <?= htmlspecialchars($success_message, ENT_QUOTES, "UTF-8"); ?>
            </div>
        <?php endif; ?>

        <?php if ($error_message !== ""): ?>
            <div class="contact-alert error">
                <?= htmlspecialchars($error_message, ENT_QUOTES, "UTF-8"); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="contact.php" class="contact-form">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= htmlspecialchars($_SESSION['contact_csrf'], ENT_QUOTES, 'UTF-8'); ?>"
            >

            <div class="form-group">
                <label for="name">Nama Lengkap</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    placeholder="Masukkan nama Anda"
                    maxlength="100"
                    value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8'); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="contoh@email.com"
                    maxlength="150"
                    value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label for="subject">Subjek Pesan</label>
                <input
                    type="text"
                    id="subject"
                    name="subject"
                    placeholder="Contoh: Pertanyaan mengenai pesanan"
                    maxlength="150"
                    required
                >
            </div>

            <div class="form-group">
                <label for="message">Isi Pesan</label>
                <textarea
                    id="message"
                    name="message"
                    rows="6"
                    maxlength="5000"
                    placeholder="Tuliskan pesan Anda di sini..."
                    required
                ></textarea>
            </div>

            <button
                type="submit"
                name="send_message"
                class="contact-submit-btn"
            >
                <i class="fa-solid fa-paper-plane"></i>
                Kirim Pesan
            </button>

        </form>

    </div>

        <!-- CARD PERCAKAPAN PELANGGAN -->
        <aside class="contact-chat-card" id="contact-chat">
            <div class="contact-chat-heading">
                <h2><i class="fa-solid fa-comments"></i> Percakapan</h2>
                <p>Lihat balasan admin dan lanjutkan percakapan di sini.</p>
            </div>

            <?php if (isset($_SESSION["user_id"]) && ($_SESSION["user_role"] ?? "") === "user"): ?>

                <?php if ($chat_error !== ""): ?>
                    <div class="contact-chat-notice error"><?= htmlspecialchars($chat_error, ENT_QUOTES, "UTF-8"); ?></div>
                <?php endif; ?>

                <?php if (isset($_GET["chat_sent"])): ?>
                    <div class="contact-chat-notice">Pesan berhasil dikirim.</div>
                <?php endif; ?>

                <?php if (!empty($chat_messages)): ?>
                    <div class="contact-chat-list">
                        <?php foreach ($chat_messages as $chat_item): ?>
                            <a
                                href="contact.php?chat_id=<?= (int)$chat_item["id"]; ?>#contact-chat"
                                class="<?= $selected_chat_id === (int)$chat_item["id"] ? "active" : ""; ?>"
                            >
                                <strong><?= htmlspecialchars($chat_item["subject"], ENT_QUOTES, "UTF-8"); ?></strong>
                                <small><?= date("d-m-Y H:i", strtotime($chat_item["created_at"])); ?></small>
                            </a>
                        <?php endforeach; ?>
                    </div>

                    <?php if ($selected_chat): ?>
                        <div class="contact-chat-history">
                            <div class="contact-chat-bubble customer">
                                <strong>Anda</strong>
                                <?= nl2br(htmlspecialchars($selected_chat["message"], ENT_QUOTES, "UTF-8")); ?>
                                <small><?= date("d-m-Y H:i", strtotime($selected_chat["created_at"])); ?></small>
                            </div>

                            <?php foreach ($chat_replies as $chat_reply_item): ?>
                                <div class="contact-chat-bubble <?= $chat_reply_item["sender_role"] === "admin" ? "admin" : "customer"; ?>">
                                    <strong><?= $chat_reply_item["sender_role"] === "admin" ? "Administrator" : "Anda"; ?></strong>
                                    <?= nl2br(htmlspecialchars($chat_reply_item["reply"], ENT_QUOTES, "UTF-8")); ?>
                                    <small><?= date("d-m-Y H:i", strtotime($chat_reply_item["created_at"])); ?></small>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <form method="POST" action="contact.php#contact-chat" class="contact-chat-reply-form">
                            <input type="hidden" name="chat_csrf" value="<?= htmlspecialchars($_SESSION["customer_chat_csrf"], ENT_QUOTES, "UTF-8"); ?>">
                            <input type="hidden" name="chat_message_id" value="<?= (int)$selected_chat_id; ?>">
                            <textarea name="chat_reply" maxlength="5000" placeholder="Tulis balasan Anda..." required></textarea>
                            <button type="submit" name="send_chat_reply"><i class="fa-solid fa-paper-plane"></i> Kirim Balasan</button>
                        </form>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="contact-chat-empty">
                        Belum ada percakapan.<br>Silakan kirim pesan melalui formulir Contact di sebelah kiri.
                    </div>
                <?php endif; ?>

            <?php else: ?>
                <div class="contact-chat-empty">
                    Silakan login sebagai pelanggan untuk melihat dan melanjutkan percakapan dengan admin.
                    <br><br>
                    <a href="login.php">Login sekarang</a>
                </div>
            <?php endif; ?>
        </aside>

    </div>

</section>

    <!-- =========================================
         CONTACT FOOTER SECTION
    ========================================== -->

    <footer class="contact-footer">

        <div class="footer-container">


            <!-- KOLOM 1: BRAND -->

            <div class="footer-brand">

                <div class="footer-logo">

                    <img
                        src="images/logo-icon.png"
                        alt="S'itik Bookstore Logo"
                    >

                    <div class="footer-logo-text">

                        <span class="top">S'itik</span>

                        <span class="bottom">BOOKSTORE</span>

                    </div>

                </div>


                <p>
                    Discover the wonders of the literary world with us.
                    S'itik Bookstore offers an excellent collection
                    of books—the perfect companions for your leisure time, whenever you need them.
                </p>

            </div>



            <!-- KOLOM 2: TAUTAN CEPAT -->

            <div class="footer-column">

                <h4>Quick Links</h4>

                <a href="home.php">Home</a>

                <a href="about-us.php">About Us</a>

                <a href="cart.php">Cart</a>

            </div>



            <!-- KOLOM 3: INFO KONTAK -->

            <div class="footer-column">

                <h4>Info Kontak</h4>

                <p>
                    <i class="fa-solid fa-location-dot contact-info-icon"></i>
                    Jl. Literasi No. 99, Jakarta
                </p>

                <p>
                    <i class="fa-solid fa-envelope contact-info-icon"></i>
                    support@sitikbookstore.com
                </p>


                <!-- WHATSAPP CONTACT -->

                <a
                    href="<?= htmlspecialchars(
                        $whatsapp_url,
                        ENT_QUOTES,
                        "UTF-8"
                    ); ?>"
                    class="contact-phone"
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label="Hubungi S'itik Bookstore melalui WhatsApp"
                    title="Chat melalui WhatsApp"
                >

                    <i class="fa-brands fa-whatsapp"></i>

                    <span>+62 838-7131-5657</span>

                </a>

            </div>

        </div>



        <!-- =========================================
             COPYRIGHT
        ========================================== -->

        <div class="footer-bottom">

            &copy; <?= date("Y"); ?> S'itik Bookstore.
            All rights reserved.

        </div>

    </footer>



    <!-- =========================================
         FLOATING WHATSAPP BUTTON
    ========================================== -->

    <a
        href="<?= htmlspecialchars(
            $whatsapp_url,
            ENT_QUOTES,
            "UTF-8"
        ); ?>"
        class="whatsapp-float"
        target="_blank"
        rel="noopener noreferrer"
        title="Hubungi kami via WhatsApp"
        aria-label="Hubungi S'itik Bookstore melalui WhatsApp"
    >

        <i class="fa-brands fa-whatsapp" aria-hidden="true"></i>

    </a>


</body>

</html>
