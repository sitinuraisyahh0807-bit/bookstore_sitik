<?php
session_start();
require_once __DIR__ . "/config/database.php";

if (isset($_SESSION["user_role"]) && $_SESSION["user_role"] === "admin") {
    header("Location: admin/dashboard.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - S'itik BOOKSTORE</title>
  <link rel="stylesheet" href="css/base.css">
  <link rel="stylesheet" href="css/about.css">
</head>
<body class="about-page">

  <header class="site-navbar">
    <a class="site-logo" href="home.php" aria-label="S'itik Bookstore Home">
      <img src="images/logo-icon.png" alt="S'itik Bookstore logo">
      <span class="site-logo-text">
        <span class="top">S’itik</span>
        <span class="bottom">BOOKSTORE</span>
      </span>
    </a>

    <nav class="site-nav" aria-label="Main navigation">
      <a href="home.php">Home</a>
      <a href="cart.php">Cart</a>
      <a href="about-us.php" class="active">About Us</a>
      <a href="contact.php">Contact</a>
      <?php if (isset($_SESSION["user_id"])): ?>
        <?php
            $nav_uid = $_SESSION["user_id"];
            $nav_stmt = $conn->prepare("SELECT name FROM users WHERE id = ? LIMIT 1");
            $nav_stmt->bind_param("i", $nav_uid);
            $nav_stmt->execute();
            $nav_user = $nav_stmt->get_result()->fetch_assoc();
            $nav_stmt->close();
            $display_name = $nav_user['name'] ?? 'Akun Saya';
        ?>
        <a href="profile.php" style="color: #4a5c46; font-weight: bold;">👤 <?php echo htmlspecialchars($display_name); ?></a>
        <a href="logout.php" class="signin-link">Logout</a>
      <?php else: ?>
        <a href="login.php" class="signin-link">Sign In</a>
      <?php endif; ?>
    </nav>

  </header>

  <main>
    <section class="about-hero">
      <img src="images/wp-about-us.png" alt="S'itik Bookstore" class="about-banner">
    </section>

    <section class="about-section">
      <div class="about-text">
        <h1>About S'itik Bookstore</h1>
        <p>
          S'itik Bookstore is a cozy online bookstore created for readers who love
          discovering new stories. We carefully curate fantasy, history, horror,
          romance, and contemporary books to make reading more accessible and enjoyable.
        </p>
      </div>
    </section>

    <section class="vision-mission" aria-label="Vision and mission">
      <article class="vm-card">
        <h3>Our Vision</h3>
        <p>
          To become a trusted bookstore that inspires a lifelong reading culture
          through meaningful stories and quality books.
        </p>
      </article>

      <article class="vm-card">
        <h3>Our Mission</h3>
        <p>
          Provide quality books, affordable prices, and a pleasant shopping
          experience for every reader.
        </p>
      </article>
    </section>

    <section class="why-section" aria-labelledby="why-title">
      <h2 id="why-title">Why Choose Us?</h2>

      <div class="feature-grid">
        <article class="feature-card">
          <h3>Curated Collection</h3>
          <p>A thoughtful selection of fantasy, history, horror, romance, and contemporary books.</p>
        </article>

        <article class="feature-card">
          <h3>Affordable Prices</h3>
          <p>Student-friendly pricing with regular promotions and special discounts.</p>
        </article>

        <article class="feature-card">
          <h3>Made for Readers</h3>
          <p>Designed to help readers discover their next favorite book and enjoy a seamless shopping experience.</p>
        </article>
      </div>
    </section>

    <section class="quote-section">
      <h2>“Every great story begins with a single page.”</h2>
      <p>Thank you for being part of the S'itik Bookstore journey.</p>
    </section>
  </main>

</body>
</html>
