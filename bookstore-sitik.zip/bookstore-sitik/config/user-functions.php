<?php
function getAllUsers($conn) { $r=$conn->query('SELECT id,name,email,role,status FROM users ORDER BY id DESC');return $r?$r->fetch_all(MYSQLI_ASSOC):[]; }
function getRecentUsers($conn,$limit=2) { $limit=max(1,min(20,(int)$limit));$stmt=$conn->prepare('SELECT id,name,email,role,status FROM users ORDER BY id DESC LIMIT ?');$stmt->bind_param('i',$limit);$stmt->execute();$rows=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);$stmt->close();return $rows; }
function handleUserActions($conn) {
    if($_SERVER['REQUEST_METHOD']!=='POST')return;
    if(isset($_POST['toggle_user_status'])){$id=(int)$_POST['user_id'];if($id>1){$stmt=$conn->prepare("UPDATE users SET status=IF(status='Aktif','Nonaktif','Aktif') WHERE id=? AND role='user'");$stmt->bind_param('i',$id);$stmt->execute();$stmt->close();}}
    if(isset($_POST['delete_user'])){$id=(int)$_POST['user_id'];if($id>1){$stmt=$conn->prepare("DELETE FROM users WHERE id=? AND role='user'");$stmt->bind_param('i',$id);$stmt->execute();$stmt->close();}}
}
