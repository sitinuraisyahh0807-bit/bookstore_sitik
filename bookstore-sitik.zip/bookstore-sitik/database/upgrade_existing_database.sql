USE sitik_bookstore;

ALTER TABLE users ADD COLUMN IF NOT EXISTS name VARCHAR(150) NULL AFTER id;
ALTER TABLE users ADD COLUMN IF NOT EXISTS email VARCHAR(190) NULL AFTER name;
ALTER TABLE users ADD COLUMN IF NOT EXISTS status ENUM('Aktif','Nonaktif') NOT NULL DEFAULT 'Aktif';
UPDATE users SET name=COALESCE(NULLIF(name,''), username, CONCAT('Pengguna ',id)) WHERE name IS NULL OR name='';
UPDATE users SET email=CONCAT('legacy+',id,'@sitik.local') WHERE email IS NULL OR email='';
UPDATE users SET email='admin@sitikbookstore.local' WHERE role='admin' AND id=1;
ALTER TABLE users MODIFY username VARCHAR(100) NULL;
ALTER TABLE users MODIFY name VARCHAR(150) NOT NULL;
ALTER TABLE users MODIFY email VARCHAR(190) NOT NULL;
ALTER TABLE users ADD UNIQUE KEY IF NOT EXISTS uq_users_email(email);

ALTER TABLE books ADD COLUMN IF NOT EXISTS is_best_author TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE books ADD COLUMN IF NOT EXISTS is_best_pick TINYINT(1) NOT NULL DEFAULT 0;

ALTER TABLE orders ADD COLUMN IF NOT EXISTS user_id INT NOT NULL DEFAULT 1;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS customer_phone VARCHAR(40) NOT NULL DEFAULT '';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS customer_address TEXT NULL;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_method VARCHAR(60) NOT NULL DEFAULT 'Transfer BCA';
ALTER TABLE orders ADD COLUMN IF NOT EXISTS subtotal INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS shipping_fee INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_status VARCHAR(40) NOT NULL DEFAULT 'Unpaid';
UPDATE orders SET subtotal=total_amount WHERE subtotal=0;
UPDATE orders SET customer_address='' WHERE customer_address IS NULL;
ALTER TABLE orders MODIFY customer_address TEXT NOT NULL;
ALTER TABLE orders MODIFY order_status ENUM('pending','processing','completed','cancelled') NOT NULL DEFAULT 'pending';

ALTER TABLE order_items ADD COLUMN IF NOT EXISTS line_total INT UNSIGNED NOT NULL DEFAULT 0;
UPDATE order_items SET line_total=price*quantity WHERE line_total=0;


