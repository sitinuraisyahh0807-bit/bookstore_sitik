<?php
session_start();require_once __DIR__.'/config/database.php';require_once __DIR__.'/config/cart-functions.php';
if(empty($_SESSION['user_id'])){header('Location: login.php');exit;}
$book_id=(int)($_POST['book_id']??$_GET['id']??0);$quantity=(int)($_POST['quantity']??1);
if(!addToCart($conn,(int)$_SESSION['user_id'],$book_id,$quantity))$_SESSION['cart_error']=$_SESSION['cart_error']??'Buku tidak dapat ditambahkan ke keranjang.';
header('Location: cart.php');exit;
