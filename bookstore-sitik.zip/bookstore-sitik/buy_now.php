<?php
session_start();

require_once __DIR__ . "/config/database.php";
require_once __DIR__ . "/config/checkout-functions.php";

// Panggil fungsi proses beli sekarang
processBuyNow($conn, $_POST);

?>