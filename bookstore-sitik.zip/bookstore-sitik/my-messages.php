<?php
// Compatibility route: chat pelanggan kini terintegrasi pada halaman Contact.
session_start();

if (!isset($_SESSION["user_id"]) || ($_SESSION["user_role"] ?? "") !== "user") {
    header("Location: login.php");
    exit;
}

$chatId = (int) ($_GET["id"] ?? 0);
$destination = "contact.php";

if ($chatId > 0) {
    $destination .= "?chat_id=" . $chatId . "#contact-chat";
} else {
    $destination .= "#contact-chat";
}

header("Location: " . $destination);
exit;
