<?php
session_start();

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../config/user-functions.php";

// Pastikan hanya admin yang bisa mengakses halaman ini
if (!isset($_SESSION["user_id"]) || $_SESSION["user_role"] !== "admin") {
    header("Location: ../login.php");
    exit;
}

// Ambil data users
$users = getAllUsers($conn);

$current_page = basename($_SERVER['PHP_SELF']);
$is_menu_open = in_array($current_page, ['dashboard.php', 'users.php', 'categories.php', 'books.php', 'add-book.php', 'orders.php']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar User - Admin S'itik Bookstore</title>
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        /* Memastikan gaya tabel sama persis dengan yang ada di dashboard */
        .dash-card { background: white; border-radius: 16px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.04); border: 1px solid #eee; margin-top: 20px; }
        .dash-card-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px; }
        .dash-card-header h3 { font-size: 18px; color: #46543d; margin: 0 0 5px 0; }
        .dash-card-header p { font-size: 13px; color: #7b8178; margin: 0; }
        
        .dash-table { width: 100%; border-collapse: collapse; }
        .dash-table th { background: #fbf9f4; padding: 12px; text-align: left; font-size: 12px; color: #555; border-bottom: 1px solid #eee; }
        .dash-table td { padding: 12px; font-size: 13px; color: #444; border-bottom: 1px solid #f5f5f5; vertical-align: middle; }
    </style>
</head>
<body>

<div class="admin-container">

    <!-- SIDEBAR PERSIS SEPERTI DASHBOARD -->
    <aside class="sidebar">
        <div class="sidebar-logo">
            <img src="../images/logo-icon.png" alt="Logo">
            <div class="logo-text">
                <span class="logo-top">S'itik</span>
                <strong>BOOKSTORE</strong>
                <small>ADMIN PANEL</small>
            </div>
        </div>

        <div class="sidebar-menu">
            <div class="menu-title">MAIN MENU</div>
            <div class="menu-dropdown-container <?php echo $is_menu_open ? 'open' : ''; ?>" id="mainMenuContainer">
                <div class="menu-item-wrapper <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                    <a href="dashboard.php" class="menu-link">⌂ <span>Dashboard</span></a>
                    <span class="arrow-toggle" onclick="toggleMenu()">▼</span>
                </div>
                
                <ul class="submenu-list">
                <li><a href="users.php" class="submenu-item <?php echo ($current_page == 'users.php') ? 'active' : ''; ?>">Daftar User</a></li>
                <li><a href="categories.php" class="submenu-item <?php echo ($current_page == 'categories.php') ? 'active' : ''; ?>">Kategori Buku</a></li>
                <li><a href="books.php" class="submenu-item <?php echo ($current_page == 'books.php') ? 'active' : ''; ?>">Data Buku</a></li>
                <li><a href="add-book.php" class="submenu-item <?php echo ($current_page == 'add-book.php') ? 'active' : ''; ?>">Tambah Buku</a></li>
                <li><a href="orders.php" class="submenu-item <?php echo ($current_page == 'orders.php') ? 'active' : ''; ?>">Pesanan User</a></li>
                <li><a href="messages.php"class="submenu-item <?= ($current_page == 'messages.php') ? 'active' : ''; ?>">Pesan Masuk</a></li>
            </ul>
            
            </div>
        </div>

        <div class="sidebar-bottom">
            <a href="../logout.php" class="menu-item logout">→ <span>Logout</span></a>
        </div>
    </aside>

    <script>
    function toggleMenu() { document.getElementById('mainMenuContainer').classList.toggle('open'); }
    </script>

    <main class="main-content">
        <!-- HEADER PERSIS SEPERTI DASHBOARD -->
        <header class="admin-header">
            <div class="header-title">
                <h1>Daftar User</h1>
                <p>Kelola semua akun pengguna S'itik Bookstore.</p>
            </div>
            <div class="admin-profile">
                <div class="profile-avatar">A</div>
                <div class="profile-text">
                    <strong>Administrator</strong>
                    <span>Admin</span>
                </div>
            </div>
        </header>

        <div class="dashboard-content" style="padding-top: 20px;">
            <div class="dash-card">
                <div class="dash-card-header">
                    <div>
                        <h3>Seluruh Pengguna</h3>
                        <p>Berikut adalah daftar lengkap akun yang terdaftar di sistem.</p>
                    </div>
                </div>
                
                <table class="dash-table">
                    <thead>
                        <tr>
                            <th>NO</th>
                            <th>ID USER</th>
                            <th>NAMA</th>
                            <th>EMAIL</th>
                            <th>ROLE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($users)): ?>
                            <tr>
                                <td colspan="5" style="text-align: center;">Belum ada user yang terdaftar.</td>
                            </tr>
                        <?php else: ?>
                            <?php $no = 1; foreach ($users as $user): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><b>#USR-<?= str_pad($user['id'], 3, "0", STR_PAD_LEFT); ?></b></td>
                                    <td><?php echo htmlspecialchars($user['name']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td>
                                        <?php if($user['role'] === 'admin'): ?>
                                            <span style="background:#e5f0ff; color:#4a82d2; padding:4px 10px; border-radius:4px; font-size:11px; font-weight:bold;">Admin</span>
                                        <?php else: ?>
                                            <span style="background:#f4f4f4; color:#555; padding:4px 10px; border-radius:4px; font-size:11px; font-weight:bold;">User</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

</div>

</body>
</html>