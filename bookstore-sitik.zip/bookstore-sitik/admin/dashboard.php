<?php
session_start();
require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../config/category-functions.php";
require_once __DIR__ . "/../config/book-functions.php";
require_once __DIR__ . "/../config/order-admin-functions.php";
require_once __DIR__ . "/../config/user-functions.php";

// ===============================
// CEK LOGIN ADMIN
// ===============================
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if (!isset($_SESSION["user_role"]) || $_SESSION["user_role"] !== "admin") {
    header("Location: ../home.php");
    exit;
}

$unread_message_query = $conn->query("
    SELECT
        (SELECT COUNT(*) FROM contact_messages WHERE is_read = 0)
        +
        (SELECT COUNT(*) FROM contact_replies
         WHERE sender_role = 'user' AND is_read = 0) AS total
");
$unread_message_count = (int) ($unread_message_query->fetch_assoc()["total"] ?? 0);

// ===============================
// TANGANI SUBMIT FORM (Preview)
// ===============================
handleCategoryActions($conn);
$add_book_msg = "";
handleAddBook($conn, $add_book_msg);
$order_msg = "";
handleUpdateOrderStatus($conn, $order_msg);

// Pengelolaan akun dilakukan melalui fungsi terproteksi (POST).
handleUserActions($conn);

// ===============================
// STATISTIK
// ===============================
$book_query = $conn->query("SELECT COUNT(*) AS total FROM books");
$total_books = $book_query->fetch_assoc()["total"];

$stock_query = $conn->query("SELECT SUM(stock) AS total FROM books");
$total_stock = $stock_query->fetch_assoc()["total"] ?? 0;

$order_count_query = $conn->query("SELECT COUNT(*) AS total FROM orders");
$total_orders = $order_count_query->fetch_assoc()["total"];

// Menghitung seluruh akun pengguna (tidak termasuk admin)
$user_query = $conn->query("
    SELECT COUNT(*) AS total
    FROM users
    WHERE LOWER(TRIM(role)) = 'user'
");

$total_users = (int) $user_query->fetch_assoc()['total'];

// ===============================
// AMBIL DATA SEMUA TABEL
// ===============================
$order_list = $conn->query("SELECT orders.id, orders.total_amount, orders.order_status, orders.created_at, orders.customer_name, orders.payment_proof FROM orders ORDER BY orders.created_at DESC LIMIT 5");

$low_stock_query = $conn->query("SELECT title, author, category, stock, image FROM books WHERE stock <= 5 ORDER BY stock ASC LIMIT 3");
$low_stock = [];
if($low_stock_query){ 
    while($row = mysqli_fetch_assoc($low_stock_query)){ 
        $low_stock[] = $row; 
    } 
}

// Ambil data (akan dilimit manual di tampilan)
$categories = getCategories($conn);
$category_options = getCategoryOptions($conn);
$books = getAllBooks($conn);

$users_query = $conn->query("SELECT * FROM users ORDER BY role ASC, id ASC LIMIT 2");
$users_list = [];
if($users_query){ 
    while($row = $users_query->fetch_assoc()){ 
        $users_list[] = $row; 
    } 
}

date_default_timezone_set("Asia/Jakarta");

$current_page = basename($_SERVER['PHP_SELF']);
$is_menu_open = in_array($current_page, ['dashboard.php', 'users.php', 'categories.php', 'books.php', 'add-book.php', 'orders.php',]);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - S'itik Bookstore</title>
    <link rel="stylesheet" href="../css/admin.css">
    <!-- CSS Tambahan Khusus Tata Letak Dashboard Final -->
    <style>
        .notification-count {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 20px;
            height: 20px;
            padding: 0 6px;
            margin-left: 6px;
            border-radius: 20px;
            background: #dc5656;
            color: #fff;
            font-size: 11px;
            font-weight: 700;
        }

        .grid-middle { display: grid; grid-template-columns: 1.8fr 1fr; gap: 20px; margin-top: 20px; }
        .grid-bottom { display: grid; grid-template-columns: 1.4fr 1fr 1.6fr; gap: 20px; margin-top: 20px; align-items: start; }
        
        .dash-card { background: white; border-radius: 16px; padding: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.04); border: 1px solid #eee; }
        .dash-card-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 15px; }
        .dash-card-header h3 { font-size: 16px; color: #46543d; margin: 0 0 5px 0; }
        .dash-card-header p { font-size: 11px; color: #7b8178; margin: 0; }
        
        .dash-table { width: 100%; border-collapse: collapse; }
        .dash-table th { background: #fbf9f4; padding: 10px; text-align: left; font-size: 10px; color: #555; border-bottom: 1px solid #eee; }
        .dash-table td { padding: 10px; font-size: 12px; color: #444; border-bottom: 1px solid #f5f5f5; vertical-align: middle; }
        
        .link-all { display: inline-block; margin-top: 15px; font-size: 12px; color: #2c6eb5; text-decoration: none; font-weight: bold; }
        .link-all:hover { text-decoration: underline; }
        
        .stock-warn-item { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid #eee; }
        .stock-warn-item:last-child { border-bottom: none; }
        .stock-warn-left { display: flex; gap: 12px; align-items: center; }
        .stock-warn-left img { width: 35px; height: 50px; border-radius: 4px; object-fit: cover; }
        .stock-red-badge { background: #ffe4e3; color: #c64c4c; padding: 5px 12px; border-radius: 6px; font-weight: bold; font-size: 14px; }
        
        .mini-form { display: flex; gap: 10px; margin-bottom: 15px; }
        .mini-input { flex: 1; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 12px; }
        .mini-btn { background: #7f9275; color: white; border: none; padding: 8px 15px; border-radius: 6px; font-size: 12px; cursor: pointer; }
    </style>
</head>
<body>

<div class="admin-container">

<!-- SIDEBAR -->
<aside class="sidebar">
    <div class="sidebar-logo">
        <img src="../images/logo-icon.png" alt="Logo">
        <div class="logo-text">
            <span class="logo-top">S'itik</span>
            <strong>BOOKSTORE</strong>
            <small>ADMIN PANEL</small>
        </div>
    </div>

    <div class="sidebar-menu">
        <div class="menu-title">MAIN MENU</div>
        <div class="menu-dropdown-container <?php echo $is_menu_open ? 'open' : ''; ?>" id="mainMenuContainer">
            <div class="menu-item-wrapper <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <a href="dashboard.php" class="menu-link">⌂ <span>Dashboard</span></a>
                <span class="arrow-toggle" onclick="toggleMenu()">▼</span>
            </div>
            
            <ul class="submenu-list">
                <li><a href="users.php" class="submenu-item <?php echo ($current_page == 'users.php') ? 'active' : ''; ?>">Daftar User</a></li>
                <li><a href="categories.php" class="submenu-item <?php echo ($current_page == 'categories.php') ? 'active' : ''; ?>">Kategori Buku</a></li>
                <li><a href="books.php" class="submenu-item <?php echo ($current_page == 'books.php') ? 'active' : ''; ?>">Data Buku</a></li>
                <li><a href="add-book.php" class="submenu-item <?php echo ($current_page == 'add-book.php') ? 'active' : ''; ?>">Tambah Buku</a></li>
                <li><a href="orders.php" class="submenu-item <?php echo ($current_page == 'orders.php') ? 'active' : ''; ?>">Pesanan User</a></li>
                <li>
                    <a href="messages.php" class="submenu-item <?= ($current_page == 'messages.php') ? 'active' : ''; ?>">
                        Pesan Masuk
                        <?php if ($unread_message_count > 0): ?>
                            <span class="notification-count"><?= $unread_message_count; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="sidebar-bottom">
        <a href="../logout.php" class="menu-item logout">→ <span>Logout</span></a>
    </div>
</aside>

<script>
function toggleMenu() { document.getElementById('mainMenuContainer').classList.toggle('open'); }
</script>

<main class="main-content">
<header class="admin-header">
    <div class="header-title">
        <h1>Admin Dashboard</h1>
        <p>Kelola S'itik Bookstore melalui halaman Admin.</p>
    </div>
    <div class="admin-profile">
        <div class="profile-avatar">A</div>
        <div class="profile-text">
            <strong>Administrator</strong>
            <span>Admin</span>
        </div>
    </div>
</header>

<div class="dashboard-content" style="padding-top: 20px;">

<!-- 1. WELCOME SECTION -->
<section class="welcome-section" style="padding: 20px 25px;">
    <div>
        <span class="welcome-small">WELCOME BACK</span>
        <h2 style="font-size: 24px; margin-top:5px;">Selamat datang, Administrator!</h2>
        <p style="font-size: 12px;">Kelola data buku, persediaan stok, pesanan, dan akun pengguna dengan mudah.</p>
    </div>
    <div class="current-date" style="padding: 12px 20px;">
        <span>Hari ini</span>
        <strong><?php echo date("d M Y"); ?></strong>
    </div>
</section>

<!-- 2. SUMMARY CARDS -->
<section class="summary-container" style="margin-top: 20px;">
    <article class="summary-card"><div class="summary-icon">📖</div><div class="summary-text"><span style="font-size:11px;">Total Buku</span><strong style="font-size:22px;"><?php echo $total_books; ?></strong><small style="font-size:10px;">Judul buku tersedia</small></div></article>
    <article class="summary-card"><div class="summary-icon" style="color:#d4842f; background:#fff2e6;">⚠️</div><div class="summary-text"><span style="font-size:11px;">Peringatan Stok</span><strong style="font-size:22px;"><?php echo count($low_stock); ?></strong><small style="font-size:10px;">Buku hampir habis</small></div></article>
    <article class="summary-card"><div class="summary-icon">🛒</div><div class="summary-text"><span style="font-size:11px;">Pesanan</span><strong style="font-size:22px;"><?php echo $total_orders; ?></strong><small style="font-size:10px;">Total pesanan masuk</small></div></article>
    <article class="summary-card"><div class="summary-icon">👤</div><div class="summary-text"><span style="font-size:11px;">Total User</span><strong style="font-size:22px;"><?php echo $total_users; ?></strong><small style="font-size:10px;">Akun pengguna</small></div></article>
</section>

<!-- 3. MIDDLE GRID (Pesanan & Stok Habis) -->
<div class="grid-middle">
    <!-- Preview Pesanan -->
    <div class="dash-card">
        <div class="dash-card-header">
            <div><h3>Pesanan User</h3><p>Pantau pesanan pelanggan, cek bukti TF, dan perbarui status pengiriman.</p></div>
        </div>
        <table class="dash-table">
            <thead><tr><th>ID PESANAN</th><th>PELANGGAN</th><th>TANGGAL</th><th>TOTAL</th><th>BUKTI TF</th><th>STATUS</th><th>UPDATE</th></tr></thead>
            <tbody>
                <?php if($order_list && $order_list->num_rows > 0): 
                    $counter = 0;
                    while($order=mysqli_fetch_assoc($order_list)): 
                        if($counter >= 2) break; // Tampilkan 2 saja di preview
                        $counter++;
                ?>
                <tr>
                    <td><b>#ORD-<?= $order['id']; ?></b></td>
                    <td><?= htmlspecialchars($order['customer_name']); ?></td>
                    <td><?= date("d M Y H:i", strtotime($order['created_at'])); ?></td>
                    <td style="font-weight:bold;">Rp <?= number_format($order['total_amount'],0,",","."); ?></td>
                    <td>
                        <?php if(!empty($order['payment_proof'])): ?><img src="../<?= htmlspecialchars($order['payment_proof']); ?>" style="width:30px; height:40px; border-radius:4px; object-fit:cover;"><?php else: ?>-<?php endif; ?>
                    </td>
                    <td>
                        <?php $status = strtolower($order['order_status']); $class = 'pending'; if ($status == 'processing') { $class = 'processing'; } elseif ($status == 'completed') { $class = 'completed'; } ?>
                        <span style="background:#eaf1e7; color:#628453; padding:4px 8px; border-radius:6px; font-size:10px; font-weight:bold;"><?= ucfirst($order['order_status']); ?></span>
                    </td>
                    <td><button style="background:#7f9275; color:white; border:none; padding:4px 10px; border-radius:4px; font-size:10px; cursor:pointer;">Update</button></td>
                </tr>
                <?php endwhile; else: ?><tr><td colspan="7">Belum ada pesanan.</td></tr><?php endif; ?>
            </tbody>
        </table>
        <a href="orders.php" class="link-all">Lihat semua pesanan →</a>
    </div>

    <!-- Preview Stok Hampir Habis -->
    <div class="dash-card">
        <div class="dash-card-header">
            <div><h3>Stok Hampir Habis</h3><p>Buku dengan stok tersisa antara 3 - 1.</p></div>
        </div>
        <div>
            <?php if(!empty($low_stock)): foreach($low_stock as $book): ?>
            <div class="stock-warn-item">
                <div class="stock-warn-left">
                    <img src="../<?= htmlspecialchars($book['image']); ?>">
                    <div><b style="font-size:13px; color:#333;"><?= htmlspecialchars($book['title']); ?></b><div style="font-size:11px; color:#777; margin-top:2px;"><?= htmlspecialchars($book['author']); ?></div></div>
                </div>
                <div style="display:flex; align-items:center; gap:10px;">
                    <span style="font-size:11px; color:#777;">Stok Tersisa</span>
                    <div class="stock-red-badge"><?= (int)$book['stock']; ?></div>
                </div>
            </div>
            <?php endforeach; else: ?><p style="font-size:12px; color:#777;">Stok aman.</p><?php endif; ?>
        </div>
        <a href="books.php" class="link-all">Lihat semua stok →</a>
    </div>
</div>

<!-- 4. BOTTOM GRID (Daftar User, Kategori, Data Buku) -->
<div class="grid-bottom">
    
    <!-- Preview Daftar User -->
    <div class="dash-card">
        <div class="dash-card-header">
            <div><h3>Daftar User</h3><p>Berikut adalah daftar semua pengguna.</p></div>
            <div style="border:1px solid #ddd; padding:4px 10px; border-radius:6px; font-size:11px; color:#777;">🔍 Cari...</div>
        </div>
        <table class="dash-table">
            <thead><tr><th>ID</th><th>NAMA</th><th>ROLE</th><th>STATUS</th></tr></thead>
            <tbody>
                <?php if(!empty($users_list)): foreach($users_list as $u): ?>
                <tr>
                    <td><b>#USR-<?= str_pad($u['id'], 3, "0", STR_PAD_LEFT); ?></b></td>
                    <td><?= !empty($u['name']) ? htmlspecialchars($u['name']) : '-'; ?></td>
                    <td><span style="background:#e5f0ff; color:#4a82d2; padding:3px 8px; border-radius:4px; font-size:10px; font-weight:bold;"><?= ucfirst($u['role']); ?></span></td>
                    <td><span style="background:#eaf1e7; color:#628453; padding:3px 8px; border-radius:4px; font-size:10px; font-weight:bold;">Aktif</span></td>
                </tr>
                <?php endforeach; else: ?><tr><td colspan="4">Belum ada user.</td></tr><?php endif; ?>
            </tbody>
        </table>
        <div style="display:flex; justify-content:space-between; align-items:center;">
            <span style="font-size:10px; color:#777; margin-top:15px;">Menampilkan 1 - 2 data</span>
            <a href="users.php" class="link-all" style="margin-top:10px;">Lihat semua user →</a>
        </div>
    </div>

    <!-- Preview Kategori Buku -->
    <div class="dash-card">
        <div class="dash-card-header">
            <div><h3>Kategori Buku</h3><p>Kelola kategori buku S'itik Bookstore.</p></div>
        </div>
        <form method="POST" action="categories.php" class="mini-form">
            <input type="text" name="name" class="mini-input" placeholder="Nama kategori baru..." required>
            <button type="submit" name="add" class="mini-btn">+ Tambah</button>
        </form>
        <table class="dash-table">
            <thead><tr><th>ID</th><th>NAMA KATEGORI</th><th>AKSI</th></tr></thead>
            <tbody>
                <?php if ($categories && $categories->num_rows > 0): 
                    $cat_count = 0;
                    while($cat = mysqli_fetch_assoc($categories)): 
                        if($cat_count >= 4) break;
                        $cat_count++;
                ?>
                <tr>
                    <td><?= (int) $cat['id']; ?></td>
                    <td><?= htmlspecialchars($cat['name']); ?></td>
                    <td><span style="color:#c64c4c; font-weight:bold; font-size:11px;">Delete</span></td>
                </tr>
                <?php endwhile; endif; ?>
            </tbody>
        </table>
        <a href="categories.php" class="link-all">Lihat semua kategori →</a>
    </div>

    <!-- Preview Data Buku -->
    <div class="dash-card">
        <div class="dash-card-header">
            <div><h3>Data Buku</h3><p>Kelola data buku pada S'itik Bookstore.</p></div>
            <a href="add-book.php" style="font-size:11px; color:#555; text-decoration:none; font-weight:bold;">+ Tambah Buku</a>
        </div>
        <table class="dash-table">
            <thead><tr><th>COVER</th><th>JUDUL</th><th>KATEGORI</th><th>STOK</th><th>AKSI</th></tr></thead>
            <tbody>
                <?php if ($books && $books->num_rows > 0): 
                    $b_count = 0;
                    while($book = $books->fetch_assoc()): 
                        if($b_count >= 3) break;
                        $b_count++;
                ?>
                <tr>
                    <td><img src="../<?= htmlspecialchars($book['image']); ?>" style="width:30px; height:40px; border-radius:4px; object-fit:cover;"></td>
                    <td><b><?= htmlspecialchars($book['title']); ?></b><br><small style="color:#777;"><?= htmlspecialchars($book['author']); ?></small></td>
                    <td><?= htmlspecialchars($book['category']); ?></td>
                    <td><b><?= (int) $book['stock']; ?></b></td>
                    <td><span style="color:#f39c12; margin-right:5px;">✏️</span><span style="color:#c64c4c;">🗑️</span></td>
                </tr>
                <?php endwhile; endif; ?>
            </tbody>
        </table>
        <a href="books.php" class="link-all">Lihat semua buku →</a>
    </div>

</div>

</div>
</main>
</div>


<script>
let dashboardUnreadCount = <?= $unread_message_count; ?>;
setInterval(async function () {
    try {
        const response = await fetch("messages.php?ajax=unread-count", { cache: "no-store" });
        if (!response.ok) return;
        const data = await response.json();
        if (Number(data.unread_count || 0) !== dashboardUnreadCount) {
            window.location.reload();
        }
    } catch (error) {
        // Abaikan kegagalan polling agar dashboard tetap dapat digunakan.
    }
}, 15000);
</script>
</body>
</html>