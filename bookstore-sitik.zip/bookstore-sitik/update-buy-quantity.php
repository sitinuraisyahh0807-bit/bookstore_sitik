<?php

session_start();

require_once __DIR__ . "/config/database.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: checkout.php");
    exit;
}

/* Simpan isi form supaya tidak hilang ketika tombol +/- ditekan. */
$_SESSION["checkout_form"] = [
    "customer_name" => $_POST["customer_name"]
        ?? ($_SESSION["checkout_form"]["customer_name"] ?? ""),
    "customer_phone" => $_POST["customer_phone"]
        ?? ($_SESSION["checkout_form"]["customer_phone"] ?? ""),
    "customer_address" => $_POST["customer_address"]
        ?? ($_SESSION["checkout_form"]["customer_address"] ?? ""),
    "payment" => $_POST["payment"]
        ?? ($_SESSION["checkout_form"]["payment"] ?? "Bank Transfer")
];

if (
    !isset($_SESSION["checkout_items"]) ||
    !is_array($_SESSION["checkout_items"])
) {
    header("Location: checkout.php");
    exit;
}

/*
| Tombol mengirim value seperti "increase:12" atau "decrease:12".
| Fallback lama tetap didukung agar file lain tidak langsung rusak.
*/
$raw_action = (string) ($_POST["quantity_action"] ?? "");
$action = $raw_action;
$book_id = (int) ($_POST["book_id"] ?? 0);

if (strpos($raw_action, ":") !== false) {
    [$action, $id_part] = explode(":", $raw_action, 2);
    $book_id = (int) $id_part;
}

if ($book_id < 1 || !in_array($action, ["increase", "decrease"], true)) {
    header("Location: checkout.php");
    exit;
}

foreach ($_SESSION["checkout_items"] as &$item) {
    if ((int) ($item["book_id"] ?? 0) !== $book_id) {
        continue;
    }

    $current_quantity = max(1, (int) ($item["quantity"] ?? 1));

    if ($action === "increase") {
        $stmt = $conn->prepare(
            "SELECT stock FROM books WHERE id = ? LIMIT 1"
        );
        $stmt->bind_param("i", $book_id);
        $stmt->execute();

        $book = $stmt
            ->get_result()
            ->fetch_assoc();

        $stmt->close();

        if ($book && $current_quantity < (int) $book["stock"]) {
            $item["quantity"] = $current_quantity + 1;
        }
    } elseif ($current_quantity > 1) {
        $item["quantity"] = $current_quantity - 1;
    }

    break;
}
unset($item);

header("Location: checkout.php");
exit;
