
<?php

// ========================================
// 1. MENGAMBIL SEMUA DATA BUKU
// ========================================

function getAllBooks($conn) {

    return $conn->query(
        "SELECT * FROM books ORDER BY id DESC"
    );

}


// ========================================
// 2. MENYIMPAN GAMBAR BUKU
// ========================================

function saveBookImage($field = 'image') {

    if (
        !isset($_FILES[$field]) ||
        $_FILES[$field]['error'] === UPLOAD_ERR_NO_FILE
    ) {
        return '';
    }

    $f = $_FILES[$field];

    if ($f['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Gagal mengunggah gambar.');
    }

    if ($f['size'] > 3 * 1024 * 1024) {
        throw new RuntimeException('Gambar maksimal 3 MB.');
    }

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);

    $map = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp'
    ];

    if (!isset($map[$mime])) {
        throw new RuntimeException(
            'Format gambar harus JPG, PNG, atau WEBP.'
        );
    }

    $name = bin2hex(random_bytes(12)) . '.' . $map[$mime];

    $dir = __DIR__ . '/../images/';

    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }

    if (!move_uploaded_file($f['tmp_name'], $dir . $name)) {
        throw new RuntimeException('Gagal menyimpan gambar.');
    }

    return 'images/' . $name;
}


// ========================================
// 3. MEMBACA STATUS BEST AUTHOR DAN BEST PICK
// ========================================

function getBookFeatureStatus($field) {

    $allowedFields = [
        'is_best_author',
        'is_best_pick'
    ];

    if (!in_array($field, $allowedFields, true)) {
        return 0;
    }

    return (
        isset($_POST[$field]) &&
        (string) $_POST[$field] === '1'
    ) ? 1 : 0;
}


// ========================================
// 4. MENAMBAHKAN BUKU BARU
// ========================================

function handleAddBook($conn, &$error_msg) {

    if (
        $_SERVER['REQUEST_METHOD'] !== 'POST' ||
        !isset($_POST['add_book'])
    ) {
        return;
    }

    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $description = trim($_POST['description'] ?? '');

    $priceRaw = trim((string) ($_POST['price'] ?? ''));
    $stockRaw = trim((string) ($_POST['stock'] ?? ''));

    // Validasi harga dan stok
    if (
        $title === '' ||
        $author === '' ||
        $category === '' ||
        $priceRaw === '' ||
        !preg_match('/^\d+(\.\d+)?$/', $priceRaw) ||
        !preg_match('/^\d+$/', $stockRaw)
    ) {
        $error_msg = 'Periksa kembali data buku. Harga dan stok harus berupa angka nol atau lebih.';
        return;
    }

    $price = (float) $priceRaw;
    $stock = (int) $stockRaw;

    try {

        $image = saveBookImage();

        // Membaca pilihan Best Author dan Best Pick
        $a = getBookFeatureStatus('is_best_author');
        $p = getBookFeatureStatus('is_best_pick');

        $s = $conn->prepare(
            "INSERT INTO books
            (
                title,
                author,
                category,
                price,
                stock,
                description,
                image,
                is_best_author,
                is_best_pick
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );

        $s->bind_param(
            'sssdissii',
            $title,
            $author,
            $category,
            $price,
            $stock,
            $description,
            $image,
            $a,
            $p
        );

        $s->execute();
        $s->close();

        header('Location: books.php?status=success');
        exit;

    } catch (Throwable $e) {

        $error_msg = $e->getMessage();

    }
}


// ========================================
// 5. MENGEDIT DATA BUKU
// ========================================

function handleEditBook($conn, $id, $current_image) {

    if (!isset($_POST['update'])) {
        return;
    }

    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $description = trim($_POST['description'] ?? '');

    $priceRaw = trim((string) ($_POST['price'] ?? ''));
    $stockRaw = trim((string) ($_POST['stock'] ?? ''));

    // Validasi data buku
    if (
        $title === '' ||
        $author === '' ||
        $category === '' ||
        $priceRaw === '' ||
        !preg_match('/^\d+(\.\d+)?$/', $priceRaw) ||
        !preg_match('/^\d+$/', $stockRaw)
    ) {
        throw new RuntimeException(
            'Data buku tidak valid. Periksa judul, author, kategori, harga, dan stok.'
        );
    }

    // Konversi data
    $price = (float) $priceRaw;
    $stock = (int) $stockRaw;

    // Pertahankan gambar lama jika tidak mengganti gambar
    $image = $current_image;

    $new_image = saveBookImage();

    if ($new_image !== '') {
        $image = $new_image;
    }

    // Status Best Author dan Best Pick
    $a = getBookFeatureStatus('is_best_author');
    $p = getBookFeatureStatus('is_best_pick');

    // Update database
    $s = $conn->prepare(
        "UPDATE books SET
            title = ?,
            author = ?,
            category = ?,
            price = ?,
            stock = ?,
            description = ?,
            image = ?,
            is_best_author = ?,
            is_best_pick = ?
        WHERE id = ?"
    );

    $id = (int) $id;

    $s->bind_param(
        'sssdissiii',
        $title,
        $author,
        $category,
        $price,
        $stock,
        $description,
        $image,
        $a,
        $p,
        $id
    );

    $s->execute();
    $s->close();

    header('Location: books.php?status=updated');
    exit;
}


// ========================================
// 6. MENGHAPUS BUKU
// ========================================

function handleDeleteBook($conn, $id) {

    $id = (int) $id;

    $s = $conn->prepare(
        "SELECT image FROM books WHERE id = ?"
    );

    $s->bind_param('i', $id);
    $s->execute();

    $book = $s->get_result()->fetch_assoc();

    $s->close();

    if (!$book) {
        return false;
    }

    $d = $conn->prepare(
        "DELETE FROM books WHERE id = ?"
    );

    $d->bind_param('i', $id);

    try {

        $d->execute();
        $ok = $d->affected_rows > 0;

    } catch (Throwable $e) {

        $d->close();
        return false;

    }

    $d->close();

    // Hapus gambar jika buku berhasil dihapus
    if ($ok && !empty($book['image'])) {

        $path = realpath(
            __DIR__ . '/../' . $book['image']
        );

        $base = realpath(
            __DIR__ . '/../images'
        );

        if (
            $path &&
            $base &&
            str_starts_with(
                $path,
                $base . DIRECTORY_SEPARATOR
            )
        ) {
            @unlink($path);
        }
    }

    return $ok;
}


// ========================================
// 7. MEMPERBARUI STOK BUKU
// ========================================

function handleUpdateStock($conn, $id, $action) {

    $id = (int) $id;

    if ($action === 'plus') {

        $s = $conn->prepare(
            "UPDATE books
             SET stock = stock + 1
             WHERE id = ?"
        );

    } elseif ($action === 'minus') {

        $s = $conn->prepare(
            "UPDATE books
             SET stock = stock - 1
             WHERE id = ? AND stock > 0"
        );

    } else {

        return false;

    }

    $s->bind_param('i', $id);

    $s->execute();

    $ok = $s->affected_rows > 0;

    $s->close();

    return $ok;
}

?>
