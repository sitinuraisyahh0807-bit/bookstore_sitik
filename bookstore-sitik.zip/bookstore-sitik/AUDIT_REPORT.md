# Laporan Audit dan Perbaikan S'titik Bookstore

## Hasil pemeriksaan
- Seluruh 43 file PHP dalam paket hasil perbaikan lolos `php -l`.
- Pemindaian referensi lokal `href`, `src`, dan `action` tidak menemukan target file yang hilang.
- Pemeriksaan dilakukan secara statis pada kode dan struktur ZIP. Aplikasi belum dijalankan terhadap database XAMPP pengguna, sehingga pengujian runtime dan transaksi nyata tetap harus dilakukan.

## Perubahan
1. Menambahkan `database/repair_existing_database.sql` untuk:
   - Mengubah `orders.payment_status` menjadi `VARCHAR(40)` agar seluruh status pembayaran dapat disimpan.
   - Menormalkan pesanan COD yang masih berjalan menjadi `Pay on Delivery`.
   - Membuat/melengkapi `contact_messages` dan `contact_replies`, termasuk kolom `is_read`.
   - Tidak menghapus data pesanan, pengguna, buku, atau pesan.
2. Menambahkan tabel chat ke skema instalasi baru `database/sitik_bookstore.sql`.
3. Memperbaiki status baca balasan:
   - Admin membuka percakapan: balasan pelanggan ditandai sudah dibaca.
   - Pelanggan membuka percakapan: balasan admin ditandai sudah dibaca.
4. Merapikan sel isi pesan pada `admin/messages.php` dengan kolom tabel tetap dan perataan kiri khusus isi pesan.
5. Menambahkan indikator pesan belum dibaca pada Dashboard admin dan polling berkala.
6. Menambahkan perlindungan CSRF pada perubahan status pesanan, verifikasi pembayaran, checkout, dan upload bukti pembayaran.
7. Memperbaiki `user/account.php`:
   - Menggunakan `user_role`, bukan session key yang tidak konsisten.
   - Mengambil data akun langsung dari database.
   - Mengganti tautan `.html` yang tidak ada menjadi halaman `.php`.
8. Mengganti referensi gambar fallback `no-image.png` yang tidak tersedia dengan gambar yang sudah ada.
9. Menjadikan `my-messages.php` sebagai rute kompatibilitas menuju card chat di `contact.php`.
10. Memindahkan file SQL ke folder `database/`.

## File yang dihapus
- `test_connection.php`: halaman uji koneksi database yang tidak diperlukan saat aplikasi berjalan.
- `users.php` di root proyek: halaman admin lama/duplikat dengan path relatif yang salah; halaman aktif berada di `admin/users.php`.
- `orders.php` di root proyek: halaman admin lama/duplikat dengan path relatif yang salah; halaman aktif berada di `admin/orders.php`.
- Folder `.git` tidak disertakan dalam ZIP distribusi. Riwayat Git lokal tidak diperlukan untuk menjalankan aplikasi.

## File dan data yang dipertahankan
- Semua gambar katalog dan aset desain.
- Semua file bukti pembayaran di `uploads/payment-proofs/`.
- Halaman dan fungsi utama katalog, keranjang, profil, checkout, pesanan, serta admin.
- `forgot-password.php` dipertahankan sebagai rute pengarah ke tab lupa password pada `login.php`.

## Cara memasang pada proyek yang sudah berjalan
1. Salin folder proyek lama sebagai backup.
2. Ekstrak ZIP hasil perbaikan ke folder sementara.
3. Backup database `sitik_bookstore` melalui phpMyAdmin > Export.
4. Salin file proyek hasil perbaikan untuk menggantikan kode lama. Jangan menghapus folder bukti pembayaran yang sudah ada; gabungkan/pindahkan file bukti lama bila diperlukan.
5. Pilih database `sitik_bookstore` di phpMyAdmin.
6. Jalankan `database/repair_existing_database.sql` melalui tab SQL.
7. Buka website dan lakukan pengujian manual.

## Skenario uji manual
- Login pelanggan, kirim pesan Contact, login admin, balas pesan, lalu pastikan balasan muncul pada card percakapan pelanggan.
- Kirim balasan lanjutan dari pelanggan dan pastikan badge unread admin bertambah; buka percakapan admin dan pastikan badge berkurang.
- Checkout COD: Pending -> Processing -> tombol Selesaikan + Konfirmasi COD -> Completed dan Paid.
- Checkout transfer: Unpaid -> upload bukti -> Waiting Verification -> admin verifikasi -> Verified -> Processing -> Completed.
- Batalkan pesanan Pending/Processing yang memenuhi syarat; pastikan stok kembali satu kali saja.
- Uji upload file bukti yang tidak diizinkan dan akses order milik akun lain.

## Batasan audit
Tidak ada klaim bahwa aplikasi sudah bebas dari seluruh runtime error. Koneksi database, struktur aktual database pengguna, hak akses file, dan perilaku browser harus diverifikasi melalui pengujian XAMPP. File migrasi harus dijalankan setelah backup.
