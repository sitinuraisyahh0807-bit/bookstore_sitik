<?php
session_start();
require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../config/book-functions.php";
require_once __DIR__ . "/../config/category-functions.php"; // Ini untuk memanggil kategori dropdown

// CEK LOGIN ADMIN
if(!isset($_SESSION["user_id"]) || $_SESSION["user_role"] !== "admin"){
    header("Location: ../login.php");
    exit;
}

$error_msg = "";
$category_error = "";

// Tangani penambahan kategori baru dari halaman Tambah Buku.
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["add_category"])) {
    $new_category = trim($_POST["new_category"] ?? "");

    if ($new_category === "") {
        $category_error = "Nama kategori tidak boleh kosong.";
    } elseif (mb_strlen($new_category) > 100) {
        $category_error = "Nama kategori maksimal 100 karakter.";
    } else {
        // Cek agar kategori dengan nama yang sama tidak dibuat dua kali.
        $check_category = $conn->prepare(
            "SELECT id FROM categories WHERE LOWER(name) = LOWER(?) LIMIT 1"
        );

        if (!$check_category) {
            $category_error = "Gagal memeriksa kategori. Silakan coba lagi.";
        } else {
            $check_category->bind_param("s", $new_category);
            $check_category->execute();
            $existing_category = $check_category->get_result()->fetch_assoc();
            $check_category->close();

            if ($existing_category) {
                $category_error = "Kategori tersebut sudah tersedia.";
            } else {
                $insert_category = $conn->prepare(
                    "INSERT INTO categories (name) VALUES (?)"
                );

                if (!$insert_category) {
                    $category_error = "Gagal menyiapkan penyimpanan kategori.";
                } else {
                    $insert_category->bind_param("s", $new_category);

                    if ($insert_category->execute()) {
                        $insert_category->close();
                        header("Location: add-book.php?category_added=1");
                        exit;
                    } else {
                        $category_error = "Kategori gagal disimpan: " . $insert_category->error;
                        $insert_category->close();
                    }
                }
            }
        }
    }
}

// Tangani proses penambahan buku yang sudah ada.
handleAddBook($conn, $error_msg);

// Ambil data kategori untuk dropdown
$category_options = getCategoryOptions($conn);

// CEK HALAMAN AKTIF UNTUK SIDEBAR
$current_page = basename($_SERVER['PHP_SELF']);
$is_menu_open = in_array($current_page, ['dashboard.php', 'users.php', 'categories.php', 'books.php', 'add-book.php', 'edit-book.php', 'orders.php']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Buku Baru - Admin S'itik Bookstore</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="../css/books.css">
</head>
<body>

<div class="admin-container">

<!-- SIDEBAR START -->
<aside class="sidebar">
    <div class="sidebar-logo">
        <img src="../images/logo-icon.png" alt="Logo">
        <div class="logo-text">
            <span class="logo-top">S'itik</span>
            <strong>BOOKSTORE</strong>
            <small>ADMIN PANEL</small>
        </div>
    </div>

    <div class="sidebar-menu">
        <div class="menu-title">MAIN MENU</div>
        <!-- Menambahkan class "open" otomatis jika $is_menu_open bernilai true -->
        <div class="menu-dropdown-container <?php echo $is_menu_open ? 'open' : ''; ?>" id="mainMenuContainer">
            
            <div class="menu-item-wrapper <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <a href="dashboard.php" class="menu-link">
                    ⌂ <span>Dashboard</span>
                </a>
                <span class="arrow-toggle" onclick="toggleMenu()">▼</span>
            </div>

            <ul class="submenu-list">
                <li><a href="users.php" class="submenu-item <?php echo ($current_page == 'users.php') ? 'active' : ''; ?>">Daftar User</a></li>
                <li><a href="categories.php" class="submenu-item <?php echo ($current_page == 'categories.php') ? 'active' : ''; ?>">Kategori Buku</a></li>
                <li><a href="books.php" class="submenu-item <?php echo ($current_page == 'books.php') ? 'active' : ''; ?>">Data Buku</a></li>
                <li><a href="add-book.php" class="submenu-item <?php echo ($current_page == 'add-book.php') ? 'active' : ''; ?>">Tambah Buku</a></li>
                <li><a href="orders.php" class="submenu-item <?php echo ($current_page == 'orders.php') ? 'active' : ''; ?>">Pesanan User</a></li>
                <li><a href="messages.php"class="submenu-item <?= ($current_page == 'messages.php') ? 'active' : ''; ?>">Pesan Masuk</a></li>
            </ul>
            
        </div>
    </div>

    <div class="sidebar-bottom">
        <a href="../logout.php" class="menu-item logout">
            → <span>Logout</span>
        </a>
    </div>
</aside>

<script>
function toggleMenu() {
    document.getElementById('mainMenuContainer').classList.toggle('open');
}
</script>
<!-- SIDEBAR END -->

<!-- MAIN CONTENT -->
<main class="main-content">
    <header class="admin-header">
        <div class="header-title">
            <h1>Tambah Buku Baru</h1>
            <p>Tambahkan koleksi buku baru ke dalam katalog toko.</p>
        </div>
        <div class="admin-profile">
            <div class="profile-avatar">A</div>
            <div class="profile-text">
                <strong>Administrator</strong>
                <span>Admin</span>
            </div>
        </div>
    </header>

    <div class="dashboard-content">
        <?php if(!empty($error_msg)): ?>
            <div class="alert-error">⚠ <?= htmlspecialchars($error_msg); ?></div>
        <?php endif; ?>

        <?php if(isset($_GET["category_added"]) && $_GET["category_added"] === "1"): ?>
            <div class="category-alert-success">✓ Kategori baru berhasil ditambahkan dan sudah tersedia pada pilihan kategori.</div>
        <?php endif; ?>

        <?php if(!empty($category_error)): ?>
            <div class="alert-error">⚠ <?= htmlspecialchars($category_error); ?></div>
        <?php endif; ?>

        <div class="add-category-card">
            <div class="add-category-heading">
                <div>
                    <h2>Tambah Kategori Baru</h2>
                    <p>Buat kategori baru tanpa meninggalkan halaman Tambah Buku.</p>
                </div>
                <span class="add-category-icon">＋</span>
            </div>

            <form action="add-book.php" method="POST" class="add-category-form">
                <div class="form-group">
                    <label for="new_category">Nama Kategori</label>
                    <input
                        type="text"
                        id="new_category"
                        name="new_category"
                        placeholder="Contoh: Sosiologi"
                        maxlength="100"
                        required
                    >
                </div>
                <button type="submit" name="add_category" value="1" class="btn-add-category">
                    + Tambah Kategori
                </button>
            </form>
        </div>

        <div class="add-book-card">
            <form action="add-book.php" method="POST" enctype="multipart/form-data" class="form-grid">
                
                <div class="form-group">
                    <label>Judul Buku *</label>
                    <input type="text" name="title" placeholder="Masukkan judul buku" required>
                </div>
                
                <div class="form-group">
                    <label>Penulis / Author *</label>
                    <input type="text" name="author" placeholder="Nama penulis buku" required>
                </div>
                
                <div class="form-group">
                    <label>Kategori Buku *</label>
                    <select name="category" required>
                        <option value="">-- Pilih Kategori --</option>
                        <?php if (isset($category_options) && $category_options && $category_options->num_rows > 0): ?>
                            <?php while($cat = $category_options->fetch_assoc()): ?>
                                <option value="<?= htmlspecialchars($cat['name']); ?>"><?= htmlspecialchars($cat['name']); ?></option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Harga (Rp) *</label>
                    <input type="number" name="price" placeholder="Contoh: 85000" min="0" required>
                </div>
                
                <div class="form-group">
                    <label>Jumlah Stok *</label>
                    <input type="number" name="stock" placeholder="Contoh: 20" min="0" required>
                </div>
                
                <div class="form-group">
                    <label>Cover Gambar</label>
                    <input type="file" name="image" accept="image/*">
                </div>

                <!-- Toggles Best Author & Best Pick dikembalikan -->
                <div class="form-group">
                    <label>Jadikan Best Author?</label>
                    <select name="is_best_author">
                        <option value="0">Bukan</option>
                        <option value="1">⭐ Ya</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Jadikan Best Pick?</label>
                    <select name="is_best_pick">
                        <option value="0">Bukan</option>
                        <option value="1">⭐ Ya</option>
                    </select>
                </div>

                <div class="form-group full-width">
                    <label>Deskripsi / Sinopsis Buku</label>
                    <textarea name="description" placeholder="Tuliskan sinopsis singkat mengenai buku ini..."></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="submit" name="add_book" class="btn-submit-book">+ Simpan Buku</button>
                </div>
                
            </form>
        </div>
    </div>
</main>
<!-- MAIN CONTENT END -->

</div>
</body>
</html>