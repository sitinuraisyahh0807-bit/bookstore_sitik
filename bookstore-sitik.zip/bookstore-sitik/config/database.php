<?php
// Konfigurasi koneksi database S'itik Bookstore.
$host = getenv('DB_HOST') ?: 'localhost';
$username = getenv('DB_USER') ?: 'root';
$password = getenv('DB_PASS') ?: '';
$database = getenv('DB_NAME') ?: 'sitik_bookstore';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $conn = new mysqli($host, $username, $password, $database);
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $error) {
    error_log('Database connection failed: ' . $error->getMessage());
    http_response_code(500);
    exit('Koneksi database gagal. Periksa konfigurasi database atau hubungi administrator.');
}
