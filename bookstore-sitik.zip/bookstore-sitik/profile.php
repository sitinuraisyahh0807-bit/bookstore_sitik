<?php
session_start();
require_once __DIR__ . "/config/database.php";
require_once __DIR__ . "/config/profile-functions.php"; // Memanggil file fungsi profil

// Jika user belum login, lempar ke halaman login
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION["user_id"];

// Panggil fungsi yang sudah dipisah
$user_data = getUserData($conn, $user_id);
$orders = getUserOrders($conn, $user_id);

if (isset($_SESSION["user_role"]) && $_SESSION["user_role"] === "admin") {
    header("Location: admin/dashboard.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya - S'itik Bookstore</title>
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/profile.css">
</head>
<body class="home-page">

<!-- NAVBAR -->
<header class="site-navbar">
    <a class="site-logo" href="home.php" aria-label="S'itik Bookstore Home">
        <img src="images/logo-icon.png" alt="S'itik Bookstore logo">
        <span class="site-logo-text">
            <span class="top">S’itik</span>
            <span class="bottom">BOOKSTORE</span>
        </span>
    </a>
    <nav class="site-nav" aria-label="Main navigation">
        <a href="home.php">Home</a>
        <a href="cart.php">Cart</a>
        <a href="about-us.php">About Us</a>
        <a href="contact.php">Contact</a>
        <a href="profile.php" style="color: #4a5c46; font-weight: bold;">👤 <?php echo htmlspecialchars($user_data['name']); ?></a>
        <a href="logout.php" class="signin-link">Logout</a>
    </nav>
</header>

<main class="profile-container">
    <div class="profile-header">
        <div class="profile-avatar">
            <?php echo strtoupper(substr($user_data['name'] ?? 'U', 0, 1)); ?>
        </div>
        <div>
            <h1 style="margin: 0; font-size: 24px; color: #fff;"><?php echo htmlspecialchars($user_data['name']); ?></h1>
            <p style="margin: 5px 0 0; opacity: 0.9;">Member S'itik Bookstore</p>
        </div>
    </div>

    <div class="order-history">
        <h2>Riwayat & Detail Pesanan Saya</h2>
        
        <?php if (empty($orders)): ?>
            <div class="no-orders">
                <p>Belum ada pesanan yang dibuat.</p>
                <a href="home.php#explore-books" style="color: #5A7156; text-decoration: underline;">Mulai Belanja Buku</a>
            </div>
        <?php else: ?>
            <?php foreach ($orders as $order): ?>
                <div class="order-card" style="flex-direction: column; align-items: stretch; gap: 15px;">
                    
                    <!-- Bagian Atas: ID & Waktu -->
                    <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #d9d0c3; padding-bottom: 10px;">
                        <div>
                            <strong>ID Pesanan: #<?php echo (int)$order['id']; ?></strong>
                            <div style="font-size: 13px; color: #777; margin-top: 2px;">Waktu: <?php echo htmlspecialchars($order['created_at']); ?></div>
                        </div>
                        <div>
                            <div>
                            <?php 
                                $status_raw = $order['order_status'] ?? 'Pending';
                                $status_class = strtolower(str_replace(' ', '-', trim($status_raw)));
                            ?>
                            <span class="order-status <?php echo htmlspecialchars($status_class); ?>">
                                Status: <?php echo htmlspecialchars($status_raw); ?>
                            </span>
                            </div>
                        </div>
                    </div>

                    <!-- Bagian Tengah: Detail Informasi Pengiriman & Pembayaran -->
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 15px; font-size: 14px; color: #333;">
                        <div>
                            <p style="margin: 4px 0;"><strong>Nama Penerima:</strong> <?php echo htmlspecialchars($order['customer_name']); ?></p>
                            <p style="margin: 4px 0;"><strong>No. Telepon:</strong> <?php echo htmlspecialchars($order['customer_phone']); ?></p>
                            <p style="margin: 4px 0;"><strong>Alamat:</strong> <?php echo htmlspecialchars($order['customer_address']); ?></p>
                        </div>
                        <div>
                            <p style="margin: 4px 0;">
    <strong>Metode Bayar:</strong> 
    <?php 
        $method = $order['payment_method'] ?? '';
        echo htmlspecialchars($method);
        
        // Menambahkan nomor rekening langsung di sampingnya
        if ($method === 'Transfer BCA') {
            echo ' (1234-5678-9012)';
        } elseif ($method === 'Transfer Mandiri') {
            echo ' (9876-5432-1098)';
        } elseif ($method === 'E-Wallet DANA') {
            echo ' (0812-1111-2222)';
        } elseif ($method === 'E-Wallet OVO') {
            echo ' (0812-3333-4444)';
        } elseif ($method === 'E-Wallet GoPay') {
            echo ' (0812-5555-6666)';
        } elseif ($method === 'E-Wallet ShopeePay') {
            echo ' (0812-7777-8888)';
        }
    ?>
</p>

                            <?php
                                $payment_status = $order['payment_status'] ?? 'Unpaid';
                                $payment_status_lower = strtolower(trim($payment_status));
                                $payment_color = '#d9534f';
                                if (in_array($payment_status_lower, ['paid', 'verified'], true)) {
                                    $payment_color = '#287a45';
                                } elseif ($payment_status_lower === 'waiting verification') {
                                    $payment_color = '#a66b00';
                                } elseif ($payment_status_lower === 'pay on delivery') {
                                    $payment_color = '#356b9a';
                                }
                            ?>
                            <p style="margin: 4px 0;"><strong>Status Pembayaran:</strong> <span style="color: <?php echo $payment_color; ?>; font-weight: bold;"><?php echo htmlspecialchars($payment_status); ?></span></p>
                            <p style="margin: 4px 0;"><strong>Subtotal:</strong> Rp <?php echo number_format((int)$order['subtotal'], 0, ',', '.'); ?></p>
                            <p style="margin: 4px 0;"><strong>Ongkir:</strong> Rp <?php echo number_format((int)$order['shipping_fee'], 0, ',', '.'); ?></p>
                        </div>
                    </div>

                    <!-- Bagian Bawah: Total Bayar & Bukti Transfer -->
                    <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #d9d0c3; padding-top: 10px; margin-top: 5px;">
                        <div>
                            <span style="font-size: 16px; font-weight: bold; color: #4b3524;">
                                Total Amount: Rp <?php echo number_format((int)$order['total_amount'], 0, ',', '.'); ?>
                            </span>
                        </div>
                        <div>
                            <?php if (!empty($order['payment_proof'])): ?>
                                <?php 
                                    $proof_path = $order['payment_proof'];
                                    if (!preg_match("~^(?:f|ht)tps?://~i", $proof_path) && strpos($proof_path, '/') !== 0) {
                                        $proof_path = $proof_path; 
                                    }
                                ?>
                                <a href="<?php echo htmlspecialchars($proof_path); ?>" target="_blank" style="background-color: #6a7c64; color: white; padding: 6px 12px; border-radius: 6px; text-decoration: none; font-size: 13px;">
                                     Lihat Bukti Transfer
                                </a>
                            <?php else: ?>
                                <?php if (strtolower(trim($order['payment_method'] ?? '')) === 'cash on delivery'): ?>
                                    <span style="font-size: 13px; color: #356b9a; font-style: italic;">Bukti transfer tidak diperlukan (COD)</span>
                                <?php else: ?>
                                    <span style="font-size: 13px; color: #888; font-style: italic;">Belum ada bukti transfer</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</main>

</body>
</html>