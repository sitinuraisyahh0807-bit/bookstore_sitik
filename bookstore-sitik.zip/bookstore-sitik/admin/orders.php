
<?php
session_start();

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../config/order-admin-functions.php";

// ==========================================
// CEK LOGIN DAN HAK AKSES ADMIN
// ==========================================

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if (!isset($_SESSION["user_role"]) || $_SESSION["user_role"] !== "admin") {
    header("Location: ../home.php");
    exit;
}

if (empty($_SESSION["orders_csrf"])) {
    $_SESSION["orders_csrf"] = bin2hex(random_bytes(32));
}

// ==========================================
// FUNGSI ESCAPE HTML
// ==========================================

function escapeHtml($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}

// ==========================================
// UPDATE STATUS PESANAN
// ==========================================

$message = "";

handleVerifyOrderPayment($conn, $message);
handleUpdateOrderStatus($conn, $message);

// Ambil seluruh data pesanan
$orders = getAllOrders($conn);

// ==========================================
// PENGATURAN SIDEBAR
// ==========================================

$current_page = basename($_SERVER["PHP_SELF"]);

$is_menu_open = in_array($current_page, [
    "dashboard.php",
    "categories.php",
    "books.php",
    "add-book.php",
    "edit-book.php",
    "orders.php"
]);

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Pesanan User - Admin S'itik Bookstore</title>

    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="../css/orders.css">
</head>

<body>

<div class="admin-container">

    <!-- ==================================
         SIDEBAR
    =================================== -->

    <aside class="sidebar">

        <!-- LOGO -->
        <div class="sidebar-logo">

            <img src="../images/logo-icon.png" alt="Logo">

            <div class="logo-text">
                <span class="logo-top">S'itik</span>
                <strong>BOOKSTORE</strong>
                <small>ADMIN PANEL</small>
            </div>

        </div>

        <!-- MENU UTAMA -->
        <div class="sidebar-menu">

            <div class="menu-title">MAIN MENU</div>

            <div
                class="menu-dropdown-container <?= $is_menu_open ? 'open' : ''; ?>"
                id="mainMenuContainer"
            >

                <!-- DASHBOARD -->
                <div class="menu-item-wrapper <?= ($current_page == 'dashboard.php') ? 'active' : ''; ?>">

                    <a href="dashboard.php" class="menu-link">
                        ⌂ <span>Dashboard</span>
                    </a>

                    <span class="arrow-toggle" onclick="toggleMenu()">
                        ▼
                    </span>

                </div>

                <!-- SUBMENU -->
                <ul class="submenu-list">

                    <li>
                        <a href="users.php"
                           class="submenu-item <?= ($current_page == 'users.php') ? 'active' : ''; ?>">
                            Daftar User
                        </a>
                    </li>

                    <li>
                        <a href="categories.php"
                           class="submenu-item <?= ($current_page == 'categories.php') ? 'active' : ''; ?>">
                            Kategori Buku
                        </a>
                    </li>

                    <li>
                        <a href="books.php"
                           class="submenu-item <?= ($current_page == 'books.php') ? 'active' : ''; ?>">
                            Data Buku
                        </a>
                    </li>

                    <li>
                        <a href="add-book.php"
                           class="submenu-item <?= ($current_page == 'add-book.php') ? 'active' : ''; ?>">
                            Tambah Buku
                        </a>
                    </li>

                    <li>
                        <a href="orders.php"
                           class="submenu-item <?= ($current_page == 'orders.php') ? 'active' : ''; ?>">
                            Pesanan User
                        </a>
                    </li>

                    <li>
    <a href="messages.php"
       class="submenu-item <?= ($current_page == 'messages.php') ? 'active' : ''; ?>">
        Pesan Masuk
    </a>
</li>

                </ul>

            </div>

        </div>

        <!-- LOGOUT -->
        <div class="sidebar-bottom">

            <a href="../logout.php" class="menu-item logout">
                → <span>Logout</span>
            </a>

        </div>

    </aside>

    <!-- SCRIPT SIDEBAR -->
    <script>
        function toggleMenu() {
            document
                .getElementById("mainMenuContainer")
                .classList.toggle("open");
        }
    </script>

    <!-- ==================================
         MAIN CONTENT
    =================================== -->

    <main class="main-content">

        <!-- HEADER -->
        <header class="admin-header">

            <div class="header-title">

                <h1>Pesanan User</h1>

                <p>
                    Pantau pesanan pelanggan, metode pembayaran,
                    bukti transfer, dan status pengiriman.
                </p>

            </div>

            <div class="admin-profile">

                <div class="profile-avatar">A</div>

                <div class="profile-text">
                    <strong>Administrator</strong>
                    <span>Admin</span>
                </div>

            </div>

        </header>

        <!-- ==================================
             DAFTAR PESANAN
        =================================== -->

        <div class="dashboard-content">

            <!-- NOTIFIKASI -->
            <?= $message; ?>

            <div class="orders-box">

                <table class="orders-table">

                    <thead>
                        <tr>
                            <th>ID PESANAN</th>
                            <th>PELANGGAN</th>
                            <th>TANGGAL</th>
                            <th>TOTAL</th>
                            <th>METODE PEMBAYARAN</th>
                            <th>BUKTI TF</th>
                            <th>STATUS PEMBAYARAN</th>
                            <th>STATUS PESANAN</th>
                            <th>UPDATE STATUS</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php if ($orders && $orders->num_rows > 0): ?>

                            <?php while ($order = $orders->fetch_assoc()): ?>

                                <?php

                                // ==================================
                                // DATA PESANAN
                                // ==================================

                                $order_id = (int) $order["id"];

                                $customer_name = $order["customer_name"] ?? "User";

                                $created_at = $order["created_at"] ?? null;

                                $total_amount = (float) ($order["total_amount"] ?? 0);


                                // ==================================
                                // METODE PEMBAYARAN
                                // ==================================

                                $payment_method = trim(
                                    $order["payment_method"] ?? ""
                                );

                                $method_lower = strtolower($payment_method);

                                // Deteksi COD
                                $is_cod = (
                                    strpos($method_lower, "cod") !== false ||
                                    strpos($method_lower, "cash on delivery") !== false ||
                                    strpos($method_lower, "pay on delivery") !== false ||
                                    strpos($method_lower, "bayar di tempat") !== false
                                );

                                // Tentukan warna metode pembayaran
                                $payment_class = "payment-default";

                                if ($is_cod) {

                                    $payment_class = "payment-cod";

                                } elseif (strpos($method_lower, "bca") !== false) {

                                    $payment_class = "payment-bca";

                                } elseif (strpos($method_lower, "mandiri") !== false) {

                                    $payment_class = "payment-mandiri";

                                } elseif (strpos($method_lower, "ovo") !== false) {

                                    $payment_class = "payment-ovo";

                                } elseif (strpos($method_lower, "dana") !== false) {

                                    $payment_class = "payment-dana";

                                } elseif (strpos($method_lower, "gopay") !== false) {

                                    $payment_class = "payment-gopay";

                                } elseif (strpos($method_lower, "shopeepay") !== false) {

                                    $payment_class = "payment-shopeepay";

                                } elseif (strpos($method_lower, "e-wallet") !== false) {

                                    $payment_class = "payment-ewallet";

                                }


                                // ==================================
                                // BUKTI PEMBAYARAN
                                // ==================================

                                $proof_path = $order["payment_proof"] ?? "";

                                $has_proof = !empty($proof_path);

                                $proof_extension = $has_proof
                                    ? strtolower(pathinfo($proof_path, PATHINFO_EXTENSION))
                                    : "";


                                // ==================================
                                // STATUS PESANAN
                                // ==================================

                                $status = strtolower(
                                    $order["order_status"] ?? "pending"
                                );

                                $status_labels = [
                                    "pending" => "Pending",
                                    "processing" => "Processing",
                                    "completed" => "Completed",
                                    "cancelled" => "Cancelled"
                                ];

                                $status_classes = [
                                    "pending" => "badge-pending",
                                    "processing" => "badge-processing",
                                    "completed" => "badge-completed",
                                    "cancelled" => "badge-cancelled"
                                ];

                                $status_label = $status_labels[$status] ?? ucfirst($status);

                                $badge_class = $status_classes[$status] ?? "badge-pending";

                                ?>

                                <tr>

                                    <!-- ID PESANAN -->
                                    <td>
                                        <strong>
                                            #ORD-<?= $order_id; ?>
                                        </strong>
                                    </td>

                                    <!-- PELANGGAN -->
                                    <td>
                                        <?= escapeHtml($customer_name); ?>
                                    </td>

                                    <!-- TANGGAL -->
                                    <td>
                                        <?= $created_at
                                            ? date("d M Y H:i", strtotime($created_at))
                                            : "-"; ?>
                                    </td>

                                    <!-- TOTAL -->
                                    <td style="color: #6d855e; font-weight: bold;">

                                        Rp <?= number_format(
                                            $total_amount,
                                            0,
                                            ",",
                                            "."
                                        ); ?>

                                    </td>

                                    <!-- METODE PEMBAYARAN -->
                                    <td>

                                        <?php if (!empty($payment_method)): ?>

                                            <span class="payment-badge <?= $payment_class; ?>">
                                                <?= escapeHtml($payment_method); ?>
                                            </span>

                                        <?php else: ?>

                                            <span class="no-proof">
                                                Belum ditentukan
                                            </span>

                                        <?php endif; ?>

                                    </td>

                                    <!-- BUKTI PEMBAYARAN -->
                                    <td>

                                        <?php if ($is_cod): ?>

                                            <span class="no-proof">
                                                Tidak diperlukan
                                            </span>

                                        <?php elseif ($has_proof): ?>

                                            <a
                                                href="../<?= escapeHtml($proof_path); ?>"
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                title="Lihat bukti pembayaran"
                                            >

                                                <?php if ($proof_extension === "pdf"): ?>

                                                    <span style="
                                                        display: inline-block;
                                                        padding: 12px;
                                                        background: #f4e8e8;
                                                        border-radius: 8px;
                                                        color: #b33;
                                                        font-weight: bold;
                                                    ">
                                                        📄 Lihat PDF
                                                    </span>

                                                <?php else: ?>

                                                    <img
                                                        src="../<?= escapeHtml($proof_path); ?>"
                                                        class="proof-img"
                                                        alt="Bukti pembayaran"
                                                    >

                                                <?php endif; ?>

                                            </a>

                                        <?php else: ?>

                                            <span class="no-proof">
                                                Belum ada bukti
                                            </span>

                                        <?php endif; ?>

                                    </td>

                                    <!-- STATUS PEMBAYARAN -->
                                    <td>
                                        <?php
                                        $payment_status = $order["payment_status"] ?? "Unpaid";
                                        $payment_status_lower = strtolower(trim($payment_status));
                                        $payment_status_class = "payment-status-unpaid";

                                        if ($payment_status_lower === "verified" || $payment_status_lower === "paid") {
                                            $payment_status_class = "payment-status-paid";
                                        } elseif ($payment_status_lower === "waiting verification") {
                                            $payment_status_class = "payment-status-waiting";
                                        } elseif ($payment_status_lower === "pay on delivery") {
                                            $payment_status_class = "payment-status-cod";
                                        } elseif ($payment_status_lower === "cancelled") {
                                            $payment_status_class = "payment-status-cancelled";
                                        }
                                        ?>

                                        <span class="payment-status-badge <?= $payment_status_class; ?>">
                                            <?= escapeHtml($payment_status); ?>
                                        </span>

                                        <?php if (!$is_cod && $payment_status_lower === "waiting verification" && $has_proof && $status === "pending"): ?>
                                            <form action="orders.php" method="POST" style="margin-top:8px;">
                                                <input type="hidden" name="csrf_token" value="<?= escapeHtml($_SESSION['orders_csrf']); ?>">
                                                <input type="hidden" name="order_id" value="<?= $order_id; ?>">
                                                <button type="submit" name="verify_payment" class="btn-update">
                                                    Verifikasi
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </td>

                                    <!-- STATUS PESANAN -->
                                    <td>
                                        <span class="badge <?= $badge_class; ?>">
                                            <?= escapeHtml($status_label); ?>
                                        </span>
                                    </td>

                                    <!-- UPDATE STATUS -->
                                    <td>

                                        <form
                                            action="orders.php"
                                            method="POST"
                                            class="status-form"
                                        >

                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?= escapeHtml($_SESSION['orders_csrf']); ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="order_id"
                                                value="<?= $order_id; ?>"
                                            >

                                            <select
                                                name="order_status"
                                                class="status-select"
                                            >

                                                <option
                                                    value="pending"
                                                    <?= ($status == "pending") ? "selected" : ""; ?>
                                                >
                                                    Pending
                                                </option>

                                                <option
                                                    value="processing"
                                                    <?= ($status == "processing") ? "selected" : ""; ?>
                                                >
                                                    Processing
                                                </option>

                                                <option
                                                    value="completed"
                                                    <?= ($status == "completed") ? "selected" : ""; ?>
                                                >
                                                    Completed
                                                </option>

                                                <option
                                                    value="cancelled"
                                                    <?= ($status == "cancelled") ? "selected" : ""; ?>
                                                >
                                                    Cancelled
                                                </option>

                                            </select>

                                            <button
                                                type="submit"
                                                name="update_status"
                                                class="btn-update"
                                                <?= ($is_cod && $status === "processing") ? 'title="Mengonfirmasi barang diterima dan pembayaran COD sudah diterima"' : ''; ?>
                                            >
                                                <?= ($is_cod && $status === "processing") ? 'Selesaikan + Konfirmasi COD' : 'Update'; ?>
                                            </button>

                                        </form>

                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>
                                <td
                                    colspan="9"
                                    style="
                                        text-align: center;
                                        padding: 40px;
                                        color: #777;
                                    "
                                >
                                    Belum ada pesanan masuk.
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </main>

</div>

</body>
</html>
