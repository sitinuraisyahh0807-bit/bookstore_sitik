
<?php
session_start();

require_once __DIR__ . "/../config/database.php";

// CEK LOGIN ADMIN
if (
    !isset($_SESSION["user_id"]) ||
    ($_SESSION["user_role"] ?? "") !== "admin"
) {
    header("Location: ../login.php");
    exit;
}

$admin_id = (int) $_SESSION["user_id"];
$message_id = (int) ($_GET["id"] ?? $_POST["message_id"] ?? 0);

if ($message_id <= 0) {
    header("Location: messages.php");
    exit;
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

// TOKEN CSRF
if (empty($_SESSION["reply_csrf"])) {
    $_SESSION["reply_csrf"] = bin2hex(random_bytes(32));
}

$error = "";

// AMBIL PESAN PELANGGAN
$stmt = $conn->prepare("
    SELECT *
    FROM contact_messages
    WHERE id = ?
    LIMIT 1
");

$stmt->bind_param("i", $message_id);
$stmt->execute();
$contact = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$contact) {
    header("Location: messages.php");
    exit;
}

// PROSES BALASAN ADMIN
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["send_reply"])) {

    $token = $_POST["csrf_token"] ?? "";
    $reply = trim($_POST["reply"] ?? "");

    if (!hash_equals($_SESSION["reply_csrf"], $token)) {
        $error = "Sesi tidak valid. Muat ulang halaman.";
    } elseif ($reply === "") {
        $error = "Balasan tidak boleh kosong.";
    } elseif (mb_strlen($reply) > 5000) {
        $error = "Balasan maksimal 5.000 karakter.";
    } else {

        $sender_role = "admin";

        $stmt = $conn->prepare("
            INSERT INTO contact_replies
            (message_id, sender_id, sender_role, reply)
            VALUES (?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "iiss",
            $message_id,
            $admin_id,
            $sender_role,
            $reply
        );

        if ($stmt->execute()) {
            $stmt->close();

            header("Location: message-detail.php?id=" . $message_id . "&sent=1");
            exit;
        } else {
            $error = "Balasan gagal dikirim.";
            $stmt->close();
        }
    }
}

// TANDAI PESAN SUDAH DIBACA
$stmt = $conn->prepare("
    UPDATE contact_messages
    SET is_read = 1
    WHERE id = ?
");
$stmt->bind_param("i", $message_id);
$stmt->execute();
$stmt->close();

// Tandai semua balasan pelanggan sebagai sudah dibaca ketika admin membuka percakapan.
$stmt = $conn->prepare("
    UPDATE contact_replies
    SET is_read = 1
    WHERE message_id = ?
      AND sender_role = 'user'
");
$stmt->bind_param("i", $message_id);
$stmt->execute();
$stmt->close();

// AMBIL RIWAYAT BALASAN
$stmt = $conn->prepare("
    SELECT r.*, u.name AS sender_name
    FROM contact_replies r
    LEFT JOIN users u ON r.sender_id = u.id
    WHERE r.message_id = ?
    ORDER BY r.created_at ASC, r.id ASC
");

$stmt->bind_param("i", $message_id);
$stmt->execute();
$replies = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Percakapan Pelanggan</title>

<link rel="stylesheet" href="../css/admin.css">

<style>
body {
    background: #faf6ee;
    color: #354231;
    font-family: Georgia, serif;
}

.conversation-page {
    max-width: 950px;
    margin: 35px auto;
    padding: 20px;
}

.back-link {
    display: inline-block;
    margin-bottom: 20px;
    color: #566b50;
    text-decoration: none;
    font-weight: bold;
}

.chat-card {
    background: white;
    border: 1px solid #e8e5dc;
    border-radius: 14px;
    padding: 24px;
    margin-bottom: 20px;
}

.chat-card h2,
.chat-card h3 {
    color: #566b50;
}

.customer-info p {
    margin: 8px 0;
}

.chat-list {
    display: flex;
    flex-direction: column;
    gap: 18px;
    margin-top: 20px;
}

.chat-message {
    max-width: 75%;
    padding: 15px 18px;
    border-radius: 13px;
    line-height: 1.6;
    overflow-wrap: anywhere;
}

.chat-message.customer {
    align-self: flex-start;
    background: #edf0df;
    color: #354231;
}

.chat-message.admin {
    align-self: flex-end;
    background: #71836b;
    color: white;
}

.chat-message small {
    display: block;
    margin-top: 8px;
    font-size: 11px;
    opacity: .75;
}

.reply-form textarea {
    width: 100%;
    min-height: 130px;
    padding: 14px;
    border: 1px solid #d9d5c9;
    border-radius: 9px;
    font: inherit;
    box-sizing: border-box;
    resize: vertical;
}

.reply-form button {
    margin-top: 12px;
    padding: 13px 22px;
    border: none;
    border-radius: 8px;
    background: #71836b;
    color: white;
    font-weight: bold;
    cursor: pointer;
}

.reply-form button:hover {
    background: #566b50;
}

.notice {
    padding: 13px;
    background: #e5f2e5;
    color: #315f35;
    border-radius: 8px;
    margin-bottom: 15px;
}

.notice.error {
    background: #fbe8e6;
    color: #a3332b;
}

@media(max-width:600px) {
    .chat-message {
        max-width: 92%;
    }
}
</style>
</head>

<body>

<div class="conversation-page">

<a href="messages.php" class="back-link">
    ← Kembali ke Pesan Masuk
</a>

<div class="chat-card customer-info">

    <h2>Percakapan Pelanggan</h2>

    <p><strong>Nama:</strong> <?= e($contact["name"]); ?></p>
    <p><strong>Email:</strong> <?= e($contact["email"]); ?></p>
    <p><strong>Subjek:</strong> <?= e($contact["subject"]); ?></p>
    <p><strong>Tanggal:</strong>
        <?= date("d-m-Y H:i", strtotime($contact["created_at"])); ?>
    </p>

</div>

<?php if (isset($_GET["sent"])): ?>
    <div class="notice">Balasan berhasil dikirim!</div>
<?php endif; ?>

<?php if ($error !== ""): ?>
    <div class="notice error"><?= e($error); ?></div>
<?php endif; ?>

<div class="chat-card">

    <h3>Riwayat Percakapan</h3>

    <div class="chat-list">

        <!-- PESAN PERTAMA PELANGGAN -->

        <div class="chat-message customer">

            <strong><?= e($contact["name"]); ?> (Pelanggan)</strong>

            <div>
                <?= nl2br(e($contact["message"])); ?>
            </div>

            <small>
                <?= date("d-m-Y H:i", strtotime($contact["created_at"])); ?>
            </small>

        </div>

        <!-- RIWAYAT BALASAN -->

        <?php foreach ($replies as $item): ?>

            <div class="chat-message <?= $item["sender_role"] === "admin" ? "admin" : "customer"; ?>">

                <strong>
                    <?= $item["sender_role"] === "admin"
                        ? "Administrator"
                        : e($item["sender_name"] ?: $contact["name"]); ?>
                </strong>

                <div>
                    <?= nl2br(e($item["reply"])); ?>
                </div>

                <small>
                    <?= date("d-m-Y H:i", strtotime($item["created_at"])); ?>
                </small>

            </div>

        <?php endforeach; ?>

    </div>

</div>

<div class="chat-card">

    <h3>Balas Pesan</h3>

    <form method="POST" class="reply-form">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= e($_SESSION["reply_csrf"]); ?>"
        >

        <input
            type="hidden"
            name="message_id"
            value="<?= $message_id; ?>"
        >

        <textarea
            name="reply"
            maxlength="5000"
            placeholder="Tuliskan balasan kepada pelanggan..."
            required
        ></textarea>

        <button type="submit" name="send_reply">
            Kirim Balasan
        </button>

    </form>

</div>

</div>

</body>
</html>
