<?php
session_start();

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if (($_SESSION["user_role"] ?? "") !== "user") {
    header("Location: ../admin/dashboard.php");
    exit;
}

$user_id = (int) $_SESSION["user_id"];
$stmt = $conn->prepare("SELECT name, email, status FROM users WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    session_destroy();
    header("Location: ../login.php");
    exit;
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Akun Saya - S'itik Bookstore</title>
    <link rel="stylesheet" href="../css/base.css">
    <style>
        body { background:#faf6ee; color:#354231; }
        .account-card { max-width:760px; margin:55px auto; padding:32px; background:#fffdf9; border:1px solid #e7dfd2; border-radius:16px; }
        .account-card h1 { color:#566b50; margin-top:0; }
        .account-row { padding:14px 0; border-bottom:1px solid #eee9df; }
        .account-row:last-child { border-bottom:0; }
        .account-row strong { display:block; margin-bottom:5px; }
        .account-links { display:flex; flex-wrap:wrap; gap:12px; margin-top:24px; }
        .account-links a { color:#fff; background:#71836b; padding:10px 16px; border-radius:8px; text-decoration:none; }
        .account-links a:hover { background:#566b50; }
    </style>
</head>
<body>
<header class="site-navbar">
    <a class="site-logo" href="../home.php">
        <img src="../images/logo-icon.png" alt="S'titik Bookstore Logo">
        <span class="site-logo-text"><span class="top">S’itik</span><span class="bottom">BOOKSTORE</span></span>
    </a>
    <nav class="site-nav">
        <a href="../home.php">Home</a>
        <a href="../cart.php">Cart</a>
        <a href="../about-us.php">About Us</a>
        <a href="../contact.php">Contact</a>
        <a href="../logout.php" class="signin-link">Logout</a>
    </nav>
</header>

<main class="account-card">
    <h1>Akun Saya</h1>
    <p>Informasi akun pelanggan S'itik Bookstore.</p>

    <div class="account-row"><strong>Nama</strong><?= e($user["name"]); ?></div>
    <div class="account-row"><strong>Email</strong><?= e($user["email"]); ?></div>
    <div class="account-row"><strong>Status Akun</strong><?= e($user["status"]); ?></div>

    <div class="account-links">
        <a href="../profile.php">Edit Profil</a>
        <a href="../profile.php">Riwayat Pesanan</a>
        <a href="../contact.php#contact-chat">Pesan Admin</a>
    </div>
</main>
</body>
</html>
