<?php
// config/profile-functions.php

// Fungsi untuk mengambil data profil user berdasarkan ID
function getUserData($conn, $user_id) {
    $stmt = $conn->prepare("SELECT name FROM users WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $data;
}

// Fungsi untuk mengambil riwayat pesanan (orders) milik user tersebut
function getUserOrders($conn, $user_id) {
    $stmt = $conn->prepare("SELECT id, customer_name, customer_phone, customer_address, payment_method, payment_proof, payment_status, subtotal, shipping_fee, total_amount, order_status, created_at FROM orders WHERE user_id = ? ORDER BY id DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $orders = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    return $orders;
}
?>