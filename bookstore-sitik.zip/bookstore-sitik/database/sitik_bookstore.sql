-- S'itik Bookstore - skema database yang selaras dengan aplikasi
-- Backup database lama sebelum mengimpor file ini.
CREATE DATABASE IF NOT EXISTS sitik_bookstore CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sitik_bookstore;

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role ENUM('admin','user') NOT NULL DEFAULT 'user',
 status ENUM('Aktif','Nonaktif') NOT NULL DEFAULT 'Aktif',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS books (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(255) NOT NULL,
 author VARCHAR(255) NOT NULL,
 category VARCHAR(100) NOT NULL,
 price INT UNSIGNED NOT NULL DEFAULT 0,
 stock INT UNSIGNED NOT NULL DEFAULT 0,
 image VARCHAR(255) DEFAULT NULL,
 description TEXT DEFAULT NULL,
 is_best_author TINYINT(1) NOT NULL DEFAULT 0,
 is_best_pick TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_books_category(category),
 INDEX idx_books_title(title)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS cart (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 book_id INT NOT NULL,
 quantity INT UNSIGNED NOT NULL DEFAULT 1,
 UNIQUE KEY uq_cart_user_book(user_id,book_id),
 CONSTRAINT fk_cart_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 CONSTRAINT fk_cart_book FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS bank_accounts (
 id INT AUTO_INCREMENT PRIMARY KEY,
 bank_name VARCHAR(50) NOT NULL,
 account_number VARCHAR(50) NOT NULL,
 account_name VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 customer_name VARCHAR(255) NOT NULL,
 customer_phone VARCHAR(40) NOT NULL,
 customer_address TEXT NOT NULL,
 payment_method VARCHAR(60) NOT NULL,
 subtotal INT UNSIGNED NOT NULL DEFAULT 0,
 shipping_fee INT UNSIGNED NOT NULL DEFAULT 0,
 total_amount INT UNSIGNED NOT NULL DEFAULT 0,
 payment_proof VARCHAR(255) DEFAULT NULL,
 payment_status VARCHAR(40) NOT NULL DEFAULT 'Unpaid',
 order_status ENUM('pending','processing','completed','cancelled') NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_orders_user(user_id),
 INDEX idx_orders_status(order_status),
 CONSTRAINT fk_orders_user FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
 id INT AUTO_INCREMENT PRIMARY KEY,
 order_id INT NOT NULL,
 book_id INT NOT NULL,
 quantity INT UNSIGNED NOT NULL,
 price INT UNSIGNED NOT NULL,
 line_total INT UNSIGNED NOT NULL,
 CONSTRAINT fk_items_order FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
 CONSTRAINT fk_items_book FOREIGN KEY(book_id) REFERENCES books(id)
) ENGINE=InnoDB;

INSERT INTO users(name,email,password,role,status)
SELECT 'Administrator','admin@sitikbookstore.local','$2y$12$qc0PeUH23rhh/XtLtpABOuNvaEHRHrrPU72hopvZuqZ1Lec60.ulu','admin','Aktif'
WHERE NOT EXISTS (SELECT 1 FROM users WHERE email='admin@sitikbookstore.local');

INSERT INTO bank_accounts(bank_name,account_number,account_name)
SELECT 'BCA','1234567890','S-itik Bookstore'
WHERE NOT EXISTS (SELECT 1 FROM bank_accounts WHERE bank_name='BCA');


-- Pesan Contact to Admin
CREATE TABLE IF NOT EXISTS contact_messages (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NULL,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(150) NOT NULL,
 subject VARCHAR(150) NOT NULL,
 message TEXT NOT NULL,
 is_read TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_contact_user(user_id),
 INDEX idx_contact_read_created(is_read, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Balasan percakapan pelanggan dan admin
CREATE TABLE IF NOT EXISTS contact_replies (
 id INT AUTO_INCREMENT PRIMARY KEY,
 message_id INT NOT NULL,
 sender_id INT NOT NULL,
 sender_role ENUM('admin','user') NOT NULL,
 reply TEXT NOT NULL,
 is_read TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_replies_message(message_id, created_at, id),
 INDEX idx_replies_unread(sender_role, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
