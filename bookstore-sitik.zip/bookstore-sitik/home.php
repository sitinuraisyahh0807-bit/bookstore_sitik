<?php
session_start();
require_once __DIR__ . "/config/database.php";
require_once __DIR__ . "/config/home-functions.php";

$best_authors = getBestAuthors($conn);
$best_picks   = getBestPicks($conn);

$search_keyword = isset($_GET['search']) ? trim($_GET['search']) : '';
$selected_category = isset($_GET['category']) ? trim($_GET['category']) : '';

// --- TAMBAHAN: Ambil semua kategori dari database secara dinamis ---
$categories_query = $conn->query("SELECT name FROM categories ORDER BY name ASC");
$all_categories = [];
if ($categories_query) {
    while ($row = $categories_query->fetch_assoc()) {
        $all_categories[] = $row['name'];
    }
}


$page_size = 10;

// Parameter offset/limit hanya digunakan untuk permintaan AJAX.
// Saat halaman Home dibuka normal, daftar selalu dimulai dari buku pertama.
$is_ajax_request = isset($_GET['ajax']) && $_GET['ajax'] === '1';
$offset = $is_ajax_request ? max(0, (int) ($_GET['offset'] ?? 0)) : 0;
$requested_limit = $is_ajax_request
    ? min(11, max(1, (int) ($_GET['limit'] ?? 11)))
    : 11;

$books = getExploreBooks($conn, $search_keyword, $selected_category, $requested_limit, $offset);
$has_more_books = count($books) > 10;
$books = array_slice($books, 0, 10);

if (isset($_GET['ajax']) && $_GET['ajax'] === '1') {
    header('Content-Type: application/json; charset=utf-8');
    ob_start();

    if (empty($books)) {
        echo '<div class="books-empty"><h3>No books available</h3><p>Book data has not been added yet.</p></div>';
    } else {
        echo '<div class="book-page"><div class="book-grid">';
        foreach ($books as $book) {
            ?>
            <a href="book-detail.php?id=<?php echo (int) $book["id"]; ?>" class="book-card-link">
              <div class="book-card">
                <img src="<?php echo htmlspecialchars($book["image"]); ?>" alt="<?php echo htmlspecialchars($book["title"]); ?>">
                <h3><?php echo htmlspecialchars($book["title"]); ?></h3>
                <p class="author"><?php echo htmlspecialchars($book["author"]); ?></p>
                <p class="price">Rp <?php echo number_format((int) $book["price"], 0, ",", "."); ?></p>
                <?php if ((int) $book["stock"] > 0): ?>
                  <span class="book-stock available">Stock: <?php echo (int) $book["stock"]; ?></span>
                <?php else: ?>
                  <span class="book-stock unavailable">Out of Stock</span>
                <?php endif; ?>
              </div>
            </a>
            <?php
        }
        echo '</div></div>';
    }

    $html = ob_get_clean();
    echo json_encode(['html' => $html, 'has_more' => $has_more_books, 'count' => count($books)]);
    exit;
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>S'itik BOOKSTORE</title>
  <link rel="stylesheet" href="css/base.css">
  <link rel="stylesheet" href="css/home.css?v=20260812-1">
</head>
<body class="home-page">

  <header class="site-navbar">
    <a class="site-logo" href="home.php" aria-label="S'itik Bookstore Home">
      <img src="images/logo-icon.png" alt="S'itik Bookstore logo">
      <span class="site-logo-text">
        <span class="top">S’itik</span>
        <span class="bottom">BOOKSTORE</span>
      </span>
    </a>

    <nav class="site-nav" aria-label="Main navigation">
      <a href="home.php" class="active">Home</a>
      <a href="cart.php">Cart</a>
      <a href="about-us.php">About Us</a>
      <a href="contact.php">Contact</a>
      <?php if (isset($_SESSION["user_id"])): ?>
        
        <?php
            // Ambil nama user untuk ditampilkan di navbar
            $nav_uid = $_SESSION["user_id"];
            $nav_stmt = $conn->prepare("SELECT name FROM users WHERE id = ? LIMIT 1");
            $nav_stmt->bind_param("i", $nav_uid);
            $nav_stmt->execute();
            $nav_user = $nav_stmt->get_result()->fetch_assoc();
            $nav_stmt->close();
            $display_name = $nav_user['name'] ?? 'Akun Saya';
        ?>
        <a href="profile.php" style="color: #4a5c46; font-weight: bold;">👤 <?php echo htmlspecialchars($display_name); ?></a>
        <a href="logout.php" class="signin-link">Logout</a>
      <?php else: ?>
        <a href="login.php" class="signin-link">Sign In</a>
      <?php endif; ?>
    </nav>
  </header>

  <main>
    <section class="hero-container">
      <div class="hero-left">
        <img src="images/hero-book.png" alt="A collection of books" class="hero-book-img">
      </div>

      <div class="hero-right">
        <div class="hero-text">
          <h1>The Book Lover's Dreamland Awaits!</h1>
          <p>Welcome to the ultimate book lover's paradise! Join our community and contribute to the ever-evolving library of stories, where every book has a chance to inspire someone new.</p>
        </div>

        <section class="best-authors-section" aria-labelledby="best-authors-title">
          <h2 id="best-authors-title">Best Authors Book</h2>
          <ul class="authors-list">
            <?php foreach ($best_authors as $author_book): ?>
            <li>
              <a href="book-detail.php?id=<?php echo (int) $author_book['id']; ?>" style="text-decoration: none; color: inherit;">
                <img src="<?php echo htmlspecialchars($author_book['image']); ?>" alt="<?php echo htmlspecialchars($author_book['title']); ?> book cover">
                <div class="author-info">
                  <strong><?php echo htmlspecialchars($author_book['title']); ?></strong>
                  <span><?php echo htmlspecialchars($author_book['author']); ?></span>
                </div>
              </a>
            </li>
            <?php endforeach; ?>
          </ul>
          </div>
        </section>

    <section class="best-picks-section" aria-labelledby="best-picks-title">
      <h2 id="best-picks-title">Our Best Picks</h2>
      <ul class="picks-list">
        <?php foreach ($best_picks as $pick): ?>
        <li>
          <a href="book-detail.php?id=<?php echo (int) $pick['id']; ?>" style="text-decoration: none; color: inherit;">
            <img src="<?php echo htmlspecialchars($pick['image']); ?>" alt="<?php echo htmlspecialchars($pick['title']); ?> book cover">
            <div class="author-info">
              <strong><?php echo htmlspecialchars($pick['title']); ?></strong>
              <span><?php echo htmlspecialchars($pick['author']); ?></span>
            </div>
          </a>
        </li>
        <?php endforeach; ?>
      </ul>
    </section>

    <!-- ===== Browse by Genre ===== -->
    <section class="genre-browser-section" aria-labelledby="genre-browser-title">
      <h2 id="genre-browser-title">Browse by Top Genres</h2>
      <div class="genre-browser-grid">
        <a class="genre-browser-card" href="genre.php?category=Romance" aria-label="Browse Romance books">
          <span class="genre-browser-icon" aria-hidden="true">♡</span>
          <span class="genre-browser-name">Romance</span>
        </a>
        <a class="genre-browser-card" href="genre.php?category=Fantasy" aria-label="Browse Fantasy books">
          <span class="genre-browser-icon" aria-hidden="true">✦</span>
          <span class="genre-browser-name">Fantasy</span>
        </a>
        <a class="genre-browser-card" href="genre.php?category=Horror" aria-label="Browse Horror books">
          <span class="genre-browser-icon" aria-hidden="true">☾</span>
          <span class="genre-browser-name">Horror</span>
        </a>
        <a class="genre-browser-card" href="genre.php?category=History" aria-label="Browse History books">
          <span class="genre-browser-icon" aria-hidden="true">◈</span>
          <span class="genre-browser-name">History</span>
        </a>
      </div>
    </section>

    <!-- ===== Explore More Books ===== -->
    <section class="explore-books" id="explore-books">
      <div class="container">
        <h2>Explore More Books</h2>


        <!-- TAMPILAN SEARCH & FILTER BAR -->
        <div class="filter-search-bar">
          <!-- BAGIAN KIRI: Filter Genre (Dinamis dari Database) -->
          <div class="filter-links" id="filter-links">
            <a href="javascript:void(0)" data-category="" class="genre-btn active">All</a>
            
            <?php foreach ($all_categories as $cat_name): ?>
                <a href="javascript:void(0)" data-category="<?php echo htmlspecialchars($cat_name); ?>" class="genre-btn">
                    <?php echo htmlspecialchars($cat_name); ?>
                </a>
            <?php endforeach; ?>
          </div>

          <!-- BAGIAN KANAN: Search Box -->
          <div class="search-box">
            <form id="search-form" onsubmit="return false;">
              <input type="text" id="search-input" placeholder="Search books" autocomplete="off">
            </form>
          </div>
        </div>
        <!-- AKHIR TAMPILAN SEARCH & FILTER BAR -->

        <div id="book-list-container">
          <?php if (empty($books)): ?>
            <div class="books-empty">
              <h3>No books available</h3>
              <p>Book data has not been added yet.</p>
            </div>
          <?php else: ?>
            <div class="book-pages" id="book-pages">
              <div class="book-page">
                <div class="book-grid">
              <?php foreach ($books as $book): ?>
                <a href="book-detail.php?id=<?php echo (int) $book["id"]; ?>" class="book-card-link">
                  <div class="book-card">
                    <img src="<?php echo htmlspecialchars($book["image"]); ?>" alt="<?php echo htmlspecialchars($book["title"]); ?>">
                    <h3><?php echo htmlspecialchars($book["title"]); ?></h3>
                    <p class="author"><?php echo htmlspecialchars($book["author"]); ?></p>
                    <p class="price">Rp <?php echo number_format((int) $book["price"], 0, ",", "."); ?></p>
                    <?php if ((int) $book["stock"] > 0): ?>
                      <span class="book-stock available">Stock: <?php echo (int) $book["stock"]; ?></span>
                    <?php else: ?>
                      <span class="book-stock unavailable">Out of Stock</span>
                    <?php endif; ?>
                  </div>
                </a>
              <?php endforeach; ?>
                </div>
              </div>
            </div>
          <?php endif; ?>
        </div>

        <div class="load-more-wrapper">
          <button type="button" id="load-more-btn" class="more-books-btn" <?php echo $has_more_books ? '' : 'hidden'; ?>>More Books</button>
        </div>
    </section>
  </main>

<style>
  .load-more-wrapper { display:flex; justify-content:center; margin:28px 0 12px; }
  .more-books-btn { border:1px solid #71836a; border-radius:24px; background:#71836a; color:#fff; padding:12px 34px; font:inherit; font-weight:600; cursor:pointer; }
  .more-books-btn:hover { background:#596b53; }
  .more-books-btn:disabled { opacity:.65; cursor:wait; }
  .more-books-btn[hidden] { display:none !important; }

  /* Setiap 10 buku menjadi satu halaman horizontal. */
  #book-list-container {
    width: 100%;
    min-width: 0;
  }

  .book-pages {
    display: flex;
    width: 100%;
    overflow-x: auto;
    overflow-y: hidden;
    scroll-snap-type: x mandatory;
    scroll-behavior: smooth;
    scrollbar-width: thin;
    scrollbar-color: #8b9a80 #eee9df;
    gap: 18px;
    padding-bottom: 12px;
  }

  .book-page {
    flex: 0 0 100%;
    width: 100%;
    min-width: 100%;
    scroll-snap-align: start;
  }

  .book-page .book-grid {
    width: 100%;
  }

  @media (max-width: 900px) {
    .book-page .book-grid {
      grid-template-columns: repeat(3, minmax(0, 1fr));
    }
  }

  @media (max-width: 600px) {
    .book-page .book-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  }
</style>

<script>
    
let currentCategory = '';
const searchInput = document.getElementById('search-input');
const bookContainer = document.getElementById('book-list-container');
const loadMoreButton = document.getElementById('load-more-btn');
const BOOKS_PER_LOAD = 10;

let currentOffset = 10;
let currentHasMore = <?php echo $has_more_books ? 'true' : 'false'; ?>;
let activeRequest = null;

function fetchBooks(reset = true) {
    if (!searchInput || !bookContainer || !loadMoreButton) return;

    if (activeRequest) activeRequest.abort();
    activeRequest = new AbortController();

    const requestedOffset = reset ? 0 : currentOffset;
    const params = new URLSearchParams({
        ajax: '1',
        category: currentCategory,
        search: searchInput.value.trim(),
        offset: String(requestedOffset),
        limit: String(BOOKS_PER_LOAD + 1)
    });

    loadMoreButton.disabled = true;
    loadMoreButton.textContent = 'Loading...';
    if (reset) loadMoreButton.hidden = true;

    fetch(`home.php?${params.toString()}`, {
        signal: activeRequest.signal
    })
    .then(response => {
        if (!response.ok) throw new Error('Gagal mengambil data buku.');
        return response.json();
    })
    .then(data => {
        if (reset) {
            bookContainer.innerHTML = data.html;
            currentOffset = data.count;

            const pages = bookContainer.querySelector('.book-pages');
            if (pages) pages.scrollLeft = 0;
        } else if (data.count > 0) {
            let pages = bookContainer.querySelector('.book-pages');

            // Create the horizontal pages wrapper if the first response had no books.
            if (!pages) {
                bookContainer.innerHTML = '<div class="book-pages" id="book-pages"></div>';
                pages = bookContainer.querySelector('.book-pages');
            }

            const temporary = document.createElement('div');
            temporary.innerHTML = data.html;
            const newPage = temporary.querySelector('.book-page');

            if (newPage) {
                pages.appendChild(newPage);
                currentOffset += data.count;

                // Geser ke kanan menuju batch 10 buku yang baru ditambahkan.
                requestAnimationFrame(() => {
                    pages.scrollTo({
                        left: newPage.offsetLeft - pages.offsetLeft,
                        behavior: 'smooth'
                    });
                });
            }
        }

        currentHasMore = data.has_more;
        loadMoreButton.hidden = !currentHasMore;
        loadMoreButton.disabled = false;
        loadMoreButton.textContent = 'More Books';
    })
    .catch(error => {
        if (error.name === 'AbortError') return;
        console.error('Error:', error);
        loadMoreButton.hidden = false;
        loadMoreButton.disabled = false;
        loadMoreButton.textContent = 'Try Again';
    });
}

document.querySelectorAll('.genre-btn').forEach(btn => {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelectorAll('.genre-btn').forEach(item => item.classList.remove('active'));
        this.classList.add('active');
        currentCategory = this.getAttribute('data-category') || '';
        fetchBooks(true);
    });
});

if (searchInput) {
    searchInput.addEventListener('input', () => fetchBooks(true));
    document.getElementById('search-form').addEventListener('submit', function(e) {
        e.preventDefault();
        fetchBooks(true);
    });
}

if (loadMoreButton) {
    loadMoreButton.addEventListener('click', function() {
        if (currentHasMore && !this.disabled) fetchBooks(false);
    });
}

</script>
</body>
</html>
