<?php
session_start();

require_once __DIR__ . "/config/database.php";
require_once __DIR__ . "/config/login-functions.php";

// Inisialisasi pesan
$error_login = "";
$error_register = "";
$success_register = "";
$error_forgot = "";
$success_forgot = "";

$active_tab = "signin";

// Proses form
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $action = $_POST["action"] ?? "";

    switch ($action) {

        case "login":
            $active_tab = "signin";
            handleLogin($conn, $error_login);
            break;

        case "register":
            $active_tab = "register";
            handleRegister($conn, $error_register, $success_register);
            break;

        case "forgot":
            $active_tab = "forgot";
            handleForgotPassword($conn, $error_forgot, $success_forgot);
            break;
    }
}

// Fungsi untuk mengamankan output HTML
function escapeOutput($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Account Access - S'itik Bookstore</title>

    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/login.css">
</head>

<body class="login-page">

<div class="auth-wrapper">

    <!-- ================= BAGIAN KIRI ================= -->
    <div class="auth-left-banner">

        <div class="auth-left-content">
            <span class="welcome-subtitle">WELCOME TO</span>

            <h1 class="welcome-title">
                S’itik Bookstore
            </h1>

            <p class="welcome-desc">
                Sign in to continue exploring your favorite books
                and manage your bookstore account.
            </p>
        </div>

        <div class="auth-quote-box">
            <p>
                “A reader lives a thousand lives before he dies.”
            </p>
        </div>

    </div>


    <!-- ================= BAGIAN KANAN ================= -->
    <div class="auth-right-panel">

        <div class="auth-card-box">

            <!-- TOMBOL TAB -->
            <div
                class="bubble-tabs-inside"
                id="bubbleTabsContainer"
                style="<?php echo $active_tab === 'forgot' ? 'display:none;' : ''; ?>"
            >

                <button
                    type="button"
                    id="tabSigninBtn"
                    class="bubble-btn-in <?php echo $active_tab === 'signin' ? 'active' : ''; ?>"
                    onclick="switchTab('signin')"
                >
                    Sign In
                </button>

                <button
                    type="button"
                    id="tabRegisterBtn"
                    class="bubble-btn-in <?php echo $active_tab === 'register' ? 'active' : ''; ?>"
                    onclick="switchTab('register')"
                >
                    Create Account
                </button>

            </div>


            <!-- ================================================= -->
            <!-- FORM 1: SIGN IN -->
            <!-- ================================================= -->

            <div
                id="signinSection"
                class="form-section <?php echo $active_tab === 'signin' ? 'active' : ''; ?>"
            >

                <div class="form-header">
                    <span class="form-tag">Account Access</span>

                    <h2>Sign In</h2>

                    <p>
                        Enter your email and password to access your account.
                    </p>
                </div>


                <?php if (!empty($error_login)): ?>
                    <div class="alert-error">
                        <?php echo escapeOutput($error_login); ?>
                    </div>
                <?php endif; ?>


                <form action="login.php" method="POST">

                    <input type="hidden" name="action" value="login">


                    <!-- EMAIL -->
                    <div class="auth-form-group">

                        <label>Email Address</label>

                        <input
                            type="email"
                            name="email"
                            placeholder="Enter your email"
                            autocomplete="email"
                            required
                        >

                    </div>


                    <!-- PASSWORD -->
                    <div class="auth-form-group">

                        <div class="auth-row-between">

                            <label>Password</label>

                            <a
                                href="#"
                                class="auth-forgot-link"
                                onclick="switchTab('forgot'); return false;"
                            >
                                Forgot Password?
                            </a>

                        </div>


                        <div class="password-input-wrapper">

                            <input
                                type="password"
                                id="loginPassword"
                                name="password"
                                placeholder="Enter your password"
                                autocomplete="current-password"
                                required
                            >

                            <button
                                type="button"
                                class="toggle-password"
                                onclick="togglePassword('loginPassword', this)"
                                aria-label="Show password"
                                aria-pressed="false"
                                title="Show password"
                            >👁</button>

                        </div>

                    </div>


                    <!-- REMEMBER ME -->
                    <div class="auth-remember-row">

                        <input
                            type="checkbox"
                            id="remember"
                        >

                        <label for="remember">
                            Remember me
                        </label>

                    </div>


                    <button type="submit" class="auth-submit-btn">
                        SIGN IN
                    </button>

                </form>

            </div>



            <!-- ================================================= -->
            <!-- FORM 2: CREATE ACCOUNT -->
            <!-- ================================================= -->

            <div
                id="registerSection"
                class="form-section <?php echo $active_tab === 'register' ? 'active' : ''; ?>"
            >

                <div class="form-header">
                    <span class="form-tag">New Member</span>

                    <h2>Create Account</h2>

                    <p>
                        Fill in your details to register a new account.
                    </p>
                </div>


                <?php if (!empty($error_register)): ?>
                    <div class="alert-error">
                        <?php echo escapeOutput($error_register); ?>
                    </div>
                <?php endif; ?>


                <?php if (!empty($success_register)): ?>
                    <div class="alert-success">
                        <?php echo escapeOutput($success_register); ?>
                    </div>
                <?php endif; ?>


                <form action="login.php" method="POST">

                    <input type="hidden" name="action" value="register">


                    <!-- FULL NAME -->
                    <div class="auth-form-group">

                        <label>Full Name</label>

                        <input
                            type="text"
                            name="name"
                            placeholder="Enter your full name"
                            autocomplete="name"
                            required
                        >

                    </div>


                    <!-- EMAIL -->
                    <div class="auth-form-group">

                        <label>Email Address</label>

                        <input
                            type="email"
                            name="email"
                            placeholder="Enter your email"
                            autocomplete="email"
                            required
                        >

                    </div>


                    <!-- PASSWORD -->
                    <div class="auth-form-group">

                        <label>Password</label>

                        <div class="password-input-wrapper">

                            <input
                                type="password"
                                id="registerPassword"
                                name="password"
                                placeholder="Create a password"
                                minlength="8"
                                autocomplete="new-password"
                                required
                            >

                            <button
                                type="button"
                                class="toggle-password"
                                onclick="togglePassword('registerPassword', this)"
                                aria-label="Show password"
                                aria-pressed="false"
                                title="Show password"
                            >👁</button>

                        </div>

                    </div>


                    <button type="submit" class="auth-submit-btn">
                        CREATE ACCOUNT
                    </button>

                </form>

            </div>



            <!-- ================================================= -->
            <!-- FORM 3: FORGOT PASSWORD -->
            <!-- ================================================= -->

            <div
                id="forgotSection"
                class="form-section <?php echo $active_tab === 'forgot' ? 'active' : ''; ?>"
            >

                <div class="form-header">

                    <span class="form-tag">Account Security</span>

                    <h2>Reset Password</h2>

                    <p>
                        Enter your registered email and create a new password.
                    </p>

                </div>


                <?php if (!empty($error_forgot)): ?>
                    <div class="alert-error">
                        <?php echo escapeOutput($error_forgot); ?>
                    </div>
                <?php endif; ?>


                <?php if (!empty($success_forgot)): ?>
                    <div class="alert-success">
                        <?php echo escapeOutput($success_forgot); ?>
                    </div>
                <?php endif; ?>


                <form action="login.php" method="POST">

                    <input type="hidden" name="action" value="forgot">


                    <!-- EMAIL -->
                    <div class="auth-form-group">

                        <label>Email Address</label>

                        <input
                            type="email"
                            name="email"
                            placeholder="Enter your registered email"
                            autocomplete="email"
                            required
                        >

                    </div>


                    <!-- NEW PASSWORD -->
                    <div class="auth-form-group">

                        <label>New Password</label>

                        <div class="password-input-wrapper">

                            <input
                                type="password"
                                id="newPassword"
                                name="new_password"
                                placeholder="Enter at least 8 characters"
                                minlength="8"
                                autocomplete="new-password"
                                required
                            >

                            <button
                                type="button"
                                class="toggle-password"
                                onclick="togglePassword('newPassword', this)"
                                aria-label="Show password"
                                aria-pressed="false"
                                title="Show password"
                            >👁</button>

                        </div>

                    </div>


                    <!-- CONFIRM PASSWORD -->
                    <div class="auth-form-group">

                        <label>Confirm New Password</label>

                        <div class="password-input-wrapper">

                            <input
                                type="password"
                                id="confirmPassword"
                                name="confirm_password"
                                placeholder="Confirm your new password"
                                minlength="8"
                                autocomplete="new-password"
                                required
                            >

                            <button
                                type="button"
                                class="toggle-password"
                                onclick="togglePassword('confirmPassword', this)"
                                aria-label="Show password"
                                aria-pressed="false"
                                title="Show password"
                            >👁</button>

                        </div>

                    </div>


                    <!-- SUBMIT -->
                    <button type="submit" class="auth-submit-btn">
                        RESET PASSWORD
                    </button>


                    <!-- BACK TO SIGN IN -->
                    <div style="text-align: center; margin-top: 16px;">

                        <a
                            href="#"
                            onclick="switchTab('signin'); return false;"
                            style="font-size: 12px; color: #9cb194; font-weight: bold; text-decoration: none;"
                        >
                            ← Back to Sign In
                        </a>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>



<!-- ================================================= -->
<!-- JAVASCRIPT -->
<!-- ================================================= -->

<script>

// ========================================
// FUNGSI BERPINDAH ANTAR FORM
// ========================================

function switchTab(tabName) {

    const signinBtn = document.getElementById('tabSigninBtn');
    const registerBtn = document.getElementById('tabRegisterBtn');
    const bubbleContainer = document.getElementById('bubbleTabsContainer');

    const signinSec = document.getElementById('signinSection');
    const registerSec = document.getElementById('registerSection');
    const forgotSec = document.getElementById('forgotSection');

    // Sembunyikan seluruh form
    signinSec.classList.remove('active');
    registerSec.classList.remove('active');
    forgotSec.classList.remove('active');

    // Hapus status aktif tombol
    signinBtn.classList.remove('active');
    registerBtn.classList.remove('active');

    if (tabName === 'signin') {

        bubbleContainer.style.display = 'flex';

        signinBtn.classList.add('active');
        signinSec.classList.add('active');

    } else if (tabName === 'register') {

        bubbleContainer.style.display = 'flex';

        registerBtn.classList.add('active');
        registerSec.classList.add('active');

    } else if (tabName === 'forgot') {

        bubbleContainer.style.display = 'none';

        forgotSec.classList.add('active');

    }

}



// ========================================
// FUNGSI SHOW / HIDE PASSWORD
// ========================================

function togglePassword(inputId, button) {

    const passwordInput = document.getElementById(inputId);

    if (!passwordInput) {
        return;
    }

    const isHidden = passwordInput.type === 'password';

    // Ubah tipe input
    passwordInput.type = isHidden ? 'text' : 'password';

    // Ubah ikon mata
    button.textContent = isHidden ? '🙈' : '👁';

    // Perbarui keterangan aksesibilitas
    button.setAttribute(
        'aria-label',
        isHidden ? 'Hide password' : 'Show password'
    );

    button.setAttribute(
        'title',
        isHidden ? 'Hide password' : 'Show password'
    );

    button.setAttribute(
        'aria-pressed',
        isHidden ? 'true' : 'false'
    );

}

</script>

</body>
</html>
