<?php
session_start();
require_once __DIR__ . "/config/database.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: home.php");
    exit;
}

$csrf_token = $_POST["csrf_token"] ?? "";
if (empty($_SESSION["payment_proof_csrf"]) || !hash_equals($_SESSION["payment_proof_csrf"], $csrf_token)) {
    http_response_code(403);
    exit("Sesi upload tidak valid. Muat ulang halaman pesanan dan coba kembali.");
}

$user_id = (int) $_SESSION["user_id"];
$order_id = (int) ($_POST["order_id"] ?? 0);

if ($order_id < 1) {
    header("Location: home.php");
    exit;
}

// Pesanan harus milik pengguna yang sedang login.
$stmt = $conn->prepare(
    "SELECT id, payment_method, payment_status, order_status, payment_proof
     FROM orders WHERE id = ? AND user_id = ? LIMIT 1"
);
$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    header("Location: home.php");
    exit;
}

$method = strtolower(trim($order["payment_method"]));
$is_cod = in_array($method, [
    "cash on delivery", "pay on delivery", "cod", "cash on-delivery", "bayar di tempat"
], true);

if ($is_cod || strtolower($order["order_status"]) !== "pending" ||
    !in_array(strtolower($order["payment_status"]), ["unpaid", "waiting verification"], true)) {
    header("Location: order-success.php?order_id=" . $order_id . "&upload=not-allowed");
    exit;
}

if (!isset($_FILES["payment_proof"]) || $_FILES["payment_proof"]["error"] !== UPLOAD_ERR_OK) {
    header("Location: order-success.php?order_id=" . $order_id . "&upload=error");
    exit;
}

$file = $_FILES["payment_proof"];
$maximum_size = 5 * 1024 * 1024;

if ($file["size"] <= 0 || $file["size"] > $maximum_size || !is_uploaded_file($file["tmp_name"])) {
    header("Location: order-success.php?order_id=" . $order_id . "&upload=error");
    exit;
}

$finfo = new finfo(FILEINFO_MIME_TYPE);
$mime_type = $finfo->file($file["tmp_name"]);
$allowed_types = [
    "image/jpeg" => "jpg",
    "image/png" => "png",
    "image/webp" => "webp",
    "application/pdf" => "pdf"
];

if (!isset($allowed_types[$mime_type])) {
    header("Location: order-success.php?order_id=" . $order_id . "&upload=error");
    exit;
}

// Validasi tambahan untuk file gambar.
if (strpos($mime_type, "image/") === 0 && @getimagesize($file["tmp_name"]) === false) {
    header("Location: order-success.php?order_id=" . $order_id . "&upload=error");
    exit;
}

$upload_directory = __DIR__ . "/uploads/payment-proofs/";
if (!is_dir($upload_directory) && !mkdir($upload_directory, 0755, true)) {
    header("Location: order-success.php?order_id=" . $order_id . "&upload=error");
    exit;
}

$file_name = "order-" . $order_id . "-" . bin2hex(random_bytes(16)) . "." . $allowed_types[$mime_type];
$destination = $upload_directory . $file_name;

if (!move_uploaded_file($file["tmp_name"], $destination)) {
    header("Location: order-success.php?order_id=" . $order_id . "&upload=error");
    exit;
}

$database_path = "uploads/payment-proofs/" . $file_name;
$payment_status = "Waiting Verification";

try {
    // Kondisi WHERE mencegah upload jika status berubah saat file sedang diproses.
    $update = $conn->prepare(
        "UPDATE orders
         SET payment_proof = ?, payment_status = ?
         WHERE id = ? AND user_id = ?
           AND order_status = 'pending'
           AND payment_method <> 'Cash on Delivery'
           AND payment_status IN ('Unpaid', 'Waiting Verification')"
    );
    $update->bind_param("ssii", $database_path, $payment_status, $order_id, $user_id);
    $update->execute();
    $updated = ($update->affected_rows === 1);
    $update->close();

    if (!$updated) {
        @unlink($destination);
        header("Location: order-success.php?order_id=" . $order_id . "&upload=not-allowed");
        exit;
    }

    // Hapus file bukti sebelumnya setelah file baru berhasil tercatat.
    $old_path = $order["payment_proof"] ?? "";
    if ($old_path !== "" && strpos($old_path, "uploads/payment-proofs/") === 0) {
        $old_file = __DIR__ . "/" . $old_path;
        if (is_file($old_file) && realpath(dirname($old_file)) === realpath($upload_directory)) {
            @unlink($old_file);
        }
    }

} catch (Throwable $error) {
    @unlink($destination);
    error_log("Upload bukti pembayaran pesanan #" . $order_id . " gagal: " . $error->getMessage());
    header("Location: order-success.php?order_id=" . $order_id . "&upload=error");
    exit;
}

header("Location: order-success.php?order_id=" . $order_id . "&upload=success");
exit;
