<?php

/** Mengambil seluruh pesanan terbaru. */
function getAllOrders($conn)
{
    return $conn->query("SELECT * FROM orders ORDER BY created_at DESC");
}

/**
 * Mengubah status pesanan dengan aturan bisnis yang konsisten.
 * Stok hanya dikembalikan saat transisi pertama menuju cancelled.
 */
function handleUpdateOrderStatus($conn, &$message)
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['update_status'])) {
        return;
    }

    $csrf = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['orders_csrf']) || !hash_equals($_SESSION['orders_csrf'], $csrf)) {
        $message = '<div class="alert-error">Sesi tidak valid. Muat ulang halaman pesanan.</div>';
        return;
    }

    $orderId = (int) ($_POST['order_id'] ?? 0);
    $newStatus = strtolower(trim($_POST['order_status'] ?? ''));
    $allowed = ['pending', 'processing', 'completed', 'cancelled'];

    if ($orderId < 1 || !in_array($newStatus, $allowed, true)) {
        $message = '<div class="alert-error">Data perubahan status tidak valid.</div>';
        return;
    }

    try {
        $conn->begin_transaction();

        $stmt = $conn->prepare(
            "SELECT id, payment_method, payment_status, payment_proof, order_status
             FROM orders WHERE id = ? FOR UPDATE"
        );
        $stmt->bind_param('i', $orderId);
        $stmt->execute();
        $order = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$order) {
            throw new RuntimeException('Pesanan tidak ditemukan.');
        }

        $currentStatus = strtolower($order['order_status']);
        $paymentMethod = strtolower(trim($order['payment_method']));
        $paymentStatus = strtolower(trim($order['payment_status'] ?? 'unpaid'));

        $isCod = in_array($paymentMethod, [
            'cash on delivery', 'pay on delivery', 'cod', 'cash on-delivery', 'bayar di tempat'
        ], true);

        if ($currentStatus === $newStatus) {
            $conn->commit();
            $message = '<div class="alert-success">Status pesanan #' . $orderId . ' tidak berubah.</div>';
            return;
        }

        // Pesanan yang sudah selesai atau dibatalkan bersifat final.
        if (in_array($currentStatus, ['completed', 'cancelled'], true)) {
            throw new RuntimeException('Pesanan yang sudah ' . $currentStatus . ' tidak dapat diubah kembali.');
        }

        $validTransitions = [
            'pending' => ['processing', 'cancelled'],
            'processing' => ['completed', 'cancelled']
        ];
        if (!isset($validTransitions[$currentStatus]) || !in_array($newStatus, $validTransitions[$currentStatus], true)) {
            throw new RuntimeException('Perubahan status dari ' . ucfirst($currentStatus) . ' ke ' . ucfirst($newStatus) . ' tidak diizinkan.');
        }

        if ($newStatus === 'processing') {
            if ($currentStatus !== 'pending') {
                throw new RuntimeException('Hanya pesanan Pending yang dapat diproses.');
            }
            if (!$isCod && $paymentStatus !== 'verified') {
                throw new RuntimeException('Pesanan transfer hanya dapat diproses setelah pembayaran diverifikasi admin.');
            }
        }

        if ($newStatus === 'completed') {
            if ($currentStatus !== 'processing') {
                throw new RuntimeException('Pesanan harus berstatus Processing sebelum diselesaikan.');
            }
            if ($isCod && $paymentStatus !== 'pay on delivery') {
                throw new RuntimeException('Status pembayaran COD tidak sesuai. Periksa pembayaran terlebih dahulu.');
            }
            if (!$isCod && $paymentStatus !== 'verified') {
                throw new RuntimeException('Pesanan transfer belum diverifikasi. Pesanan tidak dapat diselesaikan.');
            }
        }

        if ($newStatus === 'cancelled') {
            if (!in_array($currentStatus, ['pending', 'processing'], true)) {
                throw new RuntimeException('Hanya pesanan Pending atau Processing yang dapat dibatalkan.');
            }
            if (!$isCod && in_array($paymentStatus, ['verified', 'paid'], true)) {
                throw new RuntimeException('Pembayaran transfer sudah diverifikasi. Proses pengembalian dana harus diselesaikan terlebih dahulu sebelum pembatalan.');
            }
        }

        // Kembalikan stok hanya satu kali, bersamaan dengan perubahan ke Cancelled.
        if ($newStatus === 'cancelled') {
            $itemsStmt = $conn->prepare(
                "SELECT book_id, quantity FROM order_items WHERE order_id = ?"
            );
            $itemsStmt->bind_param('i', $orderId);
            $itemsStmt->execute();
            $items = $itemsStmt->get_result();
            if ($items->num_rows < 1) {
                throw new RuntimeException('Detail item pesanan tidak ditemukan; stok tidak dapat dikembalikan dengan aman.');
            }

            $restoreStmt = $conn->prepare(
                "UPDATE books SET stock = stock + ? WHERE id = ?"
            );

            while ($item = $items->fetch_assoc()) {
                $quantity = (int) $item['quantity'];
                $bookId = (int) $item['book_id'];
                $restoreStmt->bind_param('ii', $quantity, $bookId);
                $restoreStmt->execute();
                if ($restoreStmt->affected_rows !== 1) {
                    throw new RuntimeException('Gagal mengembalikan stok salah satu buku.');
                }
            }

            $restoreStmt->close();
            $itemsStmt->close();
        }

        // Completed COD berarti admin mengonfirmasi uang sudah diterima.
        if ($newStatus === 'completed' && $isCod) {
            $newPaymentStatus = 'Paid';
        } elseif ($newStatus === 'cancelled') {
            $newPaymentStatus = 'Cancelled';
        } else {
            $newPaymentStatus = $order['payment_status'];
        }

        $update = $conn->prepare(
            "UPDATE orders SET order_status = ?, payment_status = ? WHERE id = ?"
        );
        $update->bind_param('ssi', $newStatus, $newPaymentStatus, $orderId);
        $update->execute();
        $update->close();

        $conn->commit();
        $message = '<div class="alert-success">Status pesanan #' . $orderId . ' berhasil diperbarui.</div>';

    } catch (Throwable $error) {
        $conn->rollback();
        error_log('Update order #' . $orderId . ' gagal: ' . $error->getMessage());
        $message = '<div class="alert-error">' . htmlspecialchars($error->getMessage(), ENT_QUOTES, 'UTF-8') . '</div>';
    }
}

/** Verifikasi bukti transfer oleh admin. */
function handleVerifyOrderPayment($conn, &$message)
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['verify_payment'])) {
        return;
    }

    $csrf = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['orders_csrf']) || !hash_equals($_SESSION['orders_csrf'], $csrf)) {
        $message = '<div class="alert-error">Sesi tidak valid. Muat ulang halaman pesanan.</div>';
        return;
    }

    $orderId = (int) ($_POST['order_id'] ?? 0);
    if ($orderId < 1) {
        $message = '<div class="alert-error">ID pesanan tidak valid.</div>';
        return;
    }

    try {
        $conn->begin_transaction();

        $stmt = $conn->prepare(
            "SELECT payment_method, payment_status, payment_proof, order_status
             FROM orders WHERE id = ? FOR UPDATE"
        );
        $stmt->bind_param('i', $orderId);
        $stmt->execute();
        $order = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$order) {
            throw new RuntimeException('Pesanan tidak ditemukan.');
        }

        $method = strtolower(trim($order['payment_method']));
        $isCod = in_array($method, [
            'cash on delivery', 'pay on delivery', 'cod', 'cash on-delivery', 'bayar di tempat'
        ], true);

        if ($isCod) {
            throw new RuntimeException('Pembayaran COD tidak memerlukan verifikasi bukti transfer.');
        }
        if (strtolower($order['order_status']) !== 'pending') {
            throw new RuntimeException('Pembayaran hanya dapat diverifikasi saat pesanan masih Pending.');
        }
        if (empty($order['payment_proof'])) {
            throw new RuntimeException('Bukti pembayaran belum diunggah.');
        }
        if (strtolower($order['payment_status'] ?? '') !== 'waiting verification') {
            throw new RuntimeException('Pembayaran tidak berada dalam status Waiting Verification.');
        }

        $verified = 'Verified';
        $update = $conn->prepare(
            "UPDATE orders SET payment_status = ? WHERE id = ?"
        );
        $update->bind_param('si', $verified, $orderId);
        $update->execute();
        $update->close();

        $conn->commit();
        $message = '<div class="alert-success">Pembayaran pesanan #' . $orderId . ' berhasil diverifikasi.</div>';

    } catch (Throwable $error) {
        $conn->rollback();
        error_log('Verifikasi pembayaran #' . $orderId . ' gagal: ' . $error->getMessage());
        $message = '<div class="alert-error">' . htmlspecialchars($error->getMessage(), ENT_QUOTES, 'UTF-8') . '</div>';
    }
}
