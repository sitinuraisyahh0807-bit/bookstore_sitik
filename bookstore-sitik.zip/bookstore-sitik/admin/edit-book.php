<?php
session_start();
require_once "../config/database.php";
require_once "../config/book-functions.php"; // Memanggil fungsi yang sudah dipisah

// CEK LOGIN ADMIN
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== "admin") {
    header("Location: ../login.php");
    exit;
}

// CEK ID
if (!isset($_GET['id'])) {
    header("Location: books.php");
    exit;
}

$id = (int) $_GET['id'];

// AMBIL DATA BUKU DENGAN PREPARED STATEMENT
$stmt = $conn->prepare('SELECT * FROM books WHERE id = ? LIMIT 1');
$stmt->bind_param('i', $id);
$stmt->execute();
$book = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$book) {
    header("Location: books.php");
    exit;
}

// JALANKAN FUNGSI UPDATE DATA (Dari book-functions.php)
handleEditBook($conn, $id, $book['image']);

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku</title>
    
    <!-- Memanggil file CSS yang sudah dipisah -->
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="../css/edit-book.css">
</head>
<body>

<div class="edit-container">
    <div class="edit-card">
        
        <h1>Edit Buku</h1>

        <?php if (!empty($book['image'])): ?>
            <img class="preview" src="../<?= htmlspecialchars($book['image']); ?>" onerror="this.src='../images/hero-book.png';">
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            
            <label>Judul Buku</label>
            <input type="text" name="title" value="<?= htmlspecialchars($book['title']); ?>" required>

            <label>Author</label>
            <input type="text" name="author" value="<?= htmlspecialchars($book['author']); ?>" required>

            <label>Kategori</label>
            <input type="text" name="category" value="<?= htmlspecialchars($book['category']); ?>" required>

            <label>Harga</label>
            <input type="number" name="price" value="<?= htmlspecialchars($book['price']); ?>" required>

            <label>Stok</label>
            <input type="number" name="stock" value="<?= htmlspecialchars($book['stock']); ?>" required>

            
<label>Deskripsi</label>
<textarea name="description"><?= htmlspecialchars($book['description']); ?></textarea>


<!-- BEST AUTHOR -->
<label>Jadikan Best Author?</label>
<select name="is_best_author">
    <option value="0" <?= (int)$book['is_best_author'] === 0 ? 'selected' : ''; ?>>
        Bukan
    </option>

    <option value="1" <?= (int)$book['is_best_author'] === 1 ? 'selected' : ''; ?>>
        ⭐ Ya
    </option>
</select>


<!-- BEST PICK -->
<label>Jadikan Best Pick?</label>
<select name="is_best_pick">
    <option value="0" <?= (int)$book['is_best_pick'] === 0 ? 'selected' : ''; ?>>
        Bukan
    </option>

    <option value="1" <?= (int)$book['is_best_pick'] === 1 ? 'selected' : ''; ?>>
        ⭐ Ya
    </option>
</select>


<label>Ganti Gambar</label>
<input type="file" name="image" accept="image/*">


            <button type="submit" name="update">Simpan Perubahan</button>
            <a href="books.php" class="back">Kembali</a>

        </form>

    </div>
</div>

</body>
</html>