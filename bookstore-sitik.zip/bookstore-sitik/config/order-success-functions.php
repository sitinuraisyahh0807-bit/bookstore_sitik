
<?php

/**
 * Mengambil detail pesanan milik pengguna yang sedang login.
 *
 * @param mysqli $conn
 * @param int    $order_id
 * @param int    $user_id
 *
 * @return array|null
 */
function getOrderDetails($conn, $order_id, $user_id)
{
    $sql = "
        SELECT
            id,
            customer_name,
            payment_method,
            subtotal,
            shipping_fee,
            total_amount,
            order_status,
            payment_proof,
            payment_status,
            created_at
        FROM orders
        WHERE id = ?
          AND user_id = ?
        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        error_log('Gagal menyiapkan query detail pesanan: ' . $conn->error);
        return null;
    }

    $order_id = (int) $order_id;
    $user_id  = (int) $user_id;

    $stmt->bind_param('ii', $order_id, $user_id);

    if (!$stmt->execute()) {
        error_log('Gagal mengambil detail pesanan: ' . $stmt->error);
        $stmt->close();

        return null;
    }

    $result = $stmt->get_result();
    $order  = $result->fetch_assoc();

    $stmt->close();

    return $order ?: null;
}

/**
 * Mengambil semua item buku dalam satu pesanan.
 *
 * @param mysqli $conn
 * @param int    $order_id
 *
 * @return array
 */
function getOrderItems($conn, $order_id)
{
    $sql = "
        SELECT
            oi.quantity,
            oi.line_total,
            b.title,
            b.author,
            b.image
        FROM order_items AS oi
        INNER JOIN books AS b
            ON b.id = oi.book_id
        WHERE oi.order_id = ?
        ORDER BY oi.id ASC
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        error_log('Gagal menyiapkan query item pesanan: ' . $conn->error);
        return [];
    }

    $order_id = (int) $order_id;

    $stmt->bind_param('i', $order_id);

    if (!$stmt->execute()) {
        error_log('Gagal mengambil item pesanan: ' . $stmt->error);
        $stmt->close();

        return [];
    }

    $result = $stmt->get_result();
    $items  = [];

    while ($item = $result->fetch_assoc()) {
        $items[] = $item;
    }

    $stmt->close();

    return $items;
}
