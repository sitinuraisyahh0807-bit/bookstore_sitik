<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

if (($_SESSION["user_role"] ?? "") === "admin") {
    header("Location: admin/dashboard.php");
    exit;
}

if (empty($_SESSION["checkout_csrf"])) {
    $_SESSION["checkout_csrf"] = bin2hex(random_bytes(32));
}

// BUY NOW DARI HALAMAN DETAIL BUKU
if (!isset($_POST["buy_book_id"]) && isset($_SESSION["buy_now"]) && is_array($_SESSION["buy_now"])) {
    $buy_now_book_id = (int) ($_SESSION["buy_now"]["book_id"] ?? 0);
    $buy_now_quantity = (int) ($_SESSION["buy_now"]["quantity"] ?? 1);

    if ($buy_now_book_id > 0 && $buy_now_quantity > 0) {
        $_SESSION["checkout_items"] = [[
            "book_id" => $buy_now_book_id,
            "quantity" => $buy_now_quantity
        ]];
        $_SESSION["checkout_is_buy_now"] = true;
        unset($_SESSION["buy_now"]);
    }
}

require_once __DIR__ . "/config/database.php";
require_once __DIR__ . "/config/checkout-functions.php";

// Pembelian langsung dari keranjang mengambil kuantitas aktual dari database.
if (isset($_POST["buy_book_id"])) {
    $direct_id = (int)$_POST["buy_book_id"];
    $direct_stmt = $conn->prepare("SELECT quantity FROM cart WHERE user_id = ? AND book_id = ? LIMIT 1");
    $direct_stmt->bind_param("ii", $_SESSION["user_id"], $direct_id);
    $direct_stmt->execute();
    $direct_row = $direct_stmt->get_result()->fetch_assoc();
    $direct_stmt->close();
    if ($direct_row) { $_SESSION["checkout_items"] = [["book_id"=>$direct_id,"quantity"=>(int)$direct_row["quantity"]]]; $_SESSION["checkout_is_buy_now"] = false; unset($_SESSION["buy_now"]); }
}


$subtotal = 0;
$total_quantity = 0;

// AMBIL BUKU TERPILIH DARI CART
if (($_POST["checkout_mode"] ?? "") === "selected") {
    $_SESSION["checkout_items"] = [];
    $_SESSION["checkout_is_buy_now"] = false;
    unset($_SESSION["buy_now"]);

    $selected_books = $_POST["selected_books"] ?? [];
    if (is_array($selected_books)) {
        foreach ($selected_books as $book_id) {
            $book_id = (int) $book_id;
            if ($book_id < 1) continue;

            $cart_stmt = $conn->prepare("SELECT quantity FROM cart WHERE user_id = ? AND book_id = ? LIMIT 1");
            $cart_stmt->bind_param("ii", $_SESSION["user_id"], $book_id);
            $cart_stmt->execute();
            $cart_row = $cart_stmt->get_result()->fetch_assoc();
            $cart_stmt->close();
            if ($cart_row) {
                $_SESSION["checkout_items"][] = ["book_id" => $book_id, "quantity" => (int)$cart_row["quantity"]];
            }
        }
    }
}

// LOAD CHECKOUT ITEMS MENGGUNAKAN FUNCTION
$checkout_items = loadCheckoutItems($conn, $subtotal, $total_quantity);

// SHIPPING & TOTAL CALCULATION
$shipping_fee = $subtotal >= 150000 ? 0 : 10000;
$total = $subtotal + $shipping_fee;

$checkout_form = $_SESSION["checkout_form"] ?? [];
$customer_name = $checkout_form["customer_name"] ?? ($_SESSION["user_name"] ?? "");
$customer_phone = $checkout_form["customer_phone"] ?? "";
$customer_address = $checkout_form["customer_address"] ?? "";
$selected_payment = $checkout_form["payment"] ?? "Transfer BCA";
$back_link = "home.php";

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - S'itik Bookstore</title>
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/checkout.css">
</head>
<body class="checkout-page">

<header class="checkout-header">
    <a href="<?php echo htmlspecialchars($back_link); ?>" class="back-button">
        <span>←</span> Back
    </a>
    <a href="home.php" class="checkout-brand">
        <img src="images/logo-icon.png" alt="S'itik Bookstore Logo">
        <span class="checkout-brand-text">
            <span class="brand-top">S’itik</span>
            <span class="brand-bottom">BOOKSTORE</span>
        </span>
    </a>
    <a href="home.php#explore-books" class="add-more-button">
        <span>＋</span> Add More Books
    </a>
</header>

<main class="checkout-container">
    <section class="checkout-title">
        <h1>Checkout</h1>
        <div class="title-decoration">
            <span></span>
            <strong>❧</strong>
            <span></span>
        </div>
    </section>

    <form action="process-buy.php" method="post">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['checkout_csrf'], ENT_QUOTES, 'UTF-8'); ?>">
        <div class="checkout-layout">

            <!-- ================= LEFT SECTION ================= -->
            <section class="checkout-left">

                <!-- CUSTOMER INFORMATION -->
                <article class="checkout-card">
                    <div class="card-header">
                        <span class="card-icon">●</span>
                        <h2>Customer Information</h2>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="customerName">Full Name</label>
                            <input type="text" id="customerName" name="customer_name" placeholder="Enter your full name" value="<?php echo htmlspecialchars($customer_name); ?>" autocomplete="name" required>
                        </div>

                        <div class="form-group">
                            <label for="customerPhone">Phone Number</label>
                            <input type="tel" id="customerPhone" name="customer_phone" placeholder="Enter your phone number" value="<?php echo htmlspecialchars($customer_phone); ?>" autocomplete="tel" required>
                        </div>

                        <div class="form-group">
                            <label for="customerAddress">Address</label>
                            <textarea id="customerAddress" name="customer_address" rows="5" placeholder="Enter your complete address" required><?php echo htmlspecialchars($customer_address); ?></textarea>
                        </div>
                    </div>
                </article>

                <!-- PAYMENT METHOD -->
                <article class="checkout-card">
                    <div class="card-header">
                        <span class="card-icon">▣</span>
                        <h2>Payment Method</h2>
                    </div>
                    <div class="card-body payment-list">
                        
                        <!-- Bank BCA -->
                        <label class="payment-option">
                            <input type="radio" name="payment" value="Transfer BCA" <?php echo $selected_payment === "Transfer BCA" ? "checked" : ""; ?> onclick="toggleEwallet(false)">
                            <span class="custom-radio"></span>
                            <span class="payment-text">
                                <strong>Bank BCA</strong>
                                <small>Transfer ke Rekening BCA: 1234-5678-9012</small>
                            </span>
                        </label>

                        <!-- Bank Mandiri -->
                        <label class="payment-option">
                            <input type="radio" name="payment" value="Transfer Mandiri" <?php echo $selected_payment === "Transfer Mandiri" ? "checked" : ""; ?> onclick="toggleEwallet(false)">
                            <span class="custom-radio"></span>
                            <span class="payment-text">
                                <strong>Bank Mandiri</strong>
                                <small>Transfer ke Rekening Mandiri: 9876-5432-1098</small>
                            </span>
                        </label>

                        <!-- E-Wallet (Pilihan Utama) -->
                        <label class="payment-option">
                            <input type="radio" id="ewalletRadio" name="payment" value="E-Wallet"
    <?php echo strpos($selected_payment, "E-Wallet") === 0 ? "checked" : ""; ?>
    onclick="toggleEwallet(true)">
                            <span class="custom-radio"></span>
                            <span class="payment-text">
                                <strong>E-Wallet</strong>
                                <small>Pilih salah satu dompet digital (DANA, OVO, GoPay, ShopeePay)</small>
                            </span>
                        </label>

                        <!-- SUB-MENU E-WALLET -->
                        <div id="ewalletSubMenu" style="display: none; margin-left: 25px; margin-bottom: 15px; padding-left: 15px; border-left: 2px solid #9cb194;">
                            <label class="payment-option" style="margin-bottom: 8px;">
                                <input type="radio" name="payment" value="E-Wallet DANA" <?php echo $selected_payment === "E-Wallet DANA" ? "checked" : ""; ?>>
                                <span class="custom-radio"></span>
                                <span class="payment-text"><strong>DANA</strong> <small>0812-1111-2222</small></span>
                            </label>

                            <label class="payment-option" style="margin-bottom: 8px;">
                                <input type="radio" name="payment" value="E-Wallet OVO" <?php echo $selected_payment === "E-Wallet OVO" ? "checked" : ""; ?>>
                                <span class="custom-radio"></span>
                                <span class="payment-text"><strong>OVO</strong> <small>0812-3333-4444</small></span>
                            </label>

                            <label class="payment-option" style="margin-bottom: 8px;">
                                <input type="radio" name="payment" value="E-Wallet GoPay" <?php echo $selected_payment === "E-Wallet GoPay" ? "checked" : ""; ?>>
                                <span class="custom-radio"></span>
                                <span class="payment-text"><strong>GoPay</strong> <small>0812-5555-6666</small></span>
                            </label>

                            <label class="payment-option" style="margin-bottom: 0;">
                                <input type="radio" name="payment" value="E-Wallet ShopeePay" <?php echo $selected_payment === "E-Wallet ShopeePay" ? "checked" : ""; ?>>
                                <span class="custom-radio"></span>
                                <span class="payment-text"><strong>ShopeePay</strong> <small>0812-7777-8888</small></span>
                            </label>
                        </div>

                        <!-- Cash on Delivery -->
                        <label class="payment-option">
                            <input type="radio" name="payment" value="Cash on Delivery" <?php echo $selected_payment === "Cash on Delivery" ? "checked" : ""; ?> onclick="toggleEwallet(false)">
                            <span class="custom-radio"></span>
                            <span class="payment-text">
                                <strong>Cash on Delivery</strong>
                                <small>Pay when your order arrives</small>
                            </span>
                        </label>

                    </div>
                </article>

            </section>

            <!-- ================= RIGHT SECTION (ORDER ITEMS) ================= -->
            <aside class="checkout-card order-card">
                <div class="card-header">
                    <span class="card-icon">▢</span>
                    <h2>Order Items</h2>
                </div>
                <div class="card-body">
                    <?php if (!empty($checkout_items)): ?>
                        <div class="checkout-items" id="checkoutItems">
                            <?php foreach($checkout_items as $buy_item): ?>
                            <article class="checkout-item">
                                <img class="checkout-item-cover" src="<?php echo htmlspecialchars($buy_item["image"]); ?>" alt="<?php echo htmlspecialchars($buy_item["title"]); ?>">
                                <div class="checkout-item-info">
                                    <h3><?php echo htmlspecialchars($buy_item["title"]); ?></h3>
                                    <p class="checkout-item-author"><?php echo htmlspecialchars($buy_item["author"]); ?></p>
                                    <span class="checkout-item-genre"><?php echo htmlspecialchars($buy_item["category"]); ?></span>
                                    <p class="checkout-item-price">Rp <?php echo number_format((int) $buy_item["price"], 0, ",", "."); ?></p>
                                    <div class="checkout-quantity">
                                        <span>Quantity:</span>
                                        <div class="quantity-control">
                                            <button type="submit" name="quantity_action" value="decrease:<?= (int) $buy_item['id']; ?>" formaction="update-buy-quantity.php" class="quantity-button">−</button>
                                            <strong class="quantity-number"><?= $buy_item["quantity"]; ?></strong>
                                            <button type="submit" name="quantity_action" value="increase:<?= (int) $buy_item['id']; ?>" formaction="update-buy-quantity.php" class="quantity-button">+</button>
                                        </div>
                                    </div>
                                </div>
                            </article>
                            <?php endforeach; ?>
                        </div>

                        <section class="checkout-calculation" id="checkoutCalculation">
                            <div class="calculation-row">
                                <span id="subtotalLabel">Subtotal (<?php echo $total_quantity; ?> <?php echo $total_quantity === 1 ? "item" : "items"; ?>)</span>
                                <strong id="checkoutSubtotal">Rp <?php echo number_format($subtotal, 0, ",", "."); ?></strong>
                            </div>

                            <div class="calculation-row">
                                <span>Shipping Fee</span>
                                <strong id="shippingFee">
                                    <?php if ($shipping_fee === 0): ?>
                                        Free
                                    <?php else: ?>
                                        Rp <?php echo number_format($shipping_fee, 0, ",", "."); ?>
                                    <?php endif; ?>
                                </strong>
                            </div>

                            <div class="calculation-divider"></div>

                            <div class="calculation-total">
                                <span>Total</span>
                                <strong id="checkoutTotal">Rp <?php echo number_format($total, 0, ",", "."); ?></strong>
                            </div>

                            <button type="submit" class="place-order-button" id="buyButton">
                                <span>▣</span> BUY
                            </button>

                            <p class="secure-payment">
                                <span>✓</span> Your payment is secure and protected
                            </p>
                        </section>

                    <?php else: ?>
                        <div class="checkout-empty" id="checkoutEmpty">
                            <div class="empty-icon">📚</div>
                            <h3>No books selected</h3>
                            <p>Choose a book before continuing to checkout.</p>
                            <a href="home.php#explore-books">Explore Books</a>
                        </div>
                    <?php endif; ?>
                </div>
            </aside>

        </div>
    </form>

    <!-- BENEFITS -->
    <section class="checkout-benefits">
        <div class="benefit-item">
            <span class="benefit-icon">🚚</span>
            <div>
                <strong>Free Shipping</strong>
                <small>On orders over Rp 150.000</small>
            </div>
        </div>
        <div class="benefit-item">
            <span class="benefit-icon">✓</span>
            <div>
                <strong>Secure Payment</strong>
                <small>100% protected payment</small>
            </div>
        </div>
        <div class="benefit-item">
            <span class="benefit-icon">↻</span>
            <div>
                <strong>Easy Returns</strong>
                <small>7 days return policy</small>
            </div>
        </div>
        <div class="benefit-item">
            <span class="benefit-icon">☎</span>
            <div>
                <strong>Customer Support</strong>
                <small>Available every day</small>
            </div>
        </div>
    </section>
</main>

<script>
function toggleEwallet(show) {
    const subMenu = document.getElementById("ewalletSubMenu");
    const ewalletRadio = document.getElementById("ewalletRadio");

    if (!subMenu || !ewalletRadio) return;

    if (show) {
        subMenu.style.display = "block";

        // E-Wallet is a category; only its specific option is submitted.
        document.querySelectorAll('input[name="payment"]').forEach(function (radio) {
            radio.checked = false;
        });
        ewalletRadio.checked = true;
    } else {
        subMenu.style.display = "none";
        ewalletRadio.checked = false;
        subMenu.querySelectorAll('input[name="payment"]').forEach(function (radio) {
            radio.checked = false;
        });
    }
}

document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector('form[action="process-buy.php"]');
    const subMenu = document.getElementById("ewalletSubMenu");
    const ewalletRadio = document.getElementById("ewalletRadio");
    const selectedSub = subMenu ? subMenu.querySelector('input[name="payment"]:checked') : null;

    if (selectedSub) {
        ewalletRadio.checked = true;
        subMenu.style.display = "block";
    }

    if (form) {
        form.addEventListener("submit", function (event) {
            const selectedPayment = form.querySelector('input[name="payment"]:checked');

            if (!selectedPayment) {
                event.preventDefault();
                alert("Please select a payment method.");
                return;
            }

            if (selectedPayment.value === "E-Wallet") {
                event.preventDefault();
                alert("Please select a specific e-wallet: DANA, OVO, GoPay, or ShopeePay.");
                if (subMenu) subMenu.style.display = "block";
            }
        });
    }
});
</script>

</body>
</html>