<?php

header("Location: login.php#forgot");
exit;

?>