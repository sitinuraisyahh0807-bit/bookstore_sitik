<?php
session_start();require_once __DIR__.'/../config/database.php';require_once __DIR__.'/../config/auth.php';require_once __DIR__.'/../config/book-functions.php';requireAdmin();
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);exit('Method not allowed');}$id=(int)($_POST['id']??0);if($id>0)handleDeleteBook($conn,$id);header('Location: books.php');exit;
