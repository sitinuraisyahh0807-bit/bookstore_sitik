<?php
/**
 * Fungsi pengelolaan kategori dan pengambilan buku berdasarkan genre.
 * Fungsi lama dipertahankan; getBooksByCategory ditambahkan untuk halaman genre.php.
 */

function handleCategoryActions($conn)
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }

    if (isset($_POST['add'])) {
        $name = trim($_POST['name'] ?? '');

        if ($name === '') {
            header('Location: categories.php?status=empty');
            exit;
        }

        // Cek duplikasi tanpa membedakan huruf besar/kecil dan mengabaikan spasi tepi.
        $check = $conn->prepare(
            'SELECT id FROM categories WHERE LOWER(TRIM(name)) = LOWER(TRIM(?)) LIMIT 1'
        );

        if (!$check) {
            error_log('Prepare cek kategori gagal: ' . $conn->error);
            header('Location: categories.php?status=error');
            exit;
        }

        $check->bind_param('s', $name);
        $check->execute();
        $existing = $check->get_result()->fetch_assoc();
        $check->close();

        if ($existing) {
            header('Location: categories.php?status=duplicate');
            exit;
        }

        $stmt = $conn->prepare('INSERT INTO categories (name) VALUES (?)');

        if (!$stmt) {
            error_log('Prepare tambah kategori gagal: ' . $conn->error);
            header('Location: categories.php?status=error');
            exit;
        }

        $stmt->bind_param('s', $name);

        if ($stmt->execute()) {
            $stmt->close();
            header('Location: categories.php?status=success');
            exit;
        }

        // Jika database memiliki unique index dan terjadi duplikasi bersamaan.
        $errno = $stmt->errno;
        error_log('Tambah kategori gagal: ' . $stmt->error);
        $stmt->close();

        header('Location: categories.php?status=' . ($errno === 1062 ? 'duplicate' : 'error'));
        exit;
    }

    if (isset($_POST['delete_cat'])) {
        $id = (int) ($_POST['category_id'] ?? 0);
        if ($id > 0) {
            $stmt = $conn->prepare('DELETE FROM categories WHERE id = ?');
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $stmt->close();
        }
        header('Location: categories.php');
        exit;
    }
}

function getCategories($conn)
{
    return $conn->query('SELECT * FROM categories ORDER BY id DESC');
}

function getCategoryNames($conn)
{
    return $conn->query('SELECT name FROM categories ORDER BY name ASC');
}

function getCategoryOptions($conn)
{
    return $conn->query('SELECT name FROM categories ORDER BY name ASC');
}

function getAllCategories($conn)
{
    $result = $conn->query('SELECT name FROM categories ORDER BY name ASC');
    $names = [];

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $names[] = $row['name'];
        }
    }

    return $names;
}

/**
 * Mengambil buku berdasarkan nilai kolom books.category.
 * Halaman genre.php memanggil fungsi ini, tetapi versi sebelumnya
 * belum mendefinisikannya sehingga halaman genre menghasilkan fatal error.
 */
function getBooksByCategory($conn, $category)
{
    $sql = 'SELECT id, title, author, price, stock, image, category, description
            FROM books
            WHERE LOWER(TRIM(category)) = LOWER(TRIM(?))
            ORDER BY id ASC';

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        error_log('Prepare getBooksByCategory gagal: ' . $conn->error);
        return [];
    }

    $stmt->bind_param('s', $category);
    $stmt->execute();

    $result = $stmt->get_result();
    $books = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

    $stmt->close();
    return $books;
}
