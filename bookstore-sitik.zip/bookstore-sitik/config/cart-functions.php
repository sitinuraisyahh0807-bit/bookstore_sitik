<?php
function addToCart($conn, $user_id, $book_id, $quantity) {
    $user_id=(int)$user_id; $book_id=(int)$book_id; $quantity=(int)$quantity;
    if ($user_id<1 || $book_id<1 || $quantity<1 || $quantity>99) return false;
    $conn->begin_transaction();
    try {
        $book=$conn->prepare('SELECT stock FROM books WHERE id=? FOR UPDATE'); $book->bind_param('i',$book_id); $book->execute(); $row=$book->get_result()->fetch_assoc(); $book->close();
        if (!$row || (int)$row['stock']<1) throw new Exception('Buku tidak tersedia.');
        $check=$conn->prepare('SELECT id,quantity FROM cart WHERE user_id=? AND book_id=? LIMIT 1'); $check->bind_param('ii',$user_id,$book_id); $check->execute(); $existing=$check->get_result()->fetch_assoc(); $check->close();
        $newQty=$quantity+(int)($existing['quantity']??0);
        if ($newQty>(int)$row['stock']) throw new Exception('Jumlah melebihi stok yang tersedia.');
        if ($existing) { $stmt=$conn->prepare('UPDATE cart SET quantity=? WHERE id=? AND user_id=?'); $stmt->bind_param('iii',$newQty,$existing['id'],$user_id); }
        else { $stmt=$conn->prepare('INSERT INTO cart(user_id,book_id,quantity) VALUES(?,?,?)'); $stmt->bind_param('iii',$user_id,$book_id,$quantity); }
        $stmt->execute(); $stmt->close(); $conn->commit(); return true;
    } catch(Throwable $e) { $conn->rollback(); $_SESSION['cart_error']=$e->getMessage(); return false; }
}
function getCartItems($conn, $user_id, $selected_category='all', $search_keyword='') {
    $query='SELECT c.id AS cart_id,c.quantity,b.id AS book_id,b.title,b.author,b.category,b.price,b.stock,b.image FROM cart c JOIN books b ON c.book_id=b.id WHERE c.user_id=?'; $types='i'; $params=[(int)$user_id];
    if ($selected_category!=='all' && $selected_category!=='') {$query.=' AND b.category=?';$types.='s';$params[]=$selected_category;}
    if ($search_keyword!=='') {$query.=' AND (b.title LIKE ? OR b.author LIKE ?)';$types.='ss';$like='%'.$search_keyword.'%';$params[]=$like;$params[]=$like;}
    $query.=' ORDER BY c.id DESC'; $stmt=$conn->prepare($query);$stmt->bind_param($types,...$params);$stmt->execute();$items=$stmt->get_result()->fetch_all(MYSQLI_ASSOC);$stmt->close();return $items;
}
function handleRemoveFromCart($conn) {
    if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['remove_from_cart']) && isset($_SESSION['user_id'])) {
        $book_id=(int)($_POST['book_id']??0);$stmt=$conn->prepare('DELETE FROM cart WHERE user_id=? AND book_id=?');$stmt->bind_param('ii',$_SESSION['user_id'],$book_id);$stmt->execute();$stmt->close();header('Location: cart.php');exit;
    }
}
