<?php
session_start();

require_once __DIR__ . "/config/database.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: home.php");
    exit;
}

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$csrf_token = $_POST["csrf_token"] ?? "";
if (empty($_SESSION["checkout_csrf"]) || !hash_equals($_SESSION["checkout_csrf"], $csrf_token)) {
    http_response_code(403);
    exit("Sesi checkout tidak valid. Silakan kembali ke halaman checkout dan coba lagi.");
}

$user_id = (int) $_SESSION["user_id"];
$customer_name = trim($_POST["customer_name"] ?? "");
$customer_phone = trim($_POST["customer_phone"] ?? "");
$customer_address = trim($_POST["customer_address"] ?? "");
$payment_method = trim($_POST["payment"] ?? "");

if (
    $customer_name === "" ||
    $customer_phone === "" ||
    $customer_address === "" ||
    $payment_method === ""
) {
    die("Please complete all checkout information.");
}

// Menampung semua kemungkinan varian nama metode pembayaran (lama & baru)
$allowed_payments = [
    "Transfer BCA",
    "Transfer Mandiri",
    "E-Wallet DANA",
    "E-Wallet OVO",
    "E-Wallet GoPay",
    "E-Wallet ShopeePay",
    "Cash on Delivery"
];

if (!in_array($payment_method, $allowed_payments, true)) {
    die(
        "Invalid payment method. Value received: [" .
        htmlspecialchars($payment_method, ENT_QUOTES, "UTF-8") .
        "]"
    );
}

$session_items = $_SESSION["checkout_items"] ?? [];

if (!is_array($session_items) || empty($session_items)) {
    die("No books selected for checkout.");
}

$normalized_items = [];

foreach ($session_items as $item) {
    $book_id = (int) ($item["book_id"] ?? 0);
    $quantity = (int) ($item["quantity"] ?? 0);

    if ($book_id < 1 || $quantity < 1) {
        continue;
    }

    if (!isset($normalized_items[$book_id])) {
        $normalized_items[$book_id] = 0;
    }

    $normalized_items[$book_id] += $quantity;
}

if (empty($normalized_items)) {
    die("No valid books selected for checkout.");
}

$conn->begin_transaction();

try {
    $order_lines = [];
    $subtotal = 0;

    foreach ($normalized_items as $book_id => $quantity) {
        $book_statement = $conn->prepare(
            "SELECT id, title, price, stock
             FROM books
             WHERE id = ?
             LIMIT 1
             FOR UPDATE"
        );

        $book_statement->bind_param("i", $book_id);
        $book_statement->execute();

        $book = $book_statement
            ->get_result()
            ->fetch_assoc();

        $book_statement->close();

        if (!$book) {
            throw new Exception("Book not found.");
        }

        $current_stock = (int) $book["stock"];
        $book_price = (int) $book["price"];

        if ($current_stock < $quantity) {
            throw new Exception(
                "The requested quantity for \"" . $book["title"] .
                "\" exceeds the available stock."
            );
        }

        $line_total = $book_price * $quantity;
        $subtotal += $line_total;

        $order_lines[] = [
            "book_id" => (int) $book_id,
            "quantity" => (int) $quantity,
            "price" => $book_price,
            "line_total" => $line_total
        ];
    }

    $shipping_fee = $subtotal >= 150000 ? 0 : 10000;
    $total_amount = $subtotal + $shipping_fee;
    $order_status = "pending";
    $payment_status = ($payment_method === "Cash on Delivery")
        ? "Pay on Delivery"
        : "Unpaid";

    $order_statement = $conn->prepare(
        "INSERT INTO orders (
            user_id,
            customer_name,
            customer_phone,
            customer_address,
            payment_method,
            subtotal,
            shipping_fee,
            total_amount,
            order_status,
            payment_status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );

    $order_statement->bind_param(
        "issssiiiss",
        $user_id,
        $customer_name,
        $customer_phone,
        $customer_address,
        $payment_method,
        $subtotal,
        $shipping_fee,
        $total_amount,
        $order_status,
        $payment_status
    );

    $order_statement->execute();
    $order_id = $conn->insert_id;
    $order_statement->close();

    $item_statement = $conn->prepare(
        "INSERT INTO order_items (
            order_id,
            book_id,
            quantity,
            price,
            line_total
        ) VALUES (?, ?, ?, ?, ?)"
    );

    $stock_statement = $conn->prepare(
        "UPDATE books
         SET stock = stock - ?
         WHERE id = ?
         AND stock >= ?"
    );

    foreach ($order_lines as $line) {
        $book_id = $line["book_id"];
        $quantity = $line["quantity"];
        $book_price = $line["price"];
        $line_total = $line["line_total"];

        $item_statement->bind_param(
            "iiiii",
            $order_id,
            $book_id,
            $quantity,
            $book_price,
            $line_total
        );
        $item_statement->execute();

        $stock_statement->bind_param(
            "iii",
            $quantity,
            $book_id,
            $quantity
        );
        $stock_statement->execute();

        if ($stock_statement->affected_rows !== 1) {
            throw new Exception("Failed to update book stock.");
        }
    }

    $item_statement->close();
    $stock_statement->close();

    $conn->commit();

    if (empty($_SESSION["checkout_is_buy_now"])) {
        try {
            $clear = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND book_id = ?");
            foreach ($order_lines as $line) { $clear->bind_param("ii", $user_id, $line["book_id"]); $clear->execute(); }
            $clear->close();
        } catch (Throwable $cleanupError) {
            error_log("Cart cleanup failed after order #" . $order_id . ": " . $cleanupError->getMessage());
        }
    }
    unset($_SESSION["cart"], $_SESSION["checkout_items"], $_SESSION["checkout_is_buy_now"]);
    unset($_SESSION["buy_now"]);
    unset($_SESSION["checkout_form"], $_SESSION["checkout_csrf"]);

    $_SESSION["last_order_id"] = $order_id;

    header("Location: order-success.php?order_id=" . $order_id);
    exit;

} catch (Throwable $error) {
    $conn->rollback();

    error_log("Checkout gagal: " . $error->getMessage());
    $safe_message = "Transaksi belum dapat diproses. Periksa stok dan data pembayaran, lalu coba kembali.";

    die(
        "<h2>Purchase failed.</h2>" .
        "<p>{$safe_message}</p>" .
        "<p><a href='checkout.php'>Back to Checkout</a></p>"
    );
}
?>