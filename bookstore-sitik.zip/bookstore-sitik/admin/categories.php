<?php
session_start();
require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../config/category-functions.php";

// CEK LOGIN ADMIN
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if (!isset($_SESSION["user_role"]) || $_SESSION["user_role"] !== "admin") {
    header("Location: ../home.php");
    exit;
}

// Tangani aksi tambah & hapus kategori
handleCategoryActions($conn);

// Ambil data kategori
$categories = getCategories($conn);

// CEK HALAMAN AKTIF UNTUK SIDEBAR
$current_page = basename($_SERVER['PHP_SELF']);
$is_menu_open = in_array($current_page, ['dashboard.php', 'categories.php', 'books.php', 'add-book.php', 'edit-book.php', 'orders.php']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kategori Buku - Admin S'itik Bookstore</title>
    <!-- Memanggil CSS Utama Admin dan CSS Khusus Kategori -->
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="../css/categories.css">
    <style>
        .category-feedback {
            margin: 0 0 16px;
            padding: 12px 15px;
            border-radius: 9px;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 13px;
        }
        .category-feedback.success {
            color: #3f6840;
            background: #edf5e9;
            border: 1px solid #c9ddc1;
        }
        .category-feedback.error {
            color: #9b3030;
            background: #fff0f0;
            border: 1px solid #efcaca;
        }
    </style>
</head>
<body>

<div class="admin-container">

<!-- SIDEBAR START -->
<aside class="sidebar">

    <!-- LOGO -->
    <div class="sidebar-logo">
        <img src="../images/logo-icon.png" alt="Logo">
        <div class="logo-text">
            <span class="logo-top">S'itik</span>
            <strong>BOOKSTORE</strong>
            <small>ADMIN PANEL</small>
        </div>
    </div>

    <!-- MENU UTAMA -->
    <div class="sidebar-menu">
        <div class="menu-title">MAIN MENU</div>

        <!-- BUNGKUS MENU DROPDOWN -->
        <div class="menu-dropdown-container <?php echo $is_menu_open ? 'open' : ''; ?>" id="mainMenuContainer">
            
            <!-- TOMBOL DASHBOARD (Jika ini diklik, background hijau pindah ke sini) -->
            <div class="menu-item-wrapper <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <a href="dashboard.php" class="menu-link">
                    ⌂ <span>Dashboard</span>
                </a>
                <!-- PANAH DROPDOWN -->
                <span class="arrow-toggle" onclick="toggleMenu()">▼</span>
            </div>

            <!-- DAFTAR SUBMENU -->
            <ul class="submenu-list">
                <li><a href="users.php" class="submenu-item <?php echo ($current_page == 'users.php') ? 'active' : ''; ?>">Daftar User</a></li>
                <li><a href="categories.php" class="submenu-item <?php echo ($current_page == 'categories.php') ? 'active' : ''; ?>">Kategori Buku</a></li>
                <li><a href="books.php" class="submenu-item <?php echo ($current_page == 'books.php') ? 'active' : ''; ?>">Data Buku</a></li>
                <li><a href="add-book.php" class="submenu-item <?php echo ($current_page == 'add-book.php') ? 'active' : ''; ?>">Tambah Buku</a></li>
                <li><a href="orders.php" class="submenu-item <?php echo ($current_page == 'orders.php') ? 'active' : ''; ?>">Pesanan User</a></li>
                <li><a href="messages.php"class="submenu-item <?= ($current_page == 'messages.php') ? 'active' : ''; ?>">Pesan Masuk</a></li>
            </ul>
        </div>
    </div>

    <!-- MENU BAWAH -->
    <div class="sidebar-bottom">
        <a href="../logout.php" class="menu-item logout">
            → <span>Logout</span>
        </a>
    </div>

</aside>

<!-- SCRIPT UNTUK ANIMASI PANAH DROPDOWN -->
<script>
function toggleMenu() {
    document.getElementById('mainMenuContainer').classList.toggle('open');
}
</script>
<!-- SIDEBAR END -->

<!-- MAIN CONTENT START -->
<main class="main-content">

    <header class="admin-header">
        <div class="header-title">
            <h1>Kategori Buku</h1>
            <p>Kelola daftar kategori buku pada S'itik Bookstore.</p>
        </div>

        <div class="admin-profile">
            <div class="profile-avatar">A</div>
            <div class="profile-text">
                <strong>Administrator</strong>
                <span>Admin</span>
            </div>
        </div>
    </header>

    <div class="dashboard-content">
        
        <div class="category-card">
            <?php
                $category_status = $_GET['status'] ?? '';
                $category_messages = [
                    'success'   => ['success', 'Kategori berhasil ditambahkan.'],
                    'duplicate' => ['error', 'Kategori dengan nama tersebut sudah tersedia. Gunakan nama kategori lain.'],
                    'empty'     => ['error', 'Nama kategori tidak boleh kosong.'],
                    'error'     => ['error', 'Kategori gagal ditambahkan. Silakan coba lagi.']
                ];
            ?>

            <?php if (isset($category_messages[$category_status])): ?>
                <div class="category-feedback <?= $category_messages[$category_status][0]; ?>">
                    <?= htmlspecialchars($category_messages[$category_status][1]); ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="category-form">
                <input type="text" name="name" placeholder="Nama kategori baru" maxlength="100" required>
                <button type="submit" name="add">+ Tambah</button>
            </form>

            <table class="category-table">
                <tr>
                    <th>ID</th>
                    <th>Nama Kategori</th>
                    <th>Action</th>
                </tr>
                
                <?php if ($categories && $categories->num_rows > 0): ?>
                    <?php while($cat = mysqli_fetch_assoc($categories)): ?>
                    <tr>
                        <td><?= (int) $cat['id']; ?></td>
                        <td><?= htmlspecialchars($cat['name']); ?></td>
                        <td>
                            <form method="POST" action="categories.php" onsubmit="return confirm('Apakah Anda yakin ingin menghapus kategori ini?');" style="display:inline;">
                                <input type="hidden" name="category_id" value="<?= (int)$cat['id']; ?>">
                                <button type="submit" name="delete_cat" class="btn-delete">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3" style="text-align: center; color: #777;">Belum ada kategori yang ditambahkan.</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>

    </div>

</main>
<!-- MAIN CONTENT END -->

</div>

</body>
</html>