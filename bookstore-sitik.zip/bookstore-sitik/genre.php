<?php
session_start();
require_once __DIR__ . "/config/database.php";
require_once __DIR__ . "/config/category-functions.php";

$genre_content = [
    "Dongeng" => [
        "symbol" => "📖",
        "hero_image" => "images/dongeng-bg.png", 
        "hero_label" => "Welcome to the",
        "hero_text" => "Magical tales, folklore & classic stories",
        "eyebrow" => "Discover Dongeng Books",
        "headline" => "Step into a world of timeless tales.",
        "description" => "Kumpulan cerita rakyat, dongeng klasik, dan kisah penuh pesan moral.",
    ],
    "Romance" => [
        "symbol" => "♡",
        "hero_image" => "images/romance-bg.png",
        "hero_label" => "Welcome to the",
        "hero_text" => "Stories of love, feelings & connection",
        "eyebrow" => "Discover Romance Books",
        "headline" => "Fall in love with your next favorite story.",
        "description" => "A type of narrative fiction—whether in the form of a novel, film, or television series—in which the central plot focuses on the emotional connections, affection, and love that develop between the characters.",
    ],
    "Fantasy" => [
        "symbol" => "✦",
        "hero_image" => "images/fantasy-bg.png",
        "hero_label" => "Welcome to the",
        "hero_text" => "Magic, wonder & worlds beyond imagination",
        "eyebrow" => "Discover Fantasy Books",
        "headline" => "Open the door to another world.",
        "description" => "The fantasy genre is a type of speculative fiction centered on imaginative, magical, or supernatural elements that do not exist in the real world. Unlike realistic fiction, which is bound by the laws of nature, this genre grants authors complete freedom to create the rules of their own worlds—often drawing inspiration from mythology, folklore, or ancient legends.",
    ],
    "Horror" => [
        "symbol" => "☾",
        "hero_image" => "images/horror-bg.png",
        "hero_label" => "Welcome to the",
        "hero_text" => "Dark tales, mystery & chilling moments",
        "eyebrow" => "Discover Horror Books",
        "headline" => "Stories that stay with you after dark.",
        "description" => "A book in the horror genre is a work of fiction primarily designed to elicit emotional responses such as fear, dread, terror, and unease in the reader. This genre explores the deepest human fears by confronting ordinary reality with forces that lie beyond human control or reason.",
    ],
    "History" => [
        "symbol" => "◈",
        "hero_image" => "images/history-bg.png",
        "hero_label" => "Welcome to the",
        "hero_text" => "People, places & stories from the past",
        "eyebrow" => "Discover History Books",
        "headline" => "Read the stories that shaped our world.",
        "description" => "A genre within literature, film, or art that is set in the past and depicts events, figures, or eras that actually occurred in real history.
In this genre, the accuracy of details—such as the timeline, culture, attire, language, and socio-political conditions of the period—is highly prioritized to provide the audience with an authentic portrayal.",
    ],
];

$requested_category = isset($_GET["category"]) ? trim($_GET["category"]) : "Romance";
$category = null;

foreach (array_keys($genre_content) as $allowed_category) {
    if (strcasecmp($requested_category, $allowed_category) === 0) {
        $category = $allowed_category;
        break;
    }
}

if ($category === null) {
    $category = "Romance";
}

$genre = $genre_content[$category];

// Panggil dari function
$genre_books = getBooksByCategory($conn, $category);
$featured_books = array_slice($genre_books, 0, 3);

function genre_image_path($image) {
    $image = trim((string) $image);
    return $image === "" ? "images/no-image.png" : $image;
}

if (isset($_SESSION["user_role"]) && $_SESSION["user_role"] === "admin") {
    header("Location: admin/dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($category); ?> Books - S'itik BOOKSTORE</title>
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/genre.css?v=20260812-2">
</head>
<body class="genre-page">

<header class="site-navbar">
    <a class="site-logo" href="home.php" aria-label="S'itik Bookstore Home">
        <img src="images/logo-icon.png" alt="S'itik Bookstore logo">
        <span class="site-logo-text">
            <span class="top">S’itik</span>
            <span class="bottom">BOOKSTORE</span>
        </span>
    </a>
    <nav class="site-nav" aria-label="Main navigation">
        <a href="home.php">Home</a>
        <a href="cart.php">Cart</a>
        <a href="about-us.php">About Us</a>
        <a href="contact.php">Contact</a>

        <?php if (isset($_SESSION["user_id"])): ?>
            <a href="logout.php" class="signin-link">Logout</a>
        <?php else: ?>
            <a href="login.php" class="signin-link">Sign In</a>
        <?php endif; ?>
    </nav>
</header>

<main>
    <section class="genre-hero genre-<?php echo strtolower($category); ?>" style="background-image: url('<?php echo htmlspecialchars($genre["hero_image"]); ?>');">
        <div class="genre-hero-copy">
            <p><?php echo htmlspecialchars($genre["hero_label"]); ?></p>
            <h1><?php echo htmlspecialchars(strtoupper($category)); ?></h1>
            <h2><?php echo htmlspecialchars($genre["hero_text"]); ?></h2>
        </div>
    </section>

    <section class="genre-discover-section">
        <div class="genre-discover-copy">
            <span class="genre-eyebrow"><?php echo htmlspecialchars(strtoupper($genre["eyebrow"])); ?></span>
            <h2><?php echo htmlspecialchars($genre["headline"]); ?></h2>
            <p><?php echo htmlspecialchars($genre["description"]); ?></p>
            <a class="genre-jump-link" href="#genre-collection">
                View <?php echo htmlspecialchars($category); ?> Collection <span aria-hidden="true">→</span>
            </a>
        </div>

        <div class="genre-featured-books" aria-label="Featured <?php echo htmlspecialchars($category); ?> books">
            <?php if (!empty($featured_books)): ?>
                <?php foreach ($featured_books as $index => $book): ?>
                    <a class="feature-cover feature-cover-<?php echo $index + 1; ?>" href="book-detail.php?id=<?php echo (int) $book["id"]; ?>" aria-label="Open <?php echo htmlspecialchars($book["title"]); ?>">
                        <img src="<?php echo htmlspecialchars(genre_image_path($book["image"])); ?>" alt="<?php echo htmlspecialchars($book["title"]); ?> book cover">
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="genre-feature-placeholder">
                    <span><?php echo htmlspecialchars($genre["symbol"]); ?></span>
                    <p>Featured books will appear here.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="genre-collection" id="genre-collection">
        <div class="genre-collection-heading">
            <span><?php echo htmlspecialchars($genre["symbol"]); ?></span>
            <h2><?php echo htmlspecialchars($category); ?> Collection</h2>
            <p><?php echo count($genre_books); ?> book<?php echo count($genre_books) === 1 ? "" : "s"; ?> available in this genre</p>
        </div>

        <?php if (empty($genre_books)): ?>
            <div class="genre-empty-state">
                <span><?php echo htmlspecialchars($genre["symbol"]); ?></span>
                <h3>No <?php echo htmlspecialchars($category); ?> books yet</h3>
                <p>Buku untuk genre ini belum tersedia. Silakan kembali lagi nanti.</p>
                <a href="home.php#explore-books">Explore All Books</a>
            </div>
        <?php else: ?>
            <div class="genre-book-grid">
                <?php foreach ($genre_books as $book): ?>
                    <a class="genre-book-link" href="book-detail.php?id=<?php echo (int) $book["id"]; ?>">
                        <article class="genre-book-card">
                            <div class="genre-book-cover-wrap">
                                <img src="<?php echo htmlspecialchars(genre_image_path($book["image"])); ?>" alt="<?php echo htmlspecialchars($book["title"]); ?> book cover">
                            </div>
                            <h3><?php echo htmlspecialchars($book["title"]); ?></h3>
                            <p class="genre-book-author"><?php echo htmlspecialchars($book["author"]); ?></p>
                            <p class="genre-book-price">Rp <?php echo number_format((int) $book["price"], 0, ",", "."); ?></p>
                        </article>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</main>
</body>
</html>