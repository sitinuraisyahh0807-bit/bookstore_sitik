<?php
function loadCheckoutItems($conn, &$subtotal, &$total_quantity) {
    $items=[];$subtotal=0;$total_quantity=0;$source=$_SESSION['buy_now']??($_SESSION['checkout_items']??[]);
    if (isset($_SESSION['buy_now'])) $source=[$_SESSION['buy_now']];
    foreach ($source as $item) {
        $id=(int)($item['book_id']??0);$qty=(int)($item['quantity']??0);if($id<1||$qty<1)continue;
        $stmt=$conn->prepare('SELECT id,title,author,category,price,stock,image FROM books WHERE id=? LIMIT 1');$stmt->bind_param('i',$id);$stmt->execute();$book=$stmt->get_result()->fetch_assoc();$stmt->close();
        if(!$book || (int)$book['stock']<$qty) continue;
        $book['quantity']=$qty;$items[]=$book;$subtotal+=(int)$book['price']*$qty;$total_quantity+=$qty;
    }
    if (!isset($_SESSION['buy_now'])) $_SESSION['checkout_items']=array_map(fn($b)=>['book_id'=>(int)$b['id'],'quantity'=>(int)$b['quantity']],$items);
    return $items;
}
function processBuyNow($conn,$postData) {
    if($_SERVER['REQUEST_METHOD']!=='POST'){header('Location: home.php');exit;}
    if(empty($_SESSION['user_id'])){header('Location: login.php');exit;}
    $id=(int)($postData['book_id']??0);$qty=(int)($postData['quantity']??1);
    if($id<1||$qty<1||$qty>99){header('Location: home.php');exit;}
    $stmt=$conn->prepare('SELECT stock FROM books WHERE id=?');$stmt->bind_param('i',$id);$stmt->execute();$book=$stmt->get_result()->fetch_assoc();$stmt->close();
    if(!$book||(int)$book['stock']<$qty){header('Location: book-detail.php?id='.$id.'&error=stock');exit;}
    unset($_SESSION['checkout_items']);$_SESSION['buy_now']=['book_id'=>$id,'quantity'=>$qty];header('Location: checkout.php');exit;
}
