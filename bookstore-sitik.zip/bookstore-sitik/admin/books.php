<?php
session_start();
require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../config/book-functions.php";

if(!isset($_SESSION["user_id"])){
    header("Location: ../login.php");
    exit;
}
if(!isset($_SESSION["user_role"]) || $_SESSION["user_role"] !== "admin"){
    header("Location: ../home.php");
    exit;
}

$books_result = getAllBooks($conn);
$books = $books_result->fetch_all(MYSQLI_ASSOC);

// Mengambil daftar genre/kategori secara otomatis
$categories = [];

foreach ($books as $book) {
    if (!empty($book['category'])) {
        $categories[] = $book['category'];
    }
}

$categories = array_unique($categories);
sort($categories);

$current_page = basename($_SERVER['PHP_SELF']);
$is_menu_open = in_array($current_page, ['dashboard.php', 'categories.php', 'books.php', 'add-book.php', 'edit-book.php', 'orders.php']);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Buku - Admin S'itik Bookstore</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="stylesheet" href="../css/books.css">
</head>
<body>

<div class="admin-container">

<!-- SIDEBAR START -->
<aside class="sidebar">
    <div class="sidebar-logo">
        <img src="../images/logo-icon.png" alt="Logo">
        <div class="logo-text">
            <span class="logo-top">S'itik</span>
            <strong>BOOKSTORE</strong>
            <small>ADMIN PANEL</small>
        </div>
    </div>
    <div class="sidebar-menu">
        <div class="menu-title">MAIN MENU</div>
        <div class="menu-dropdown-container <?php echo $is_menu_open ? 'open' : ''; ?>" id="mainMenuContainer">
            <div class="menu-item-wrapper <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>">
                <a href="dashboard.php" class="menu-link">⌂ <span>Dashboard</span></a>
                <span class="arrow-toggle" onclick="toggleMenu()">▼</span>
            </div>
            <ul class="submenu-list">
                <li><a href="users.php" class="submenu-item <?php echo ($current_page == 'users.php') ? 'active' : ''; ?>">Daftar User</a></li>
                <li><a href="categories.php" class="submenu-item <?php echo ($current_page == 'categories.php') ? 'active' : ''; ?>">Kategori Buku</a></li>
                <li><a href="books.php" class="submenu-item <?php echo ($current_page == 'books.php') ? 'active' : ''; ?>">Data Buku</a></li>
                <li><a href="add-book.php" class="submenu-item <?php echo ($current_page == 'add-book.php') ? 'active' : ''; ?>">Tambah Buku</a></li>
                <li><a href="orders.php" class="submenu-item <?php echo ($current_page == 'orders.php') ? 'active' : ''; ?>">Pesanan User</a></li>
                <li><a href="messages.php"class="submenu-item <?= ($current_page == 'messages.php') ? 'active' : ''; ?>">Pesan Masuk</a></li>
            </ul>
        </div>
    </div>
    <div class="sidebar-bottom">
        <a href="../logout.php" class="menu-item logout">→ <span>Logout</span></a>
    </div>
</aside>
<script>
function toggleMenu() { document.getElementById('mainMenuContainer').classList.toggle('open'); }
</script>
<!-- SIDEBAR END -->

<!-- MAIN CONTENT -->
<main class="main-content">
    <header class="admin-header">
        <div class="header-title">
            <h1>Data Buku</h1>
            <p>Kelola seluruh data buku pada S'itik Bookstore.</p>
        </div>
        <div class="admin-profile">
            <a href="add-book.php" class="add-book-btn" style="margin-right: 20px;">+ Tambah Buku</a>
            <div class="profile-avatar">A</div>
            <div class="profile-text">
                <strong>Administrator</strong>
                <span>Admin</span>
            </div>
        </div>
    </header>

    <div class="dashboard-content">
        <?php if(isset($_GET['status']) && $_GET['status'] === 'success'): ?>
            <div class="alert-success">✓ Berhasil! Buku baru telah ditambahkan ke koleksi.</div>
        <?php endif; ?>

        <div class="books-box">

    <!-- SEARCH DAN FILTER -->
    <div class="books-toolbar">

        <div class="books-search">
            <icon class="search-icon"></icon>
            <input
                type="text"
                id="searchBook"
                placeholder="Cari judul buku atau author..."
            >
        </div>

        <select id="filterCategory" class="books-filter">
            <option value="">Semua Genre</option>

            <?php foreach ($categories as $category): ?>
                <option value="<?= htmlspecialchars($category, ENT_QUOTES, 'UTF-8'); ?>">
                    <?= htmlspecialchars($category); ?>
                </option>
            <?php endforeach; ?>

        </select>

    </div>

    <div class="books-info">
        <strong>Daftar Koleksi Buku</strong>
        <span id="booksCount">
            Menampilkan <?= count($books); ?> buku
        </span>
    </div>

    <table class="books-table">
                <thead>
                    <tr>
                        <th>COVER</th>
                        <th>JUDUL</th>
                        <th>AUTHOR</th>
                        <th>KATEGORI</th>
                        <th>HARGA</th>
                        <th>STOK</th>
                        <th>ACTION</th>
                    </tr>
                </thead>
                <tbody id="booksTableBody">

    <?php if (!empty($books)): ?>

        <?php foreach ($books as $book): ?>

        <tr class="book-row"
            data-category="<?= htmlspecialchars($book['category'], ENT_QUOTES, 'UTF-8'); ?>">

            <td>
                <?php if (!empty($book['image'])): ?>

                    <img
                        src="../<?= htmlspecialchars($book['image']); ?>"
                        class="cover-img"
                        onerror="this.src='../images/hero-book.png';"
                    >

                <?php else: ?>

                    <div class="no-cover">No Image</div>

                <?php endif; ?>
            </td>

            <td>
                <strong>
                    <?= htmlspecialchars($book['title']); ?>
                </strong>
            </td>

            <td>
                <?= htmlspecialchars($book['author']); ?>
            </td>

            <td>
                <?= htmlspecialchars($book['category']); ?>
            </td>

            <td class="price">
                Rp <?= number_format($book['price'], 0, ",", "."); ?>
            </td>

            <td>
                <strong><?= (int)$book['stock']; ?></strong>
            </td>

            <td>
                <div class="action">

                    <a
                        href="edit-book.php?id=<?= (int)$book['id']; ?>"
                        class="btn-edit"
                    >
                        Edit
                    </a>

                    <form
                        method="POST"
                        action="delete-book.php"
                        style="display:inline;"
                        onsubmit="return confirm('Hapus buku ini secara permanen?')"
                    >

                        <input
                            type="hidden"
                            name="id"
                            value="<?= (int)$book['id']; ?>"
                        >

                        <button type="submit" class="btn-delete">
                            Delete
                        </button>

                    </form>

                </div>
            </td>

        </tr>

        <?php endforeach; ?>

    <?php endif; ?>

    <tr id="emptySearch" style="display:none;">
        <td colspan="7" style="text-align:center;padding:40px;color:#777;">
            Buku yang kamu cari tidak ditemukan.
        </td>
    </tr>

    <?php if (empty($books)): ?>
        <tr>
            <td colspan="7" style="text-align:center;padding:40px;color:#777;">
                Belum ada data buku.
            </td>
        </tr>
    <?php endif; ?>

</tbody>
            </table>
        </div>
    </div>
</main>
<!-- MAIN CONTENT END -->

</div>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const searchInput = document.getElementById('searchBook');
    const categoryFilter = document.getElementById('filterCategory');
    const rows = document.querySelectorAll('.book-row');
    const emptySearch = document.getElementById('emptySearch');
    const booksCount = document.getElementById('booksCount');

    function filterBooks() {

        const keyword = searchInput.value.toLowerCase().trim();
        const selectedCategory = categoryFilter.value.toLowerCase();

        let visibleCount = 0;

        rows.forEach(function (row) {

            const text = row.textContent.toLowerCase();
            const category = row.dataset.category.toLowerCase();

            const matchSearch = text.includes(keyword);
            const matchCategory =
                selectedCategory === '' ||
                category === selectedCategory;

            if (matchSearch && matchCategory) {
                row.style.display = '';
                visibleCount++;
            } else {
                row.style.display = 'none';
            }

        });

        emptySearch.style.display =
            visibleCount === 0 ? '' : 'none';

        booksCount.textContent =
            'Menampilkan ' + visibleCount + ' dari ' + rows.length + ' buku';

    }

    searchInput.addEventListener('input', filterBooks);
    categoryFilter.addEventListener('change', filterBooks);

});
</script>

</body>
</html>