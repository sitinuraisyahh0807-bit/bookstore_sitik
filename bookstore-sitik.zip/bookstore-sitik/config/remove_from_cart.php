<?php
session_start();
require_once __DIR__ . "/database.php"; // Path disesuaikan karena sudah di dalam config

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['book_id'])) {
    $user_id = $_SESSION["user_id"];
    $book_id = (int) $_POST['book_id'];

    $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND book_id = ?");
    $stmt->bind_param("ii", $user_id, $book_id);
    
    if ($stmt->execute()) {
        $stmt->close();
        header("Location: ../cart.php"); // Mundur satu folder kembali ke cart.php
        exit;
    } else {
        $stmt->close();
        echo "Gagal menghapus produk dari keranjang.";
    }
} else {
    header("Location: ../cart.php");
    exit;
}
?>