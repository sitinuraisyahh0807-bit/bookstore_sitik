<?php

session_start();

require_once __DIR__ . "/config/database.php";

/* AMBIL ID BUKU DARI URL */
$book_id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$book_id || $book_id < 1) {
    header("Location: home.php");
    exit;
}

/* AMBIL DATA BUKU DARI DATABASE */
$statement = $conn->prepare("SELECT id, title, author, category, price, stock, image, description FROM books WHERE id = ? LIMIT 1");
$statement->bind_param("i", $book_id);
$statement->execute();

$result = $statement->get_result();
$book = $result->fetch_assoc();

$statement->close();

/* JIKA BUKU TIDAK DITEMUKAN */
if (!$book) {
    http_response_code(404);
    die("<h2>Book not found.</h2><p><a href='home.php'>Back to Home</a></p>");
}

if (isset($_SESSION["user_role"]) && $_SESSION["user_role"] === "admin") {
    header("Location: admin/dashboard.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($book["title"]); ?> - S'itik Bookstore</title>
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/book-detail.css">
</head>

<body class="book-detail-page">

<!-- NAVBAR -->
<header class="site-navbar">
    <a class="site-logo" href="home.php" aria-label="S'itik Bookstore Home">
        <img src="images/logo-icon.png" alt="S'itik Bookstore logo">
        <span class="site-logo-text">
            <span class="top">S’itik</span>
            <span class="bottom">BOOKSTORE</span>
        </span>
    </a>

    <nav class="site-nav" aria-label="Main navigation">
        <a href="home.php">Home</a>
        <a href="cart.php">Cart</a>
        <a href="about-us.php">About Us</a>
        <a href="contact.php">Contact</a>
        <?php if (isset($_SESSION["user_id"])): ?>
            <a href="logout.php" class="signin-link">Logout</a>
        <?php else: ?>
            <a href="login.php" class="signin-link">Sign In</a>
        <?php endif; ?>
    </nav>

</header>

<!-- DETAIL BUKU -->
<main class="detail-page-container">
    <a href="home.php#explore-books" class="back-to-books">← Back to Books</a>

    <article class="detail-card">
        <!-- COVER BUKU -->
        <div class="detail-cover">
            <img src="<?php echo htmlspecialchars($book["image"]); ?>" alt="<?php echo htmlspecialchars($book["title"]); ?>">
        </div>

        <!-- INFORMASI BUKU -->
        <section class="detail-information">
            <p class="detail-category"><?php echo htmlspecialchars($book["category"]); ?></p>
            <h1 class="detail-title"><?php echo htmlspecialchars($book["title"]); ?></h1>
            <p class="detail-description"><?php echo nl2br(htmlspecialchars($book["description"] ?? "")); ?></p>

            <div class="detail-bottom-information">
                <!-- AUTHOR -->

                <div class="detail-author">

                    <span>Written By:</span>
                    <strong><?php echo htmlspecialchars($book["author"]); ?></strong>
                </div>

                <!-- RATING -->
                <div class="detail-rating">

                    <div class="detail-stars">
                        <span>★</span><span>★</span><span>★</span><span>★</span><span class="empty-star">★</span>
                    </div>

                    <strong>4.0 Reviews</strong>

                </div>

            </div>

        </section>

        <!-- PURCHASE AREA -->
        <aside class="detail-purchase">
            <p class="detail-stock">Stock: <strong><?php echo (int) $book["stock"]; ?></strong></p>

            <?php if ((int) $book["stock"] > 0): ?>
                <!-- FORM ADD TO CART + BUY -->
                <form action="add_to_cart.php" method="post" class="detail-purchase-form">
                    <input type="hidden" name="book_id" value="<?php echo (int) $book["id"]; ?>">
                    
                    <button type="submit" class="detail-button">ADD TO CART</button>
                    <button type="submit" class="detail-button" formaction="buy_now.php">BUY</button>

                    <div class="quantity-area">
                        <label for="quantity">Quantity</label>
                        <input type="number" id="quantity" name="quantity" min="1" max="<?php echo (int) $book["stock"]; ?>" value="1" required>
                    </div>

                    <p class="detail-price">Rp <?php echo number_format((int) $book["price"], 0, ",", "."); ?></p>
                </form>

            <?php else: ?>
                <!-- OUT OF STOCK -->
                <button type="button" class="detail-button" disabled>OUT OF STOCK</button>
                <p class="detail-price">Rp <?php echo number_format((int) $book["price"], 0, ",", "."); ?></p>
            <?php endif; ?>

        </aside>


    </article>
    
</main>

</body>
</html>