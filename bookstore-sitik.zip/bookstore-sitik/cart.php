<?php
session_start();
require_once __DIR__ . "/config/database.php";
require_once __DIR__ . "/config/cart-functions.php";
require_once __DIR__ . "/config/category-functions.php";
require_once __DIR__ . "/config/login-functions.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION["user_id"];
$search_keyword = isset($_GET['search']) ? trim($_GET['search']) : '';
$selected_category = isset($_GET['category']) ? trim($_GET['category']) : 'all';

// Panggil dari function
$cart_items = getCartItems($conn, $user_id, $selected_category, $search_keyword);
$filtered_items = $cart_items;
$all_categories = getAllCategories($conn);

if (isset($_SESSION["user_role"]) && $_SESSION["user_role"] === "admin") {
    header("Location: admin/dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart - S'itik BOOKSTORE</title>
    <link rel="stylesheet" href="css/base.css">
    <link rel="stylesheet" href="css/cart.css?v=5">
</head>
<body class="cart-page">

<header class="site-navbar">
    <a class="site-logo" href="home.php" aria-label="S'itik Bookstore Home">
        <img src="images/logo-icon.png" alt="S'itik Bookstore logo">
        <span class="site-logo-text">
            <span class="top">S'itik</span>
            <span class="bottom">BOOKSTORE</span>
        </span>
    </a>

    <nav class="site-nav" aria-label="Main navigation">
      <a href="home.php">Home</a>
      <a href="cart.php" class="active">Cart</a>
      <a href="about-us.php">About Us</a>
      <a href="contact.php">Contact</a>
      <?php if (isset($_SESSION["user_id"])): ?>
        <?php
            $nav_uid = $_SESSION["user_id"];
            $nav_stmt = $conn->prepare("SELECT name FROM users WHERE id = ? LIMIT 1");
            $nav_stmt->bind_param("i", $nav_uid);
            $nav_stmt->execute();
            $nav_user = $nav_stmt->get_result()->fetch_assoc();
            $nav_stmt->close();
            $display_name = $nav_user['name'] ?? 'Akun Saya';
        ?>
        <a href="profile.php" style="color: #4a5c46; font-weight: bold;">👤 <?php echo htmlspecialchars($display_name); ?></a>
        <a href="logout.php" class="signin-link">Logout</a>
      <?php else: ?>
        <a href="login.php" class="signin-link">Sign In</a>
      <?php endif; ?>
    </nav>
</header>

<main class="catalog-container">
    <h1 class="catalog-title">Your Shopping Cart</h1>

    <div class="filter-bar">
        <div class="category-filters">
            <a href="cart.php?category=all<?php echo $search_keyword !== '' ? '&search=' . urlencode($search_keyword) : ''; ?>" class="<?php echo $selected_category === 'all' ? 'filter-active' : ''; ?>">All</a>
            <?php foreach ($all_categories as $cat_name): ?>
                <a href="cart.php?category=<?php echo urlencode($cat_name); ?><?php echo $search_keyword !== '' ? '&search=' . urlencode($search_keyword) : ''; ?>" class="<?php echo strcasecmp($selected_category, $cat_name) === 0 ? 'filter-active' : ''; ?>">
                    <?php echo htmlspecialchars($cat_name); ?>
                </a>
            <?php endforeach; ?>
        </div>

        <form action="cart.php" method="get" class="search-box">
            <input type="hidden" name="category" value="<?php echo htmlspecialchars($selected_category); ?>">
            <input type="text" name="search" placeholder="Search books" aria-label="Search books" value="<?php echo htmlspecialchars($search_keyword); ?>">
            <button type="submit" class="search-button" aria-label="Search"></button>
        </form>
    </div>

    <?php if (isset($_GET["added"])): ?>
        <div class="cart-success-message">Book successfully added to Cart.</div>
    <?php endif; ?>

    <?php if (empty($cart_items)): ?>
        <section class="empty-cart">
            <div class="empty-cart-icon">🛒</div>
            <h2>Your cart is empty</h2>
            <p>No books have been added to your Cart.</p>
            <a href="home.php#explore-books" class="continue-shopping-btn">Explore Books</a>
        </section>

    <?php elseif (empty($filtered_items)): ?>
        <section class="empty-cart">
            <div class="empty-cart-icon">🔍</div>
            <h2>No books found</h2>
            <p>No matching books were found in your Cart.</p>
            <a href="cart.php" class="continue-shopping-btn">Show All Books</a>
        </section>

    <?php else: ?>
        <div id="selectedBox" class="selected-cart-box">
            <h3>Buku Dipilih</h3>
            <div id="selectedList">Belum ada buku dipilih</div>
        </div>

        <div class="book-grid">
            <?php foreach ($filtered_items as $book): ?>
                <article class="book-card">
                    <div class="book-img-wrapper">
                        <img src="<?php echo htmlspecialchars($book["image"]); ?>" alt="<?php echo htmlspecialchars($book["title"]); ?>">
                    </div>
                    <div class="book-content">
                        <div class="book-meta">
                            <span class="book-genre"><?php echo htmlspecialchars($book["category"]); ?></span>
                            <label class="book-select">
                                <input type="checkbox" class="book-checkbox" name="selected_books[]" value="<?= (int) $book['book_id']; ?>" form="selectedCheckoutForm" data-id="<?= $book['book_id']; ?>" data-title="<?= htmlspecialchars($book['title']); ?>" data-author="<?= htmlspecialchars($book['author']); ?>" data-category="<?= htmlspecialchars($book['category']); ?>" data-price="<?= $book['price']; ?>">
                            </label>
                        </div>
                        <h3><?php echo htmlspecialchars($book["title"]); ?></h3>
                        <p class="author"><?php echo htmlspecialchars($book["author"]); ?></p>
                        <p class="price book-price">Rp <?php echo number_format((int) $book["price"], 0, ",", "."); ?></p>
                        <span class="availability">Stock: <?php echo (int) $book["stock"]; ?></span>
                        <p class="cart-quantity">Quantity: <strong><?php echo (int) $book["quantity"]; ?></strong></p>
                        <div class="cart-actions">
                            <form action="config/remove_from_cart.php" method="post" class="cart-action-form">
    <input type="hidden" name="book_id" value="<?php echo (int) $book["book_id"]; ?>">
    <button type="submit" class="cart-btn remove-cart-btn">Remove from Cart</button>
</form>
                            <form action="checkout.php" method="POST" class="cart-action-form">
                                <input type="hidden" name="buy_book_id" value="<?= $book["book_id"]; ?>">
                                <button type="submit" class="buy-cart-btn">Buy</button>
                            </form>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>

        <form action="checkout.php" method="POST" id="selectedCheckoutForm">
            <input type="hidden" name="checkout_mode" value="selected">
            <button type="submit" class="checkout-btn">Checkout Selected Books</button>
        </form>

        <a href="home.php#explore-books" class="checkout-btn">Add More Books</a>
    <?php endif; ?>

    <div class="selected-cart-box" id="selectedCartBox">
        <div class="selected-cart-header">
            <b>☑ Pilih Semua (<span id="selectedCount">0</span>)</b>
            <span>🗑 Hapus</span>
        </div>
        <div id="selectedCartList"></div>
        <div class="selected-cart-footer">
            <div>
                <b>Total (<span id="totalBooks">0</span> buku)</b>
                <h2 id="selectedTotal">Rp 0</h2>
            </div>
            <button type="submit" class="checkout-selected-btn" form="selectedCheckoutForm">
                Checkout (<span id="checkoutCount">0</span>)
            </button>
        </div>
    </div>
</main>
</body>
</html>