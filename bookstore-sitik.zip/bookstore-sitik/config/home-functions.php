<?php
// config/home-functions.php

// 1. Fungsi ambil buku Best Authors (Dinamis dari Admin)
function getBestAuthors($conn) {
    // Ambil buku yang ditandai "⭐ Ya" oleh Admin
    $query = $conn->query("SELECT id, title, author, image FROM books WHERE is_best_author = 1 ORDER BY id DESC LIMIT 6");
    $books = $query->fetch_all(MYSQLI_ASSOC);

    // Jika Admin menandai kurang dari 4 buku, sistem otomatis memenuhinya
    if (count($books) < 4) {
        $limit = 4 - count($books);
        $exclude_ids = empty($books) ? "0" : implode(",", array_column($books, 'id'));
        $fallback = $conn->query("SELECT id, title, author, image FROM books WHERE id NOT IN ($exclude_ids) ORDER BY id DESC LIMIT $limit");
        $books = array_merge($books, $fallback->fetch_all(MYSQLI_ASSOC));
    }

    return $books;
}

// 2. Fungsi ambil buku Best Picks (Dinamis dari Admin)
function getBestPicks($conn) {
    // Ambil buku yang ditandai "⭐ Ya" untuk Best Picks
    $query = $conn->query("SELECT id, title, author, image FROM books WHERE is_best_pick = 1 ORDER BY id DESC LIMIT 5");
    $books = $query->fetch_all(MYSQLI_ASSOC);

    // Jika Admin menandai kurang dari 5 buku, sistem otomatis memenuhinya
    if (count($books) < 5) {
        $limit = 5 - count($books);
        $exclude_ids = empty($books) ? "0" : implode(",", array_column($books, 'id'));
        // Urutkan ASC agar berbeda dengan Best Authors
        $fallback = $conn->query("SELECT id, title, author, image FROM books WHERE id NOT IN ($exclude_ids) ORDER BY id ASC LIMIT $limit");
        $books = array_merge($books, $fallback->fetch_all(MYSQLI_ASSOC));
    }

    return $books;
}

// 3. Fungsi ambil buku Explore More Books (Mendukung Search & Filter Genre)
function getExploreBooks($conn, $search_keyword, $selected_category, $limit = 11, $offset = 0) {
    $limit = max(1, min(11, (int) $limit));
    $offset = max(0, (int) $offset);

    $query_sql = "SELECT id, title, author, category, price, stock, image FROM books WHERE 1=1";
    $params = [];
    $types = "";

    if ($selected_category !== '' && $selected_category !== 'All') {
        $query_sql .= " AND category = ?";
        $types .= "s";
        $params[] = $selected_category;
    }

    if ($search_keyword !== '') {
        $query_sql .= " AND (title LIKE ? OR author LIKE ?)";
        $types .= "ss";
        $like = "%" . $search_keyword . "%";
        $params[] = $like;
        $params[] = $like;
    }

    $query_sql .= " ORDER BY id ASC LIMIT ? OFFSET ?";
    $types .= "ii";
    $params[] = $limit;
    $params[] = $offset;

    $stmt = $conn->prepare($query_sql);
    if (!$stmt) {
        return [];
    }

    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $books = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return $books;
}
?>