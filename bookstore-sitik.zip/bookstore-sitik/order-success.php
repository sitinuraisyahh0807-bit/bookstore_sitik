<?php
session_start();

require_once __DIR__ . "/config/database.php";
require_once __DIR__ . "/config/order-success-functions.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$user_id = (int) $_SESSION["user_id"];

if (empty($_SESSION["payment_proof_csrf"])) {
    $_SESSION["payment_proof_csrf"] = bin2hex(random_bytes(32));
}

$order_id = (int) (
    $_GET["order_id"]
    ?? $_SESSION["last_order_id"]
    ?? 0
);

if ($order_id < 1) {
    header("Location: home.php");
    exit;
}

$order = getOrderDetails($conn, $order_id, $user_id);

if (!$order) {
    die("Order not found.");
}

$order_items = getOrderItems($conn, $order_id);

$order_number = "#ORD-" . str_pad($order["id"], 4, "0", STR_PAD_LEFT);
$order_date = date("d-m-Y", strtotime($order["created_at"]));
$payment_method = $order["payment_method"];
$receipt_payment_status = $order["payment_status"] ?? "Unpaid";
$is_cod = in_array(strtolower(trim($payment_method)), ["cash on delivery", "pay on delivery", "cod", "cash on-delivery", "bayar di tempat"], true);

$needs_proof = !$is_cod;

$payment_destination = "";

if ($payment_method === "Transfer BCA") {
    $payment_destination = "BCA: 1234-5678-9012 (S'itik Bookstore)";
} elseif ($payment_method === "Transfer Mandiri") {
    $payment_destination = "Mandiri: 9876-5432-1098 (S'itik Bookstore)";
} elseif ($payment_method === "E-Wallet DANA") {
    $payment_destination = "DANA: 0812-1111-2222 (S'itik Bookstore)";
} elseif ($payment_method === "E-Wallet OVO") {
    $payment_destination = "OVO: 0812-3333-4444 (S'itik Bookstore)";
} elseif ($payment_method === "E-Wallet GoPay") {
    $payment_destination = "GoPay: 0812-5555-6666 (S'itik Bookstore)";
} elseif ($payment_method === "E-Wallet ShopeePay") {
    $payment_destination = "ShopeePay: 0812-7777-8888 (S'itik Bookstore)";
}

function e($value)
{
    return htmlspecialchars((string) ($value ?? ""), ENT_QUOTES, "UTF-8");
}

function rupiah($value)
{
    return "Rp " . number_format((float) $value, 0, ",", ".");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Purchase Successful - S'itik Bookstore</title>

    <link rel="stylesheet" href="css/order-success.css?v=44">

    <style>
        .purchase-result-layout {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 360px;
            align-items: start;
            gap: 28px;
            width: min(1400px, calc(100% - 48px));
            margin: 40px auto;
        }

        .purchase-result-layout .success-wrapper {
            width: 100%;
            max-width: none;
            min-width: 0;
            margin: 0;
        }

        .purchase-result-layout .success-card {
            width: 100%;
            max-width: none;
            margin: 0;
        }

        .purchase-receipt {
            box-sizing: border-box;
            width: 100%;
            max-width: 360px;
            margin: 0;
            padding: 26px 22px;
            background: #fffdf8;
            color: #292929;
            border: 1px solid #ded6c9;
            border-radius: 8px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
            font-family: "Courier New", monospace;
            font-size: 12px;
            line-height: 1.5;
            text-align: left;
        }

        .purchase-receipt * {
            box-sizing: border-box;
        }

        .receipt-header {
            text-align: center;
            margin-bottom: 18px;
        }

        .receipt-header h2 {
            margin: 0;
            color: #3b4d37;
            font-family: "Courier New", monospace;
            font-size: 20px;
            font-weight: 800;
            line-height: 1.4;
        }

        .receipt-header p {
            margin: 4px 0 0;
            font-size: 10px;
            letter-spacing: 2px;
        }

        .receipt-divider {
            border-top: 1px dashed #777;
            margin: 13px 0;
        }

        .receipt-detail p {
            display: flex;
            flex-direction: column;
            gap: 3px;
            margin: 9px 0;
        }

        .receipt-detail span {
            color: #777;
            font-size: 10px;
        }

        .receipt-detail strong {
            font-size: 12px;
            overflow-wrap: anywhere;
        }

        .receipt-column-heading,
        .receipt-total-row,
        .receipt-grand-total {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 10px;
        }

        .receipt-column-heading {
            font-weight: bold;
            font-size: 11px;
        }

        .receipt-book {
            margin: 12px 0;
        }

        .receipt-book-name {
            display: grid;
            grid-template-columns: 32px minmax(0, 1fr);
            gap: 6px;
            line-height: 1.5;
        }

        .receipt-book-name strong {
            font-size: 12px;
            overflow-wrap: anywhere;
        }

        .receipt-book-price {
            margin: 4px 0 0 38px;
            text-align: right;
            font-weight: bold;
        }

        .receipt-total-row {
            margin: 9px 0;
            font-size: 12px;
        }

        .receipt-grand-total {
            font-size: 12px;
            font-weight: bold;
        }

        .receipt-grand-total strong {
            font-size: 14px;
            text-align: right;
            overflow-wrap: anywhere;
        }

        .receipt-thanks {
            margin: 20px 0 0;
            text-align: center;
            font-size: 11px;
            line-height: 1.8;
        }

        .receipt-print-button {
            width: 100%;
            margin-top: 20px;
            padding: 12px;
            border: none;
            border-radius: 24px;
            background: #5a7156;
            color: white;
            font-family: inherit;
            font-weight: bold;
            cursor: pointer;
        }

        .receipt-print-button:hover {
            background: #3b4d37;
        }

        @media (max-width: 950px) {
            .purchase-result-layout {
                grid-template-columns: minmax(0, 1fr);
                width: calc(100% - 32px);
                gap: 24px;
            }

            .purchase-result-layout .purchase-receipt {
                max-width: 420px;
                justify-self: center;
            }
        }

        @media print {
            @page {
                margin: 10mm;
            }

            body * {
                visibility: hidden !important;
            }

            #purchase-receipt,
            #purchase-receipt * {
                visibility: visible !important;
            }

            #purchase-receipt {
                position: absolute !important;
                top: 0 !important;
                left: 0 !important;
                width: 100% !important;
                max-width: 380px !important;
                margin: 0 !important;
                box-shadow: none !important;
                border: none !important;
                background: #fff !important;
                color: #000 !important;
            }

            .receipt-print-button {
                display: none !important;
            }
        }
    </style>
</head>

<body>

<div class="purchase-result-layout">

    <!-- CARD PURCHASE SUCCESSFUL -->
    <main class="success-wrapper">
        <section class="success-card">

            <div class="success-icon">
                <img src="images/success-check.png" alt="Success Icon">
            </div>

            <h1>Purchase Successful</h1>

            <p class="success-subtitle">
                Detail Pemesanan untuk <?= e($order["customer_name"]) ?>
            </p>

            <div class="success-information">

                <!-- PESANAN -->
                <section class="information-box">
                    <h2>Pesanan</h2>

                    <p><strong>Order ID:</strong> <?= e($order_number) ?></p>
                    <p><strong>Tanggal:</strong> <?= e($order_date) ?></p>

                    <div class="payment-info">
                        <strong>Metode Pembayaran:</strong>
                        <p class="payment-name" style="margin: 4px 0;">
                            <?= e($payment_method) ?>
                        </p>

                        <?php if ($payment_destination !== ""): ?>
                            <p style="font-size:12px;color:#555;margin:4px 0;background:#f4f1ea;padding:6px;border-radius:4px;">
                                <b>Tujuan:</b><br>
                                <?= e($payment_destination) ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </section>

                <!-- BUKU -->
                <section class="information-box">
                    <h2>Buku</h2>

                    <div class="success-books">
                        <?php foreach ($order_items as $item): ?>
                            <article class="success-book">
                                <img
                                    src="<?= e($item["image"]) ?>"
                                    alt="<?= e($item["title"]) ?>"
                                >

                                <div class="success-book-information">
                                    <strong class="success-book-title">
                                        <?= e($item["title"]) ?>
                                    </strong>

                                    <span><?= e($item["author"]) ?></span>

                                    <span>
                                        Quantity: <?= (int) $item["quantity"] ?>
                                    </span>

                                    <strong>
                                        Sub-total: <?= rupiah($item["line_total"]) ?>
                                    </strong>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                </section>

                <!-- TOTAL -->
                <section class="information-box">
                    <h2>Total</h2>

                    <div class="total-row">
                        <strong>Sub-Total:</strong>
                        <span><?= rupiah($order["subtotal"]) ?></span>
                    </div>

                    <div class="total-row">
                        <strong>Shipping:</strong>
                        <span>
                            <?php if ((float) $order["shipping_fee"] == 0): ?>
                                Free
                            <?php else: ?>
                                <?= rupiah($order["shipping_fee"]) ?>
                            <?php endif; ?>
                        </span>
                    </div>

                    <hr>

                    <div class="total-row final-total">
                        <strong>Total Bayar:</strong>
                        <strong><?= rupiah($order["total_amount"]) ?></strong>
                    </div>
                </section>

            </div>

            <a href="home.php#explore-books" class="continue-button">
                CONTINUE SHOPPING
            </a>

            <?php if ($needs_proof): ?>
                <div class="success-payment-instruction" style="background:#f4f1ea;border:1px solid #d9d0c3;padding:18px;border-radius:8px;margin:25px 0 15px;text-align:left;">
                    <h4 style="margin:0 0 8px;font-size:14px;color:#3b4d37;font-family:Georgia,serif;">
                        💳 Instruksi Pembayaran
                    </h4>

                    <p style="margin:0 0 10px;font-size:13px;color:#555;">
                        Pesanan Anda berhasil dibuat! Silakan segera lakukan pembayaran ke tujuan berikut:
                    </p>

                    <div style="font-size:14px;color:#4b3524;font-weight:bold;background:#fff;padding:10px;border-radius:6px;border:1px dashed #d9d0c3;">
                        🏦 <?= e($payment_destination) ?>
                    </div>

                    <p style="margin:10px 0 0;font-size:12px;color:#777;font-style:italic;">
                        Jangan lupa mengunggah bukti transfer melalui halaman profil setelah melakukan pembayaran.
                    </p>
                </div>

                <section class="payment-proof-section" style="margin-top:25px;background:#fdfbf7;padding:20px;border-radius:8px;border:1px solid #d9d0c3;text-align:center;">
                    <h2 style="color:#3b4d37;margin-bottom:10px;font-size:18px;">
                        Bukti Pembayaran
                    </h2>

                    <?php if (!empty($order["payment_proof"])): ?>
                        <div class="proof-sent" style="background:#e2ede0;color:#3b4d37;padding:12px;border-radius:6px;font-weight:bold;margin-bottom:15px;">
                            ✓ Bukti pembayaran sudah diterima.
                        </div>

                        <p style="font-size:14px;color:#555;margin-bottom:10px;">
                            Status Pembayaran:
                            <strong><?= e($order["payment_status"] ?? "Waiting Verification") ?></strong>
                        </p>

                        <div style="margin-top:10px;">
                            <span style="font-size:13px;color:#777;display:block;margin-bottom:5px;">
                                Bukti yang Anda Unggah:
                            </span>
                            <?php if (strtolower(pathinfo($order["payment_proof"], PATHINFO_EXTENSION)) === "pdf"): ?>
                                <a href="<?= e($order["payment_proof"]) ?>" target="_blank" rel="noopener noreferrer">Lihat bukti pembayaran (PDF)</a>
                            <?php else: ?>
                                <img
                                    class="payment-proof-preview"
                                    src="<?= e($order["payment_proof"]) ?>"
                                    alt="Bukti pembayaran"
                                    style="max-width:250px;border-radius:6px;border:1px solid #ccc;box-shadow:0 2px 4px rgba(0,0,0,0.1)"
                                >
                            <?php endif; ?>
                        </div>
                    <?php elseif (($order["payment_status"] ?? "Unpaid") === "Unpaid" && strtolower($order["order_status"]) === "pending"): ?>
                        <p style="font-size:13px;color:#666;margin-bottom:15px;">
                            Silakan kirim bukti pembayaran untuk metode
                            <strong><?= e($payment_method) ?></strong>.
                        </p>

                        <form
                            action="upload-payment-proof.php"
                            method="post"
                            enctype="multipart/form-data"
                            class="payment-proof-form"
                        >
                            <input type="hidden" name="csrf_token" value="<?= e($_SESSION['payment_proof_csrf']); ?>">
                            <input
                                type="hidden"
                                name="order_id"
                                value="<?= (int) $order["id"] ?>"
                            >

                            <div style="margin-bottom:15px;">
                                <input
                                    type="file"
                                    name="payment_proof"
                                    accept=".jpg,.jpeg,.png,.webp,.pdf"
                                    required
                                    style="font-size:13px;"
                                >
                            </div>

                            <button
                                type="submit"
                                class="upload-payment-button"
                                style="background-color:#5A7156;color:white;padding:10px 20px;border:none;border-radius:6px;cursor:pointer;font-weight:bold;"
                            >
                                KIRIM BUKTI PEMBAYARAN
                            </button>
                        </form>
                    <?php else: ?>
                        <p style="font-size:13px;color:#666;margin-bottom:10px;">
                            Status pembayaran: <strong><?= e($order["payment_status"] ?? "Unpaid") ?></strong>
                        </p>
                        <p style="font-size:13px;color:#777;">Bukti pembayaran tidak dapat diunggah pada status pesanan saat ini.</p>
                    <?php endif; ?>
                </section>
            <?php endif; ?>

        </section>

        <div class="delivery-information">
            <p><strong>Est. Delivery:</strong> 3 days</p>
            <p>Keep your Order ID for order tracking</p>
        </div>
    </main>

    <!-- STRUK DI LUAR CARD, SEBELAH KANAN -->
    <aside class="purchase-receipt" id="purchase-receipt">

        <div class="receipt-header">
            <h2>S'ITIK BOOKSTORE</h2>
            <p>BUKTI PEMBELIAN</p>
        </div>

        <div class="receipt-divider"></div>

        <div class="receipt-detail">
            <p>
                <span>ORDER ID</span>
                <strong><?= e($order_number) ?></strong>
            </p>

            <p>
                <span>TANGGAL</span>
                <strong><?= e($order_date) ?></strong>
            </p>

            <p>
                <span>NAMA PEMBELI</span>
                <strong><?= e($order["customer_name"]) ?></strong>
            </p>
        </div>

        <div class="receipt-divider"></div>

        <div class="receipt-column-heading">
            <span>QTY / ITEM</span>
            <span>JUMLAH</span>
        </div>

        <?php foreach ($order_items as $item): ?>
            <div class="receipt-book">
                <div class="receipt-book-name">
                    <span><?= (int) $item["quantity"] ?> ×</span>
                    <strong><?= e($item["title"]) ?></strong>
                </div>

                <div class="receipt-book-price">
                    <?= rupiah($item["line_total"]) ?>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="receipt-divider"></div>

        <div class="receipt-total-row">
            <span>Subtotal</span>
            <span><?= rupiah($order["subtotal"]) ?></span>
        </div>

        <div class="receipt-total-row">
            <span>Pengiriman</span>
            <span>
                <?php if ((float) $order["shipping_fee"] == 0): ?>
                    Gratis
                <?php else: ?>
                    <?= rupiah($order["shipping_fee"]) ?>
                <?php endif; ?>
            </span>
        </div>

        <div class="receipt-divider"></div>

        <div class="receipt-grand-total">
            <span>TOTAL BAYAR</span>
            <strong><?= rupiah($order["total_amount"]) ?></strong>
        </div>

        <div class="receipt-divider"></div>

        <div class="receipt-detail">
            <p>
                <span>METODE PEMBAYARAN</span>
                <strong><?= e($payment_method) ?></strong>
            </p>

            <p>
                <span>STATUS PESANAN</span>
                <strong><?= e($order["order_status"] ?? "Tidak tersedia") ?></strong>
            </p>

            <p>
                <span>STATUS PEMBAYARAN</span>
                <strong><?= e($receipt_payment_status) ?></strong>
            </p>
        </div>

        <p class="receipt-thanks">
            Terima kasih telah berbelanja di<br>
            <strong>S'itik Bookstore</strong>
        </p>

        <button
            type="button"
            class="receipt-print-button"
            onclick="window.print()"
        >
            CETAK / SIMPAN PDF
        </button>

    </aside>

</div>

</body>
</html>