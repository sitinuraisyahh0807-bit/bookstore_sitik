.USE sitik_bookstore;

-- 1. Status pembayaran harus dapat menyimpan semua status workflow.
ALTER TABLE orders
    MODIFY COLUMN payment_status VARCHAR(40) NOT NULL DEFAULT 'Unpaid';

-- Normalisasi pesanan COD yang masih berjalan.
UPDATE orders
SET payment_status = 'Pay on Delivery'
WHERE LOWER(TRIM(payment_method)) IN
      ('cash on delivery', 'pay on delivery', 'cod', 'cash on-delivery', 'bayar di tempat')
  AND LOWER(order_status) IN ('pending', 'processing')
  AND (payment_status IS NULL OR payment_status = '' OR LOWER(payment_status) = 'unpaid');

-- Transfer yang sudah mengunggah bukti menunggu verifikasi.
UPDATE orders
SET payment_status = 'Waiting Verification'
WHERE LOWER(TRIM(payment_method)) NOT IN
      ('cash on delivery', 'pay on delivery', 'cod', 'cash on-delivery', 'bayar di tempat')
  AND payment_proof IS NOT NULL
  AND payment_proof <> ''
  AND LOWER(order_status) = 'pending'
  AND LOWER(payment_status) = 'unpaid';

-- 2. Tabel pesan awal pelanggan.
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    subject VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_contact_user (user_id),
    INDEX idx_contact_read_created (is_read, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Lengkapi tabel pesan lama tanpa menghapus pesan yang sudah tersimpan.
ALTER TABLE contact_messages
    ADD COLUMN IF NOT EXISTS user_id INT NULL,
    ADD COLUMN IF NOT EXISTS name VARCHAR(100) NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS email VARCHAR(150) NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS subject VARCHAR(150) NOT NULL DEFAULT '',
    ADD COLUMN IF NOT EXISTS message TEXT NULL,
    ADD COLUMN IF NOT EXISTS is_read TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE contact_messages
    MODIFY COLUMN user_id INT NULL;

-- 3. Tabel balasan percakapan.
CREATE TABLE IF NOT EXISTS contact_replies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    message_id INT NOT NULL,
    sender_id INT NOT NULL,
    sender_role ENUM('admin', 'user') NOT NULL,
    reply TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_replies_message (message_id, created_at, id),
    INDEX idx_replies_unread (sender_role, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE contact_replies
    ADD COLUMN IF NOT EXISTS message_id INT NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS sender_id INT NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS sender_role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
    ADD COLUMN IF NOT EXISTS reply TEXT NULL,
    ADD COLUMN IF NOT EXISTS is_read TINYINT(1) NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;


