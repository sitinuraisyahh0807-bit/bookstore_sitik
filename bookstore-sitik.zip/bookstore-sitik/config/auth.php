<?php
function requireLogin(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    if (empty($_SESSION['user_id'])) { header('Location: ' . (str_contains($_SERVER['PHP_SELF'], '/admin/') ? '../login.php' : 'login.php')); exit; }
}
function requireAdmin(): void {
    requireLogin();
    if (($_SESSION['user_role'] ?? '') !== 'admin') {
        http_response_code(403);
        exit('Akses ditolak. Halaman ini hanya untuk administrator.');
    }
}
function verifyCsrf(): void {
    if (session_status() !== PHP_SESSION_ACTIVE) session_start();
    $token = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(419); exit('Sesi formulir tidak valid. Muat ulang halaman lalu coba kembali.');
    }
}
