S'TITIK BOOKSTORE - CATATAN PEMASANGAN DAN PERBAIKAN

STRUKTUR:
- PHP aplikasi berada di root proyek.
- File database berada di folder database/.
- Bukti pembayaran tetap berada di uploads/payment-proofs/.

DATABASE BARU:
1. Buat database bernama sitik_bookstore.
2. Import database/sitik_bookstore.sql.
3. Pastikan konfigurasi config/database.php sesuai dengan MySQL XAMPP.

DATABASE LAMA / DATA SUDAH ADA:
1. Backup database sitik_bookstore melalui phpMyAdmin > Export.
2. Pilih database sitik_bookstore > tab SQL.
3. Jalankan database/repair_existing_database.sql.
4. Script ini menyesuaikan payment_status dan menyiapkan tabel chat tanpa
   menghapus isi pesanan, pengguna, buku, atau pesan yang sudah tersimpan.

PENGUJIAN:
1. Login sebagai pelanggan dan kirim pesan di Contact.
2. Login admin > Pesan Masuk > Balas Pesan.
3. Login pelanggan > Contact > buka percakapan dan periksa balasan admin.
4. Buat pesanan COD: Pending > Processing > Selesaikan + Konfirmasi COD.
5. Buat pesanan transfer: upload bukti > admin verifikasi > Processing > Completed.
6. Uji pembatalan pesanan Pending/Processing dan pastikan stok kembali hanya sekali.

CATATAN:
- Seluruh file PHP telah diperiksa dengan php -l.
- Pemeriksaan sintaks bukan pengganti pengujian runtime di XAMPP.
- Jangan hapus uploads/payment-proofs karena berisi bukti transaksi.
- my-messages.php dipertahankan sebagai alamat kompatibilitas dan mengarahkan
  pelanggan ke card percakapan di contact.php.
- File test_connection.php dan halaman admin duplikat di root dihapus karena
  tidak digunakan oleh navigasi aktif. Halaman admin aktif berada di folder admin/.
