USE sitik_bookstore;

-- Pesanan COD yang masih berjalan menunggu pembayaran saat barang diterima.
UPDATE orders
SET payment_status = 'Pay on Delivery'
WHERE LOWER(TRIM(payment_method)) IN
      ('cash on delivery', 'pay on delivery', 'cod', 'cash on-delivery', 'bayar di tempat')
  AND order_status IN ('pending', 'processing')
  AND payment_status = 'Unpaid';

-- Transfer yang sudah mengunggah bukti menunggu verifikasi admin.
UPDATE orders
SET payment_status = 'Waiting Verification'
WHERE LOWER(TRIM(payment_method)) NOT IN
      ('cash on delivery', 'pay on delivery', 'cod', 'cash on-delivery', 'bayar di tempat')
  AND payment_proof IS NOT NULL
  AND payment_proof <> ''
  AND order_status = 'pending'
  AND payment_status = 'Unpaid';

-- CATATAN:
-- 1. Pesanan COD lama berstatus Completed + Unpaid harus diperiksa manual.
--    Ubah menjadi Paid hanya jika uang benar-benar telah diterima.
-- 2. Transfer lama berstatus Verified perlu dicocokkan dengan bukti transaksi.
-- 3. Stok pesanan yang sudah lama Cancelled tidak otomatis dikembalikan oleh
--    migrasi ini karena tidak ada penanda historis apakah stok pernah dipulihkan.
