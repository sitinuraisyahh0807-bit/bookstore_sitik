<?php
session_start();

require_once __DIR__ . "/../config/database.php";

// =====================================
// CEK HAK AKSES ADMIN
// =====================================

if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit;
}

if (($_SESSION["user_role"] ?? "") !== "admin") {
    header("Location: ../home.php");
    exit;
}

// =====================================
// TOKEN CSRF
// =====================================

if (empty($_SESSION["message_csrf"])) {
    $_SESSION["message_csrf"] = bin2hex(random_bytes(32));
}

$notification = "";

// =====================================
// UBAH STATUS BACA PESAN
// =====================================

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["change_status"])) {

    $token = $_POST["csrf_token"] ?? "";

    if (!hash_equals($_SESSION["message_csrf"], $token)) {
        $notification = "Sesi tidak valid. Silakan muat ulang halaman.";
    } else {
        $message_id = (int) ($_POST["message_id"] ?? 0);
        $new_status = (int) ($_POST["new_status"] ?? -1);

        if ($message_id > 0 && in_array($new_status, [0, 1], true)) {
            // Pastikan percakapan memang ada.
            $check = $conn->prepare("SELECT id FROM contact_messages WHERE id = ? LIMIT 1");
            $check->bind_param("i", $message_id);
            $check->execute();
            $exists = $check->get_result()->fetch_assoc();
            $check->close();

            if ($exists) {
                $stmt = $conn->prepare("
                    UPDATE contact_messages
                    SET is_read = ?
                    WHERE id = ?
                ");
                $stmt->bind_param("ii", $new_status, $message_id);
                $stmt->execute();
                $stmt->close();

                // Jika admin menandai sudah dibaca, tandai juga seluruh balasan pelanggan.
                if ($new_status === 1) {
                    $stmt = $conn->prepare("
                        UPDATE contact_replies
                        SET is_read = 1
                        WHERE message_id = ?
                          AND sender_role = 'user'
                    ");
                    $stmt->bind_param("i", $message_id);
                    $stmt->execute();
                    $stmt->close();

                    $notification = "Percakapan berhasil ditandai sudah dibaca.";
                } else {
                    $notification = "Percakapan ditandai belum dibaca.";
                }
            } else {
                $notification = "Percakapan tidak ditemukan.";
            }
        } else {
            $notification = "Data status tidak valid.";
        }
    }
}

// =====================================
// AMBIL DATA PESAN
// =====================================

$result = $conn->query("
    SELECT
        cm.*,

        (
            1 + (
                SELECT COUNT(*)
                FROM contact_replies cr
                WHERE cr.message_id = cm.id
                  AND cr.sender_role = 'user'
            )
        ) AS total_customer_chats,

        (
            SELECT COUNT(*)
            FROM contact_replies cr
            WHERE cr.message_id = cm.id
              AND cr.sender_role = 'user'
              AND cr.is_read = 0
        ) AS unread_chats

    FROM contact_messages cm
    ORDER BY cm.is_read ASC, cm.created_at DESC
");

$messages = $result->fetch_all(MYSQLI_ASSOC);

// =====================================
// HITUNG PESAN BELUM DIBACA
// =====================================

$count_result = $conn->query("
    SELECT
        (SELECT COUNT(*) FROM contact_messages WHERE is_read = 0)
        +
        (SELECT COUNT(*) FROM contact_replies
         WHERE sender_role = 'user' AND is_read = 0) AS total
");
$unread_count = (int) ($count_result->fetch_assoc()["total"] ?? 0);

// Endpoint untuk pengecekan notifikasi baru.
if (isset($_GET["ajax"]) && $_GET["ajax"] === "unread-count") {
    header("Content-Type: application/json; charset=utf-8");
    echo json_encode(["unread_count" => $unread_count]);
    exit;
}

$current_page = basename($_SERVER["PHP_SELF"]);

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, "UTF-8");
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Pesan Masuk - Admin S'titik Bookstore</title>

    <link rel="stylesheet" href="../css/admin.css">

    <style>
        .messages-content {
            padding: 25px;
        }

        .messages-summary {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 15px;
            margin-bottom: 25px;
            padding: 20px;
            background: #fff;
            border: 1px solid #eee;
            border-radius: 12px;
        }

        .messages-summary h2 {
            margin: 0;
            color: #566b50;
        }

        .messages-summary span {
            padding: 8px 15px;
            background: #f7e8c9;
            color: #8a641d;
            border-radius: 20px;
            font-weight: bold;
        }

        .messages-table-wrapper {
            overflow-x: auto;
            padding: 20px;
            background: #fff;
            border-radius: 12px;
            border: 1px solid #eee;
        }

        .messages-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 850px;
        }

        .messages-table th {
            padding: 15px;
            background: #edf0df;
            color: #566b50;
            text-align: left;
        }

        .messages-table td {
            padding: 15px;
            border-bottom: 1px solid #eee;
            vertical-align: top;
        }

        .messages-table tr.unread {
            background: #fffdf3;
            font-weight: 600;
        }

        .message-subject {
            color: #566b50;
            font-weight: bold;
        }


        .message-status {
            display: inline-block;
            padding: 6px 11px;
            border-radius: 20px;
            font-size: 12px;
            background: #fbe8c9;
            color: #8a641d;
        }

        .message-status.read {
            background: #e1f0e3;
            color: #356b3c;
        }

        .read-button {
            padding: 9px 13px;
            border: none;
            border-radius: 7px;
            background: #71836b;
            color: white;
            cursor: pointer;
        }

        .read-button:hover {
            background: #566b50;
        }

        .notification {
            margin-bottom: 20px;
            padding: 13px 17px;
            border-radius: 8px;
            background: #e5f2e5;
            color: #315f35;
        }

        .empty-message {
            padding: 35px;
            text-align: center;
            color: #888;
        }



        .chat-badges {
            display: flex;
            align-items: center;
            gap: 6px;
            margin-top: 8px;
        }

        .chat-count {
            display: inline-block;
            padding: 4px 9px;
            border-radius: 14px;
            background: #edf0df;
            color: #566b50;
            font-size: 11px;
            font-weight: 700;
            white-space: nowrap;
        }

        .unread-count,
        .notification-count {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 22px;
            height: 22px;
            padding: 0 6px;
            border-radius: 50px;
            background: #dc5656;
            color: #fff;
            font-size: 11px;
            font-weight: 700;
            white-space: nowrap;
        }

        .notification-count {
            min-width: 20px;
            height: 20px;
            margin-left: 5px;
        }

        .messages-table {
            table-layout: fixed;
        }

        .messages-table th:nth-child(1) { width: 5%; }
        .messages-table th:nth-child(2) { width: 16%; }
        .messages-table th:nth-child(3) { width: 10%; }
        .messages-table th:nth-child(4) { width: 30%; }
        .messages-table th:nth-child(5) { width: 13%; }
        .messages-table th:nth-child(6) { width: 16%; }
        .messages-table th:nth-child(7) { width: 10%; }

        .messages-table td.message-content-cell {
            text-align: left !important;
            vertical-align: top !important;
            font-weight: 400 !important;
        }

        .messages-table td.message-content-cell .message-body {
            display: block !important;
            width: 100% !important;
            max-width: none !important;
            min-width: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
            float: none !important;
            text-align: left !important;
            text-indent: 0 !important;
            font-weight: 400 !important;
            line-height: 1.55 !important;
            white-space: pre-wrap !important;
            overflow-wrap: anywhere !important;
            word-break: normal !important;
        }

        .status-form {
            margin-top: 9px;
        }

        .status-toggle {
            border: 0;
            border-radius: 7px;
            padding: 7px 9px;
            font-size: 11px;
            font-weight: 600;
            cursor: pointer;
            white-space: nowrap;
            transition: .2s ease;
        }

        .status-toggle.mark-read {
            background: #e1f0e3;
            color: #356b3c;
        }

        .status-toggle.mark-read:hover {
            background: #cfe6d2;
        }

        .status-toggle.mark-unread {
            background: #fbe8c9;
            color: #8a641d;
        }

        .status-toggle.mark-unread:hover {
            background: #f4dba9;
        }
    </style>
</head>

<body>

<div class="admin-container">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <div class="sidebar-logo">
            <img src="../images/logo-icon.png" alt="Logo">

            <div class="logo-text">
                <span class="logo-top">S'itik</span>
                <strong>BOOKSTORE</strong>
                <small>ADMIN PANEL</small>
            </div>
        </div>

        <div class="sidebar-menu">

            <div class="menu-title">MAIN MENU</div>

            <div class="menu-dropdown-container open" id="mainMenuContainer">

                <div class="menu-item-wrapper">
                    <a href="dashboard.php" class="menu-link">
                        ⌂ <span>Dashboard</span>
                    </a>

                    <span class="arrow-toggle" onclick="toggleMenu()">▼</span>
                </div>

                <ul class="submenu-list">

                    <li>
                        <a href="users.php" class="submenu-item">
                            Daftar User
                        </a>
                    </li>

                    <li>
                        <a href="categories.php" class="submenu-item">
                            Kategori Buku
                        </a>
                    </li>

                    <li>
                        <a href="books.php" class="submenu-item">
                            Data Buku
                        </a>
                    </li>

                    <li>
                        <a href="add-book.php" class="submenu-item">
                            Tambah Buku
                        </a>
                    </li>

                    <li>
                        <a href="orders.php" class="submenu-item">
                            Pesanan User
                        </a>
                    </li>

                    <li>
                        <a href="messages.php" class="submenu-item active">
                            Pesan Masuk
                            <span id="sidebarUnreadCount" class="notification-count"><?= $unread_count; ?></span>
                        </a>
                    </li>

                </ul>

            </div>
        </div>

        <div class="sidebar-bottom">
            <a href="../logout.php" class="menu-item logout">
                → <span>Logout</span>
            </a>
        </div>

    </aside>

    <script>
        function toggleMenu() {
            document
                .getElementById("mainMenuContainer")
                .classList.toggle("open");
        }
    </script>

    <!-- MAIN CONTENT -->

    <main class="main-content">

        <header class="admin-header">

            <div class="header-title">
                <h1>Pesan Masuk</h1>
                <p>Kelola pesan dan pertanyaan dari pelanggan.</p>
            </div>

            <div class="admin-profile">
                <div class="profile-avatar">A</div>

                <div class="profile-text">
                    <strong>Administrator</strong>
                    <span>Admin</span>
                </div>
            </div>

        </header>

        <div class="messages-content">

            <?php if ($notification !== ""): ?>
                <div class="notification">
                    <?= e($notification); ?>
                </div>
            <?php endif; ?>

            <div class="messages-summary">
                <h2>Daftar Pesan Pelanggan</h2>

                <span id="summaryUnreadCount">
                    <?= $unread_count; ?> Pesan Belum Dibaca
                </span>
            </div>

            <div class="messages-table-wrapper">

                <?php if (count($messages) > 0): ?>

                                    
<table class="messages-table">

    <thead>
        <tr>
            <th>No.</th>
            <th>Pengirim</th>
            <th>Subjek</th>
            <th>Isi Pesan</th>
            <th>Tanggal</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>

    <tbody>

        <?php foreach ($messages as $index => $msg): ?>

            <tr class="<?= ((int)$msg["is_read"] === 0 || (int)$msg["unread_chats"] > 0) ? "unread" : ""; ?>">

                <td>
                    <?= $index + 1; ?>
                </td>

                <td>
                    <strong><?= e($msg["name"]); ?></strong>
                    <br>
                    <small><?= e($msg["email"]); ?></small>
                    <div class="chat-badges">
                        <span class="chat-count"><?= (int)$msg["total_customer_chats"]; ?> Chat</span>
                        <?php if ((int)$msg["unread_chats"] > 0): ?>
                            <span class="unread-count" title="Pesan pelanggan belum dibaca">
                                <?= (int)$msg["unread_chats"]; ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </td>

                <td class="message-subject">
                    <?= e($msg["subject"]); ?>
                </td>

                <td class="message-content-cell">
                    <div class="message-body"><?= e($msg["message"]); ?></div>
                </td>

                <td>
                    <?= date(
                        "d-m-Y H:i",
                        strtotime($msg["created_at"])
                    ); ?>
                </td>

                <td>
                    <?php
                        $conversation_unread = (
                            (int)$msg["is_read"] === 0 ||
                            (int)$msg["unread_chats"] > 0
                        );
                    ?>

                    <?php if ($conversation_unread): ?>
                        <span class="message-status">Belum Dibaca</span>
                    <?php else: ?>
                        <span class="message-status read">Sudah Dibaca</span>
                    <?php endif; ?>

                    <form method="POST" class="status-form">
                        <input type="hidden" name="csrf_token" value="<?= e($_SESSION['message_csrf']); ?>">
                        <input type="hidden" name="message_id" value="<?= (int)$msg['id']; ?>">
                        <input type="hidden" name="new_status" value="<?= $conversation_unread ? 1 : 0; ?>">

                        <button type="submit" name="change_status"
                            class="status-toggle <?= $conversation_unread ? 'mark-read' : 'mark-unread'; ?>">
                            <?= $conversation_unread ? 'Tandai Sudah Dibaca' : 'Tandai Belum Dibaca'; ?>
                        </button>
                    </form>
                </td>

                <td>
                    <a
                        href="message-detail.php?id=<?= (int) $msg['id']; ?>"
                        class="read-button"
                        style="
                            display: inline-block;
                            padding: 9px 13px;
                            text-decoration: none;
                            white-space: nowrap;
                            font-size: 12px;
                        "
                    >
                        Balas Pesan
                    </a>
                </td>

            </tr>

        <?php endforeach; ?>

    </tbody>

</table>


                <?php else: ?>

                    <div class="empty-message">
                        <h3>Belum Ada Pesan</h3>
                        <p>Pesan dari pelanggan akan muncul di halaman ini.</p>
                    </div>

                <?php endif; ?>

            </div>

        </div>

    </main>

</div>

<script>
let lastUnreadCount = <?= $unread_count; ?>;

// Periksa pesan baru setiap 15 detik.
async function checkNewMessages() {
    try {
        const response = await fetch("messages.php?ajax=unread-count", {
            cache: "no-store"
        });
        if (!response.ok) return;

        const data = await response.json();
        const currentCount = Number(data.unread_count || 0);

        if (currentCount !== lastUnreadCount) {
            window.location.reload();
        }
    } catch (error) {
        // Polling gagal tidak mengganggu halaman.
    }
}

setInterval(checkNewMessages, 15000);
</script>

</body>
</html>