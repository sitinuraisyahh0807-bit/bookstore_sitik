<?php
function handleLogin($conn, &$error_login) {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') { $error_login = 'Email dan password wajib diisi dengan benar.'; return; }
    $stmt = $conn->prepare('SELECT id, name, password, role, status FROM users WHERE email = ? LIMIT 1');
    $stmt->bind_param('s', $email); $stmt->execute(); $user = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$user || (!password_verify($password, $user['password']) && !hash_equals((string)$user['password'], $password))) { $error_login = 'Email atau password salah.'; return; }
    if (!password_verify($password, $user['password'])) { $newHash=password_hash($password,PASSWORD_DEFAULT); $upgrade=$conn->prepare('UPDATE users SET password=? WHERE id=?'); $upgrade->bind_param('si',$newHash,$user['id']); $upgrade->execute(); $upgrade->close(); }
    if (($user['status'] ?? 'Aktif') !== 'Aktif') { $error_login = 'Akun Anda sedang dinonaktifkan. Hubungi administrator.'; return; }
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int)$user['id']; $_SESSION['user_name'] = $user['name']; $_SESSION['user_role'] = $user['role'];
    header('Location: ' . ($user['role'] === 'admin' ? 'admin/dashboard.php' : 'home.php')); exit;
}
function handleRegister($conn, &$error_register, &$success_register) {
    $name = trim($_POST['name'] ?? ''); $email = strtolower(trim($_POST['email'] ?? '')); $password = (string)($_POST['password'] ?? '');
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 8) { $error_register = 'Nama dan email wajib valid. Password minimal 8 karakter.'; return; }
    $check = $conn->prepare('SELECT id FROM users WHERE email = ? LIMIT 1'); $check->bind_param('s', $email); $check->execute(); $check->store_result();
    if ($check->num_rows) { $error_register = 'Email sudah terdaftar, silakan gunakan email lain.'; $check->close(); return; } $check->close();
    $hash = password_hash($password, PASSWORD_DEFAULT); $role = 'user'; $status = 'Aktif';
    $stmt = $conn->prepare('INSERT INTO users (name,email,password,role,status) VALUES (?,?,?,?,?)'); $stmt->bind_param('sssss',$name,$email,$hash,$role,$status);
    if ($stmt->execute()) $success_register = 'Akun berhasil dibuat! Silakan masuk menggunakan akun baru.'; else $error_register = 'Registrasi gagal. Silakan coba kembali.'; $stmt->close();
}
function handleForgotPassword($conn, &$error_forgot, &$success_forgot) {

    // Ambil data dari form
    $email = strtolower(trim($_POST['email'] ?? ''));
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Validasi email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_forgot = 'Masukkan alamat email yang valid.';
        return;
    }

    // Validasi panjang password
    if (strlen($new_password) < 8) {
        $error_forgot = 'Password minimal harus 8 karakter.';
        return;
    }

    // Validasi konfirmasi password
    if ($new_password !== $confirm_password) {
        $error_forgot = 'Konfirmasi password tidak cocok.';
        return;
    }

    // Periksa apakah email terdaftar
    $check = $conn->prepare(
        "SELECT id FROM users WHERE email = ? LIMIT 1"
    );

    $check->bind_param("s", $email);
    $check->execute();

    $user = $check->get_result()->fetch_assoc();

    $check->close();

    if (!$user) {
        $error_forgot = 'Email tidak ditemukan. Gunakan email yang terdaftar.';
        return;
    }

    // Enkripsi password baru
    $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

    // Update password ke database
    $update = $conn->prepare(
        "UPDATE users SET password = ? WHERE id = ?"
    );

    $update->bind_param("si", $password_hash, $user['id']);

    if ($update->execute()) {
        $success_forgot = 'Password berhasil diubah. Silakan login kembali.';
    } else {
        $error_forgot = 'Password gagal diperbarui. Silakan coba kembali.';
    }

    $update->close();
}
function getUserName($conn, $user_id) {
    $stmt = $conn->prepare('SELECT name FROM users WHERE id = ? LIMIT 1'); $stmt->bind_param('i',$user_id); $stmt->execute(); $row=$stmt->get_result()->fetch_assoc(); $stmt->close(); return $row['name'] ?? '';
}
